<!-- Footer -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="list-inline">
					<li>
						<a href="/datenschutzerklaerung" title="Datenschutzerklärung von handyhuelle24.de">Datenschutzerklärung</a>
					</li>	
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/impressum" title="Impressum von handyhuelle24.de" >Impressum</a>
					</li>
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/sitemap" title="Sitemap von handyhuelle24.de">Sitemap</a>
					</li>
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/handyhuelle-selbst-gestalten" title="Handyhülle selbst gestalten" >Handyhülle selbst gestalten</a>
					</li>
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/handyhuelle-fuer-deinen-style" title="Welche Handyhülle pass zu deinen Style?" >Welche Handyhülle passt zu deinen Style?</a>
					</li>
				</ul>
				<p class="copyright text-muted small">Copyright &copy; handyhuelle24.de 2016</p>
			</div>
		</div>
	</div>
</footer>



<!-- Bootstrap Core CSS -->
<link href="/css/bootstrap.min.css" rel="stylesheet">

<!-- W3css 
<link href="/css/w3css.css" rel="stylesheet">-->

<!-- Custom CSS -->
<link href="/css/landing-page.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="/css/font-awesome-corp.css" rel="stylesheet" type="text/css">
<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

<!-- Loadbar -->
<link href="/css/pace.min.css" rel="stylesheet">




<script src="/js/default.js" type="text/javascript"></script>
<? /*
<!-- jQuery -->
<script src="/js/jquery.js" type="text/javascript"></script>

<!-- Bootstrap Core JavaScript -->
<script src="/js/bootstrap.min.js" type="text/javascript"></script>

<!-- Loadbar -->
<script src="/js/pace.min.js" type="text/javascript"></script>

<!-- Scroll to top Button -->
<script src="/js/scrolltotop.js" type="text/javascript"></script>
*/ ?> 
 
<!-- Matomo -->
<script type="text/javascript">
  var _paq = _paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.tagesdecken-24.de/site-admin/piwik/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', '31']);
    _paq.push(['appendToTrackingUrl', 'bots=1']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Matomo Code -->
<noscript>
<img src="https://www.tagesdecken-24.de/site-admin/piwik/matomo.php?idsite=31&bots=1&amp;rec=1" style="border:0" alt="" />
</noscript>
<!-- End Matomo -->
