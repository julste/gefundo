<?php
    header("Location: http://partners.webmasterplan.com/click.asp?ref=729574&site=12836&type=text&tnb=25&diurl=http%3A%2F%2Fwww.photofancy.de%2Fproduktgruppen%2Fsmartphone-huellen.html");
    exit;
?>