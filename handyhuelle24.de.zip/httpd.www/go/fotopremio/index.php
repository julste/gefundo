<?php
    header("Location: http://partners.webmasterplan.com/click.asp?ref=729574&site=13488&type=text&tnb=28");
    exit;
?>
