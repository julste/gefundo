<?php
    header("Location: http://partners.webmasterplan.com/click.asp?ref=729574&site=2558&type=text&tnb=148");
    exit;
?>
