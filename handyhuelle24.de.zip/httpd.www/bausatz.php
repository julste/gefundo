<!DOCTYPE html>
<html lang=de><? $page="template"; ?><? include( "head.php"); ?>
<style>.bs-callout{padding:20px;margin:20px 0;border:1px solid #eee;border-left-width:5px;border-radius:3px}.bs-callout h4{margin-top:0;margin-bottom:5px}.bs-callout p:last-child{margin-bottom:0}.bs-callout code{border-radius:3px}.bs-callout+.bs-callout{margin-top:-5px}.bs-callout-default{border-left-color:#777}.bs-callout-default h4{color:#777}.bs-callout-primary{border-left-color:#428bca}.bs-callout-primary h4{color:#428bca}.bs-callout-success{border-left-color:#5cb85c}.bs-callout-success h4{color:#5cb85c}.bs-callout-success h3{color:#5cb85c}.bs-callout-danger{border-left-color:#d9534f}.bs-callout-danger h4{color:#d9534f}.bs-callout-warning{border-left-color:#f0ad4e}.bs-callout-warning h4{color:#f0ad4e}.bs-callout-info{border-left-color:#5bc0de}.bs-callout-info h4{color:#5bc0de}.videowrapper{float:none;clear:both;width:100%;position:relative;padding-bottom:56.25%;padding-top:25px;height:0}.videowrapper iframe{position:absolute;top:0;left:0;width:100%;height:100%}.img-border{margin-left: 20px;margin-bottom:20px;}
</style>

<body><? include( "nav.php"); ?>

<div style=padding-top:80px;padding-bottom:50px>

<div class=container>

<div class=row>

<div class="col-sm-12 col-lg-12 col-md-12">

<h1>Handyhüllen Bausatz</h1>

<img src="img/bausatz.jpg" class="img-responsive img-rounded pull-right img-border" alt="Responsives Bild">

<p style="text-align: justify;">
Eine Handyh&uuml;lle kann &uuml;berlebenswichtig sein &ndash; nicht unbedingt f&uuml;r den Besitzer eines Smartphone, aber f&uuml;r das Ger&auml;t selbst allemal. Denn ein Handy kann mir nichts dir nichts zerst&ouml;rt werden und daf&uuml;r braucht es nicht einmal viel Pech: Eine unachtsame &Uuml;bergabe, eine zu lange Wanderung bei leichtem Nieselregen, eine &uuml;berraschend glatte Oberfl&auml;che &ndash; schon ist das Ger&auml;t unwiderruflich zerst&ouml;rt und muss f&uuml;r viel Geld repariert oder sogar ersetzt werden. Dass dies mehr als &auml;rgerlich ist, k&ouml;nnen t&auml;glich hunderte, wenn nicht sogar tausende Smartphone-Besitzer best&auml;tigen. Eine H&uuml;lle ist also quasi unverzichtbar, denn sie dient dazu, das Ger&auml;t vor den beschriebenen Ungl&uuml;cksf&auml;llen zu bewahren und seine Lebensdauer dadurch um eine lange Zeit zu erh&ouml;hen.
</p>

<h2>
Ich bau mir meine Handyh&uuml;lle
</h2>

<p style="text-align: justify;">
Wer sich von einer H&uuml;lle mehr verspricht als &bdquo;nur&ldquo; Schutz und wer gleichzeitig nicht gerne nullachtf&uuml;nfzehn-m&auml;&szlig;ig unterwegs, technikaffin und au&szlig;erdem eine Bastlernatur ist, f&uuml;r den ist vielleicht der Trend zum Bausatz interessant: Denn Handyh&uuml;llen kann man nicht nur im fertigen und oft recht simplen Zustand erwerben, sondern es gibt auch Baus&auml;tze f&uuml;r Handyh&uuml;llen, die es erm&ouml;glichen, sich eine wahre High-Tech-Multifunktions-H&uuml;lle selbst zusammen zu bauen. Solche H&uuml;llen k&ouml;nnen dann beispielsweise die Luftqualit&auml;t messen, eine riesige Menge an Speicherplatz bieten und zahlreiche weitere Funktionen mitbringen. Damit ist so eine H&uuml;lle sehr viel mehr als nur ein einfacher Schutz f&uuml;r das Mobilger&auml;t.
</p>

<h3>
Die Bausatz-Handyh&uuml;lle
</h3>

<p style="text-align: justify;">
In einem YouTube-Video wird genau so eine Bausatz-Handyh&uuml;lle, die es k&auml;uflich zu erwerben gibt (mehr dazu: http://www.cliphane.com/handyhulle-mit-bausatz-fur-individuelle-gadgets-tech-talk-welt-der-wunder_8bd628ba8.html), detailliert. Schnell wird klar, dass das Case einen gro&szlig;en Vorteil mit sich bringt: ein modulares Steck-System, das es dem Nutzer erm&ouml;glicht, sein Ger&auml;t individuell aufzur&uuml;sten. Was kompliziert klingt, ist eigentlich ganz einfach: Die H&uuml;lle, die es in vier verschiedenen Farben zu kaufen gibt, wird an die R&uuml;ckseite des Telefons geklemmt. Sie verf&uuml;gt &uuml;ber sechs individuell belegbare Steckpl&auml;tze f&uuml;r Funktionsmodule. Je nach Umfang des Moduls kann dieses ein bis drei Steckpl&auml;tze einnehmen, sodass zwei bis sechs Module pro Handyh&uuml;lle m&ouml;glich sind. Im Onlineshop des Anbieters kann der Nutzer zwischen zw&ouml;lf unterschiedlichen Erweiterungen w&auml;hlen. Diese m&ouml;glichen Erweiterungen sind: ein Alkoholmessger&auml;t, das besonders Partyliebhaber erfreuen wird, ein Temperatur- und Feuchtigkeitsmesser &ndash; ein Muss f&uuml;r alle Outdoor-Freunde &ndash;, ein Micro-SD-Kartenleser f&uuml;r die Erweiterung von Speicherplatz, ein Zusatzakku, LED-Flashlicht, ein Backup-Modul, ein Hotkey-Modul, Lautsprecher f&uuml;r eine verbesserte Tonqualit&auml;t, ein USB-Stick-Modul, ein Laserpointer f&uuml;r den n&auml;chsten Vortrag und ein Messger&auml;t zur Analyse der Luftqualit&auml;t. Neue Erweiterungen sollen folgen, Anregungen der K&auml;ufer nimmt das Unternehmen gerne entgegen. Die H&uuml;lle an sich, die ab 90 Euro erworben werden kann &ndash; also ohne zus&auml;tzliche Module &ndash;, verf&uuml;gt bereits &uuml;ber einen integrierten Akku, der dem Smartphone eine zus&auml;tzliche Laufzeit von bis zu 50 Prozent erm&ouml;glicht. Die einzelnen Module kosten zwischen 18 und 40 Euro pro St&uuml;ck, leere Steckpl&auml;tze k&ouml;nnen mit einem Platzhalterbaustein f&uuml;r etwa 5 Euro gef&uuml;llt werden. &Uuml;ber eine dazugeh&ouml;rige App k&ouml;nnen alle vorhandenen Module der H&uuml;lle via Bluetooth gesteuert werden. Die H&uuml;lle ist bisher nur f&uuml;r einige iPhone- und Galaxy-Modelle verf&uuml;gbar, wobei alle Module sowohl f&uuml;r iOS- als auch Android-Ger&auml;te identisch und somit untereinander tauschbar sind &ndash; so kann beispielsweise f&uuml;r den n&auml;chsten Wanderausflug der Temperaturmesser des Kollegen geliehen werden, der in der Zwischenzeit meinen Laserpointer ausleihen kann.
</p>

<p style="text-align: justify;">
Ein wie oben beschriebenes Case ist eine wahre Allround-H&uuml;lle. Sie bietet nicht nur, aber auch Bastlern ein enormes Ma&szlig; an Flexibilit&auml;t und stillt gleichzeitig die Spiel- und Technikfreude aller Smartphone-Besitzer.
</p>

</div>
</div>
</div>
</div><? include( "footer.php"); ?>