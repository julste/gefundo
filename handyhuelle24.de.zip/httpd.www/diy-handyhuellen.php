<!DOCTYPE html>
<html lang=de><? $page="template"; ?><? include( "head.php"); ?>
<style>.bs-callout{padding:20px;margin:20px 0;border:1px solid #eee;border-left-width:5px;border-radius:3px}.bs-callout h4{margin-top:0;margin-bottom:5px}.bs-callout p:last-child{margin-bottom:0}.bs-callout code{border-radius:3px}.bs-callout+.bs-callout{margin-top:-5px}.bs-callout-default{border-left-color:#777}.bs-callout-default h4{color:#777}.bs-callout-primary{border-left-color:#428bca}.bs-callout-primary h4{color:#428bca}.bs-callout-success{border-left-color:#5cb85c}.bs-callout-success h4{color:#5cb85c}.bs-callout-success h3{color:#5cb85c}.bs-callout-danger{border-left-color:#d9534f}.bs-callout-danger h4{color:#d9534f}.bs-callout-warning{border-left-color:#f0ad4e}.bs-callout-warning h4{color:#f0ad4e}.bs-callout-info{border-left-color:#5bc0de}.bs-callout-info h4{color:#5bc0de}.videowrapper{float:none;clear:both;width:100%;position:relative;padding-bottom:56.25%;padding-top:25px;height:0}.videowrapper iframe{position:absolute;top:0;left:0;width:100%;height:100%}.img-border{margin-left: 20px;margin-bottom:20px;}
</style>

<body><? include( "nav.php"); ?>

<div style=padding-top:80px;padding-bottom:50px>

<div class=container>

<div class=row>

<div class="col-sm-12 col-lg-12 col-md-12">

<h1>DIY Handyhüllen</h1>

<img src="img/diy-handhuellen.jpg" class="img-responsive img-rounded pull-right img-border" alt="Responsives Bild">

<p>
<strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=search-alias=aps&amp;field-keywords=handyh%C3%BClle+diy&amp;rh=i:aps,k:handyh%C3%BClle+diy&amp;linkCode=ll2&amp;tag=handyhuellen24-21&amp;linkId=5639a4964c46e2fdc56a0a4853f5c7c0" rel="nofollow" target="_blank" title="Hier geht es zu Amazon. ">Hier</a>&nbsp;findest du eine Auswahl an DIY-Handyh&uuml;llen.</strong>
</p>

<p style="text-align: justify;">
Ein Smartphone und eine passende H&uuml;lle geh&ouml;ren einfach zusammen. Das ist eigentlich jedem klar, weil das Mobilger&auml;t einfach viel zu schnell zerst&ouml;rt werden kann und es daf&uuml;r selbst den Reichsten unter uns doch zu teuer ist, um leichtfertig damit umzugehen. So logisch die Kombination ist, so langweilig ist sie vielleicht auch &ndash; und von Individualit&auml;t kann eigentlich nicht die Rede sein. Oder?
</p>

<p style="text-align: justify;">
Falsch gedacht, denn seitdem der DIY-Trend &ndash; DIY steht f&uuml;r &bdquo;Do It Yourself&ldquo;, also zu gut Deutsch &bdquo;<strong>Mach&rsquo;s selbst</strong>&ldquo; &ndash; auch den Handyzubeh&ouml;r-Markt erobert hat, sind Handyh&uuml;llen alles andere als Standard und langweilig. Denn es gilt: Selbstgemachtes ist Individualit&auml;t pur, und was man sich ausdenken kann, das kann man auch umsetzen &ndash; das gilt f&uuml;r Basteleien und Kochaktionen ebenso wie f&uuml;r das Gestalten von Handyh&uuml;llen.
</p>

<h2>
Alles andere als langweilig
</h2>

<p style="text-align: justify;">
Eine Handyh&uuml;lle im DIY-Stil selbst zu gestalten meint nicht nur die beinahe schon &bdquo;klassische&ldquo; Variante des Bedruckens eines Cases mit privaten Fotos oder das Eingravieren des eigenen Namens, wie es bei vielen On- und Offline-Anbietern schon lange m&ouml;glich ist. &bdquo;Do It Yourself&ldquo; steht f&uuml;r noch mehr Kreativit&auml;t, f&uuml;r noch mehr Selbst-Gemacht! <strong>Handyh&uuml;llen </strong>kann man n&auml;hen, stricken, h&auml;keln oder vorhandene Cases auf alle m&ouml;gliche Art versch&ouml;nern. Wer nicht selbst vor Kreativit&auml;t nur so &uuml;bersprudelt, der findet im Internet eine schier unersch&ouml;pfliche Menge an Tipps und Tricks, an Anleitungen und Mitmach-Videos, die dabei helfen, sich nach und nach an den Trend heranzutasten.
</p>

<h3>
DIY + Youtube
</h3>

<p style="text-align: justify;">
Die YouTuberinnen Diana und Kisu beispielsweise sind beim &bdquo;Aufpimpen&ldquo; der Handyh&uuml;llen besonders kreativ und gleichzeitig praktisch veranlagt: Sie hatten die Idee, dass die Handyh&uuml;lle gleichzeitig zur To-Do-Liste werden k&ouml;nnte. Und das muss man ihnen lassen: Die Idee ist genial, denn kaum einen anderen Gegenstand nehmen wir t&auml;glich so h&auml;ufig in die Hand wie unser Smartphone &ndash; wenn auf dessen R&uuml;ckseite gleichzeitig unsere To-Dos verzeichnet sind, k&ouml;nnen wir diese eigentlich gar nicht mehr vergessen. Gedacht, getan &ndash; und das so einfach wie nie: Man nehme ein kariertes Blatt, kaufe sich eine g&uuml;nstige und durchsichtige Handyh&uuml;lle, lege diese auf das Blatt und schneide ein St&uuml;ck des Papiers in der Gr&ouml;&szlig;e der H&uuml;lle aus. Das Papier muss danach nur zwischen Handy und H&uuml;lle gesteckt werden, sodass es hinten durchscheint &ndash; und nicht vergessen: das Kameraloch muss freigeschnitten werden. Jetzt einen abwischbaren Stift (z.B. einen Tafelmarker) im Drogeriemarkt kaufen &ndash; und schon kann man die R&uuml;ckseite des Handys zum Verzeichnen und Abhaken der noch zu erledigenden Wochenaufgaben verwenden. Mithilfe eines einfachen Badreinigers kann das Geschriebene auch ruckzuck wieder abgewischt werden. Wer sich das Ganze noch einmal angucken m&ouml;chte, findet das hilfreiche Video hier:
</p>

<div class="visible-lg visible-md visible-sm">
<iframe width="560" height="315" src="https://www.youtube.com/embed/Wf05dwMPruQ" frameborder="0" allowfullscreen></iframe>
</div>

<p style="text-align: justify;">
Um sich eine eigene Handyh&uuml;lle zu gestalten, muss man noch nicht einmal auf eine vorhandene H&uuml;lle zur&uuml;ckgreifen und diese lediglich versch&ouml;nern, sondern kann sich das eigene Case auch komplett selbst machen, und das nicht nur mithilfe von Nadel und Faden, sondern mit einer Hei&szlig;klebepistole. Daf&uuml;r ben&ouml;tigt man zun&auml;chst normales Back- oder Brotpapier, in das das Handy m&ouml;glichst faltenfrei wie ein Geschenk eingepackt werden muss. Mit einem Stift malt man die wichtigsten Stellen wie die Aussparungen der Kamera und die Lautsprecheraussparungen aus und legt das Ganze dann noch einmal auf ein St&uuml;ck Backpapier. Nun f&auml;hrt man mit der Hei&szlig;klebepistole einmal au&szlig;en am Handy entlang, umrandet die Kamera-Aussparungen und kann dann noch verschiedene Muster wie Spiralen oder Punkte auf die H&uuml;lle malen. Dann muss man noch einmal komplett au&szlig;en entlangfahren, um eine Umrandung zu haben, und die Seiten des Handys vollst&auml;ndig mit Hei&szlig;kleber ausmalen. Danach das zweite Backpapier entfernen und auch vorne noch eine Umrandung malen &ndash; wenn das geschehen ist, kann das noch verbliebene Backpapier vorsichtig entfernt werden, sodass lediglich die aus getrocknetem Hei&szlig;kleber bestehende Handyh&uuml;lle zur&uuml;ckbleibt. Wer Farbe mag, kann die H&uuml;lle noch mithilfe von Nagellack einf&auml;rben &ndash; fertig ist das selbstgestaltete Case! Wem das hier zu schnell ging, kann die Anleitung auch noch einmal Schritt f&uuml;r Schritt nachschauen:
</p>

<div class="visible-lg visible-md visible-sm">
<iframe width="560" height="315" src="https://www.youtube.com/embed/Nx8gkxwBjUo" frameborder="0" allowfullscreen></iframe>
	</div>

<p style="text-align: justify;">
Es bleibt festzuhalten: Dass der DIY-Trend nun auch auf dem Handyh&uuml;llen-Markt zu finden ist, ist eine tolle Sache &ndash; Kreative voraus!
</p>

<p style="text-align: justify;">
Du willst dir gleiche eine DIY-Handyh&uuml;lle kaufen? Dann klicke einfach <strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=search-alias=aps&amp;field-keywords=handyh%C3%BClle+diy&amp;rh=i:aps,k:handyh%C3%BClle+diy&amp;linkCode=ll2&amp;tag=handyhuellen24-21&amp;linkId=5639a4964c46e2fdc56a0a4853f5c7c0" rel="nofollow" target="_blank" title="Hier geht es zu Amazon. ">hier</a></strong>!
</p>



</div>
</div>
</div>
</div><? include( "footer.php"); ?>