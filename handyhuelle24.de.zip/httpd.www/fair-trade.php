<!DOCTYPE html>
<html lang=de><? $page="template"; ?><? include( "head.php"); ?>
<style>.bs-callout{padding:20px;margin:20px 0;border:1px solid #eee;border-left-width:5px;border-radius:3px}.bs-callout h4{margin-top:0;margin-bottom:5px}.bs-callout p:last-child{margin-bottom:0}.bs-callout code{border-radius:3px}.bs-callout+.bs-callout{margin-top:-5px}.bs-callout-default{border-left-color:#777}.bs-callout-default h4{color:#777}.bs-callout-primary{border-left-color:#428bca}.bs-callout-primary h4{color:#428bca}.bs-callout-success{border-left-color:#5cb85c}.bs-callout-success h4{color:#5cb85c}.bs-callout-success h3{color:#5cb85c}.bs-callout-danger{border-left-color:#d9534f}.bs-callout-danger h4{color:#d9534f}.bs-callout-warning{border-left-color:#f0ad4e}.bs-callout-warning h4{color:#f0ad4e}.bs-callout-info{border-left-color:#5bc0de}.bs-callout-info h4{color:#5bc0de}.videowrapper{float:none;clear:both;width:100%;position:relative;padding-bottom:56.25%;padding-top:25px;height:0}.videowrapper iframe{position:absolute;top:0;left:0;width:100%;height:100%}
</style>

<body><? include( "nav.php"); ?>

<div style=padding-top:80px;padding-bottom:50px>

<div class=container>

<div class=row>

<div class="col-sm-12 col-lg-12 col-md-12">

<h1>Fair Trade oder Massenware Handyhüllen</h1>

<img src="img/fair-trade-oder-massenware.jpg" class="img-responsive img-rounded pull-right" alt="Responsives Bild">

<p>
<strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=node=364935031&amp;field-keywords=fair+trade&amp;rh=n:562066,n:1384526031,n:364918031,n:364935031,k:fair+trade&amp;ajr=1&amp;linkCode=ll2&amp;tag=handyhuellen.de-21&amp;linkId=bfafbb8e6a822d29de3901b0bea17b23" rel="nofollow" target="_blank" title="Direkt zu Amazon">Hier</a></strong> <strong>geht es&nbsp;direkt zu den Fair Trade Handyh&uuml;llen.</strong>
</p>

<p>
Nicht jeder, der ein Produkt kauft, macht sich automatisch auch Gedanken &uuml;ber dessen Herkunft. Trotzdem kann man mit Fug und Recht behaupten, dass das Bewusstsein f&uuml;r die Produktionsbedingungen von Kleidung, Lebensmitteln und anderen Waren in den letzten Jahren stetig gestiegen ist. Unf&auml;lle in Kleidungsfabriken in Bangladesch, Massentierhaltung und unfaire Herstellungsbedingungen sowie undurchsichtige Warenketten haben dazu gef&uuml;hrt, dass bei vielen Produkten die Frage nach dem &bdquo;Woher&ldquo; &ouml;fter und lauter gestellt wird als je zuvor.
</p>

<p>
Auch bei dem Erwerb von Handys und ihrem Zubeh&ouml;r &ndash; etwa Handtaschen &ndash; nimmt diese Frage an Bedeutung zu. Dass die meisten Mobilger&auml;thersteller ihre Ware m&ouml;glichst g&uuml;nstig herstellen lassen wollen, um einen m&ouml;glichst hohen Gewinn zu erzielen, ist kein Geheimnis. Der iPhone-Produzent Apple muss sich beispielsweise immer wieder vorwerfen lassen, seine hohen Gewinne auf Kosten der Arbeiter und Zulieferer zu erzielen: extreme Arbeitsbedingungen, enormer Druck, 60-Stunden-Wochen, ja sogar Kinderarbeit &ndash; es gibt wenig, womit Apple noch nicht konfrontiert wurde. Viele US-Unternehmen, darunter auch Apple, produzieren ihre Ware im g&uuml;nstigen Ausland &ndash; dies wurde nicht zuletzt noch einmal dadurch in die &Ouml;ffentlichkeit ger&uuml;ckt, dass der designierte Pr&auml;sident Donald Trump das milliardenschwere Unternehmen dazu zwingen m&ouml;chte, zuk&uuml;nftig wieder ausschlie&szlig;lich auf heimischem Boden zu produzieren, um die Arbeitspl&auml;tze zur&uuml;ck in die USA zu holen. Doch nicht nur Apple, auch die meisten anderen Smartphone- und Zubeh&ouml;rhersteller produzieren so billig wie m&ouml;glich &ndash; egal, welchen &bdquo;moralischen&ldquo; Preis sie zahlen m&uuml;ssen. Vor allem das Zubeh&ouml;r f&uuml;r die beliebten Ger&auml;te wird oft als absolute Massenware in Asien hergestellt &ndash; dass dabei nicht selten billige Plastikh&uuml;llen herauskommen, hat oft keine oder nur verschwindend geringe Auswirkungen auf die fantastischen Umsatzzahlen der jeweiligen Unternehmen.
</p>

<p>
Doch mehr und mehr macht sich ein neuer Trend auf dem Markt breit und bietet den Billigherstellern die Stirn: Nachhaltigkeit und Fair Trade sind die neuen Kaufanreize. Allen voran: das Fairphone, das mit seiner auf Fairness ausgerichteten Produktionsweise einen neuen Markt f&uuml;r sich erschlie&szlig;en konnte. Dabei handelt es sich um ein Smartphone, dessen Herstellern es um soziale Werte und positive Einfl&uuml;sse f&uuml;r die Umwelt geht &ndash; sie achten daher darauf, dass alle Materialien m&ouml;glichst fair gehandelt sind, die Arbeitsbedingungen gut sind und das Ger&auml;t selbst wiederverwendbar und recycelbar ist. Das Konzept scheint aufzugehen: Immer mehr Menschen entscheiden sich nicht f&uuml;r einen der gro&szlig;en Anbieter wie Apple oder Samsung, sondern w&auml;hlen bewusst das Fairphone, bei dem sie die Herstellung nachvollziehen und die Bedingungen vertreten k&ouml;nnen. Das Unternehmen stellt aber nicht nur die Smartphones her, sondern auch Zubeh&ouml;r wie Cases oder Verst&auml;rker. Und auch hier achten sie auf faire Bedingungen und bieten so eine echte Alternative zur Massenware.
</p>

<p>
Wer kein Fairphone besitzt oder sich neu kaufen m&ouml;chte, dennoch aber eine nachhaltige und fair produzierte H&uuml;lle f&uuml;r sein Handy w&uuml;nscht, f&uuml;r den gibt es gute Nachrichten: Auch au&szlig;erhalb des Fairphone-Produzenten w&auml;chst das Angebot an Fair-Trade-Handyh&uuml;llen. Die Firma Kohomi aus Mittelhessen beispielsweise hat sich darauf spezialisiert, nachhaltige Handycases herzustellen &ndash; in Handarbeit produzieren die Unternehmer sch&ouml;ne H&uuml;llen aus dem regenerativen Werkstoff Holz sowie recycelbarem Kunststoff. Dies ist nur eines von vielen Beispielen &ndash; immer mehr kleine L&auml;den tauchen im Internet auf, die sich auf eine nachhaltige Produktion von Handyzubeh&ouml;r spezialisiert haben und diese nicht selten in Handarbeit selbst ausf&uuml;hren. Dar&uuml;ber hinaus finden sich im Internet immer mehr Druckvorlagen f&uuml;r 3-D-Drucker, die kostenlos heruntergeladen werden k&ouml;nnen (bspw. auf <a href="http://www.thingiverse.com" target="_blank">http://www.thingiverse.com</a>). Wer &uuml;ber keinen 3-D-Drucker verf&uuml;gt, der kann nat&uuml;rlich auch dar&uuml;ber nachdenken, sich eine Handytasche selbst zu stricken oder zu n&auml;hen &ndash; hier sind allerdings ein wenig Kreativit&auml;t und handwerkliche Geschicklichkeit gefragt.
</p>

<p>
<strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=node=364935031&amp;field-keywords=fair+trade&amp;rh=n:562066,n:1384526031,n:364918031,n:364935031,k:fair+trade&amp;ajr=1&amp;linkCode=ll2&amp;tag=handyhuellen.de-21&amp;linkId=bfafbb8e6a822d29de3901b0bea17b23" rel="nofollow" target="_blank" title="Direkt zu Amazon">Hier</a></strong> <strong>geht es&nbsp;direkt zu den Fair Trade Handyh&uuml;llen.</strong>
</p>

</div>
</div>
</div>
</div><? include( "footer.php"); ?>