<!DOCTYPE html>
<html lang=de><? $page="template"; ?><? include( "head.php"); ?>
<style>.bs-callout{padding:20px;margin:20px 0;border:1px solid #eee;border-left-width:5px;border-radius:3px}.bs-callout h4{margin-top:0;margin-bottom:5px}.bs-callout p:last-child{margin-bottom:0}.bs-callout code{border-radius:3px}.bs-callout+.bs-callout{margin-top:-5px}.bs-callout-default{border-left-color:#777}.bs-callout-default h4{color:#777}.bs-callout-primary{border-left-color:#428bca}.bs-callout-primary h4{color:#428bca}.bs-callout-success{border-left-color:#5cb85c}.bs-callout-success h4{color:#5cb85c}.bs-callout-success h3{color:#5cb85c}.bs-callout-danger{border-left-color:#d9534f}.bs-callout-danger h4{color:#d9534f}.bs-callout-warning{border-left-color:#f0ad4e}.bs-callout-warning h4{color:#f0ad4e}.bs-callout-info{border-left-color:#5bc0de}.bs-callout-info h4{color:#5bc0de}.videowrapper{float:none;clear:both;width:100%;position:relative;padding-bottom:56.25%;padding-top:25px;height:0}.videowrapper iframe{position:absolute;top:0;left:0;width:100%;height:100%}.img-border{margin-left: 20px;margin-bottom:20px;}
</style>

<body><? include( "nav.php"); ?>

<div style=padding-top:80px;padding-bottom:50px>

<div class=container>

<div class=row>

<div class="col-sm-12 col-lg-12 col-md-12">

<h1>Handyhüllen mit Akku</h1>

<img src="img/handy-akku.png" class="img-responsive img-rounded pull-right img-border" alt="Responsives Bild">

<p>
<strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=search-alias=aps&amp;field-keywords=handyh%C3%BCllen+mit+akku&amp;rh=i:aps,k:handyh%C3%BCllen+mit+akku&amp;linkCode=ll2&amp;tag=handyhuellen24-21&amp;linkId=8902a4472c7613c0cf8644851e7f0779" rel="nofollow" target="_blank" title="Hier geht es zu Amazon.  ">Hier</a> kommst du direkt zu Akku Handyh&uuml;llen!</strong>
</p>

<p style="text-align: justify;">
Die richtige Handyh&uuml;lle kann dein Smartphone vor Besch&auml;digungen, wie Kratzer oder St&uuml;rzen sch&uuml;tzen. Aber das ist l&auml;ngst nicht alles!
</p>

<p style="text-align: justify;">
Einige Hersteller haben H&uuml;llen auf den Markt gebracht mit denen du dein Handy unterwegs laden kannst, so genannte Power Case / Power Cover / Battery Case &nbsp;oder einfach Handyh&uuml;lle mit Akku.
</p>

<p style="text-align: justify;">
Aber Achtung! Damit sind nicht Power-Banks gemeint. Power-Banks sind mobile Akkus, meist mit USB Schnittstelle, mit denen du deine Ger&auml;te, wie Handy, Tablet oder Laptop unterwegs mit Strom versorgen kannst.
</p>

<p style="text-align: justify;">
Es sind richtige Handyh&uuml;llen, die angepasst an dein Smartphone nicht unbedingt zu sehr auftragen und es mit Energie unterwegs versorgen k&ouml;nnen oder immer wenn du welche brachst. Power Cases gibt es in vielen&nbsp; verschieden Ausf&uuml;hrungen. Du bekommst edle H&uuml;llen mit Leder, aber auch welche aus Carbon oder Kunststoff um dein Smartphone aufzupeppen. Die Leistung, der Battery Cases reicht von schmalen 1000 mAh bis &uuml;ber 8000 mAh. Zum Vergleich ein iPhone 6 hat um die 2000 mAh Akkuleistung, so sind also bis zu 4 Ladungen und mehr unterwegs m&ouml;glich. Nat&uuml;rlich muss man f&uuml;r solche H&uuml;llen etwas tiefer in die Tasche greifen. Battery Cases mit mehr Leistung bekommst du ab ca. 50 Euro Speziell f&uuml;r das iPhone ist der Markt gr&ouml;&szlig;er, da bekommst du auch schon H&uuml;llen unter 20 Euro, welche allerdings dann nicht sehr viel mAh Leistung mit sich bringen. F&uuml;r viele Smartphone Modelle bekommst du leider noch keine Handyh&uuml;llen mit Akku. F&uuml;r die beiden Platzhirsche Apple und Samsung wirst du relativ leicht f&uuml;ndig werden, vor allem eine iPhone 6 Akku H&uuml;lle wirst du oft finden. &nbsp;
</p>

<h2>
Handyh&uuml;lle mit Akku - Schutzfunktion beeintr&auml;chtigt?
</h2>

<p style="text-align: justify;">
Viele werden sich fragen ob man denn, wenn man sich ein Power Case zulegt Abstriche im Schutz des Handys machen muss. Eine direkte Antwort ist nicht m&ouml;glich. Wenn man sich die Powercases anschaut sehen sie eigentlich ganz robust aus. Viele Hersteller werben zumindest damit, dass das Smartphone in ihren Handyh&uuml;llen genauso gut gesch&uuml;tzt ist wie in anderen H&uuml;llen ohne Akku und manchen F&auml;llen ist das Ger&auml;t sogar besser gesch&uuml;tzt, da der Akku mehr Aufprall Energie aufnehmen kann.
</p>

<p style="text-align: justify;">
Bei einigen Power Covern wird das Smartphone erst ein Bumper (was ein Bumper ist erf&auml;hrst du <a href="https://www.handyhuelle24.de/bumper">hier</a>) gelegt, welcher dann in die eigentliche Akku Handyh&uuml;lle geklickt bzw. gesteckt wird, so ist das Hady dann besser gesch&uuml;tzt.&nbsp; &nbsp;
</p>

<h3>
Tr&auml;gt der Akku zu viel auf?
</h3>

<p style="text-align: justify;">
Ja und nein muss man darauf antworten. Zum einen gibt es &auml;hnlich wie bei Handyh&uuml;llen ohne Akku auch bei H&uuml;llen mit Akku eine sehr gro&szlig;e Auswahl (vornehmlich f&uuml;r iPhone Nutzer), zum anderen muss nat&uuml;rlich beachtet werden, dass der Akku ja irgendwie in die Handyh&uuml;lle integriert werden muss und dass das nicht ganz ohne aufzutragen geht ist logisch.
</p>

<p style="text-align: justify;">
Tats&auml;chlich ist es so, dass das Handy dann mit Power Cover gut das Doppelte wiegt bzw. wiegen kann. F&uuml;r mache Anschl&uuml;sse, wie Kopfh&ouml;rer Buchse braucht man eventuell eine Verl&auml;ngerung, die aber meistens mitgeliefert wird.
</p>

<p style="text-align: justify;">
Man kann sagen wer mehr Leistung haben will, also mehr mAh haben m&ouml;chte, muss auch damit rechnen das die Handyh&uuml;lle etwas dicker wird und sie so mehr Auftr&auml;gt. Denn irgendwo m&uuml;ssen die (mehr) mAh ja untergebracht werden.
</p>

<h3>
Wie wird das Handy geladen?
</h3>

<p style="text-align: justify;">
In die H&uuml;lle ist f&uuml;r den jeweiligen Smartphone Typ der Anschluss integriert, das Handy wird dann in die Akku H&uuml;lle reingeschoben oder geklickt.
</p>

<p style="text-align: justify;">
Eine sch&ouml;ne Neuerung beim Samsung Galaxy S7 und S7 Edge ist die M&ouml;glichkeit des induktiven Aufladens. Das hei&szlig;t f&uuml;r das Aufladen werden keine Stecker mehr ben&ouml;tigt, das Handy wird einfach auf eine Platte gelegt, welche es dann aufl&auml;dt! Allerdings wird diese Platte im Lieferumfang nicht enthalten (Preis ca. 40 Euro).
</p>

<p style="text-align: justify;">
Einige Hersteller bieten bereits Power Cover mit induktiven Laden an, der Vorteil liegt klar auf der Hand, da nichts gesteckt werden muss ist der Verschlei&szlig; sehr viel geringer und das Anbringen der Akku H&uuml;lle vereinfacht sich auch.
</p>

<p style="text-align: justify;">
Ein weiterer Vorteil f&uuml;r iPhone Nutzer ist, dass durch das Power Case die M&ouml;glichkeit besteht das Ger&auml;t &uuml;ber eine Micro USB Schnittstelle zu laden, anstatt mit dem Apple &uuml;blichen Anschluss. Warum ist das ein Vorteil werden sich manche fragen. Wer ein iPhone besitzt wei&szlig; nur zu gut das ein neues Ladeger&auml;t ein kleines Loch in die Geldb&ouml;rse brennen kann. Und die M&ouml;glichkeit das Ger&auml;t &uuml;ber einen Micro USB Anschluss zu Laden ist dann gar nicht so schlecht.
</p>

<p style="text-align: justify;">
Die meisten Akku H&uuml;llen haben auf der R&uuml;ckseite eine LED Anzeige f&uuml;r den Ladezustand des Power Cases und einen Knopf um den Ladevorgang zu starten. Damit wird verhindert, dass das Ger&auml;t durchg&auml;ngig geladen wird und man beh&auml;lt die Kontrolle dar&uuml;ber wann das Ger&auml;t geladen wird.&nbsp;
</p>

<p style="text-align: justify;">
<strong>Exkurs: Was bedeutet mAh?</strong><br />
MAh ist die Abk&uuml;rzung f&uuml;r Milliamperstunden und beschreibt die Menge an Energie, welche in einem Akku gespeichert werden kann. Die Leistung des Akkus kann dabei erheblich beeinflusst werden. Beispielsweise haben Temperatur und&nbsp; Alter einen enormen Einfluss auf die Leistung des Akkus.
</p>

<p style="text-align: justify;">
<strong>Fazit:</strong><br />
Das Battery Case / Power Cover ist f&uuml;r Leute gemacht, die viel mit ihrem Smartphone Arbeiten und &ouml;fter an die Grenzen ihres des Akkus Sto&szlig;en. Wer allerdings mit seinem Akku &uuml;ber den Tag kommt brauch dieses Gadget nicht unbedingt. F&uuml;r reisen kann es sehr praktisch sein, da kommt es &ouml;fter vor, dass Steckodes zu weit weg ist oder man einfach nicht zum laden kommt.
</p>

<p style="text-align: justify;">
Man muss nicht zwei Ger&auml;te mit sich herum schleppen, damit sind Power Bank und Handy gemeint, sondern du hast alles zusammen in einem Ger&auml;t. Weniger Platzbedarf und weiniger Gewicht.
</p>

<p style="text-align: justify;">
In Sachen Leistung und aussehen kann das Power Cover Punkten und auch in der Handhabung sind die meisten Akku H&uuml;llen sehr gut und einfach zu bedienen.
</p>

<p style="text-align: justify;">
Was das Gewicht und den Preis angeht sind die meisten Modelle doch noch sehr schwer und auch Preislich mit ca. 50 &euro; auch nicht so billig. Ein weiterer kleiner Wermutstropfen ist, dass im Moment noch wenig Smartphone Modelle unterst&uuml;tzt werden, was aber in Zukunft bestimmt anders sein wird.&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
</p>

<p>
<strong>Vorteile:</strong>
</p>

<ul>
<li>
Immer ein geladenes Handy wenn man es braucht
</li>
<li>
Hohe mAh Leistung m&ouml;glich bis 8000 mAh und mehr
</li>
<li>
Keine Funktionalen einb&uuml;&szlig;en
</li>
<li>
Keine einb&uuml;&szlig;en bei Schutzfunktion
</li>
<li>
Keine Design Einbu&szlig;en
</li>
<li>
Einsparung der Power Bank
</li>
</ul>

<p>
<strong>Nachteile:</strong>
</p>

<ul>
<li>
Relativ kleine Auswahl
</li>
<li>
noch relativ teuer
</li>
<li>
noch f&uuml;r wenig Handymodelle verf&uuml;gbar
</li>
<li>
Relativ hohes Gewicht
</li>
<li>
NFC funktioniert nicht mehr
</li>
</ul>

<p>&nbsp;

</p>

<p>
Hier ist ein kleines Video in dem ein Power Case f&uuml;r das iPhone 6 Plus vorgestellt wird:
</p>

	<div class="visible-lg visible-md visible-sm">
		<iframe width="560" height="315" src="https://www.youtube.com/embed/UWHkZ86TLiY" frameborder="0" allowfullscreen></iframe>
	</div>
	<br/>
<p>
Battery Case S7 induction:
</p>
<div class="visible-lg visible-md visible-sm">
<iframe width="560" height="315" src="https://www.youtube.com/embed/hTPKHdfrI2E" frameborder="0" allowfullscreen></iframe>
	</div>
<p>
&nbsp; &nbsp;&nbsp;
</p>

<p>
Du bist auf den Geschmack gekommen und m&ouml;chtest dir gleich die extra Energie f&uuml;r unterwegs zulegen? Dann klicke einfach <strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=search-alias=aps&amp;field-keywords=handyh%C3%BCllen+mit+akku&amp;rh=i:aps,k:handyh%C3%BCllen+mit+akku&amp;linkCode=ll2&amp;tag=handyhuellen24-21&amp;linkId=8902a4472c7613c0cf8644851e7f0779" rel="nofollow" target="_blank" title="Hier geht es zu Amazon.  ">hier</a></strong> und such dir passende Akku Handyh&uuml;lle raus!
</p>

</div>
</div>
</div>
</div><? include( "footer.php"); ?>