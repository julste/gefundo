
<nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation"> 

<div class="container topnav"> 

<div class="navbar-header"> <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse"> 

<span class="sr-only">
</span> 

<span class="icon-bar">
</span> 

<span class="icon-bar">
</span> 

<span class="icon-bar">
</span> </button> 

<div style="padding-top:9px;"> <a href="http://handyhuelle24.de" title="handyhuelle24.de"> <img src="/img/logo-handyhuelle24.de.PNG" title="Finde deine Handyhülle online!" alt="Handyhüllen online - Finde die richtige Hülle auf handyhuellen24.de!" class="img-responsive"/></a> 
</div> 
</div> 

<div class="collapse navbar-collapse" id="navbar-collapse"> 
	  <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Verschiedens<span class="caret"></span></a>
          <ul class="dropdown-menu">	
		  <li class="dropdown-header">Sport</li>  
				<li> <a href="/joggen" title="Handyhüllen zum Joggen">Joggen</a> </li> 
				<li> <a href="/outdoor" title="Handyhüllen Outdoor">Outdoor</a></li> 
				 <li role="separator" class="divider"></li>
			<li class="dropdown-header">Film</li>
				<li> <a href="/star-wars" title="Star Wars">Star Wars</a> </li> 
				<li> <a href="/batman" title="Batman">Batman</a> </li> 
				<li> <a href="/pokemon" title="Pokemon">Pokemon</a></li> 
				<li> <a href="/disney" title="Disney">Disney</a></li>
				<li role="separator" class="divider"></li>
			<li class="dropdown-header">Gadget</li>
				<li> <a href="/akku" title="Handyhüllen mit Akku">Akku</a> </li> 
				<li> <a href="/zusatzfunktionen" title="Handyhüllen Zusatzfunktionen">Zusatzfunktionen</a> </li> 
				<li> <a href="/bausatz" title="Handyhüllen Bausatz">Bausatz</a> </li> 			
          </ul>
        </li>
      </ul>
	  	  <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Marken<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li> <a href="/samsung" title="Handyhüllen Samsung">Samsung</a> </li> 
			<li> <a href="/iphone" title="Handyhüllen iPhone">iPhone</a></li> 
			<li> <a href="/htc-one" title="Handyhüllen HTC">HTC</a> </li> 
			<li> <a href="/guess" title="Handyhüllen Guess">Guess</a> </li> 
          </ul>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Arten<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li> <a href="/soft-case" title="Soft Cases">Soft Cases</a> </li> 
			<li> <a href="/tasche" title="Handytaschen">Handytaschen</a> </li> 
			<li> <a href="/socke" title="Handysocken">Handysocken</a> </li> 
			<li> <a href="/hardcase" title="Hard Ceses">Hard Ceses</a> </li>
			<li> <a href="/flipcase" title="Flip Cases">Flip Cases</a> </li> 
			<li> <a href="/bumper" title="Bumper">Bumper</a> </li> 
			<li> <a href="/bookstyle" title="Bookstyle">Bookstyle</a> </li> 			
          </ul>
        </li>
      </ul>
	        <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Material<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li> <a href="/leder" title="Leder">Leder</a> </li> 
			<li> <a href="/filz" title="Filz">Filz</a> </li> 
			<li> <a href="/holz" title="Holz">Holz</a> </li> 
			<li> <a href="/silikon" title="Silikon">Silikon</a> </li> 
			<li> <a href="/hartplastik" title="Hartplastik">Hartplastik</a> </li> 
			<li> <a href="/neopren" title="Neopren">Neopren</a></li> 
          </ul>
        </li>
      </ul>
	        <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Selber machen<span class="caret"></span></a>
          <ul class="dropdown-menu">
          	<li><a href="/handyhuelle-selbst-gestalten" title="Handyhülle selbst gestalten" >Handyhülle selbst gestalten</a></li>
			<li> <a href="/foto" title="Handyhülle mit Foto">Foto</a> </li> 
			<li> <a href="/naehen" title="Handyhülle nähen">nähen</a> </li> 
			<li> <a href="/haekeln" title="Handyhülle häkeln">häkeln</a> </li> 
			<li> <a href="/diy-handyhuellen" title="Handyhülle DIY">DIY</a> </li> 
			<li> <a href="/gravur" title="Handyhülle Gravur">Gravur</a> </li> 
			<li> <a href="/nagellack" title="Handyhülle Nagellack">Nagellack</a></li> 
          </ul>
        </li>
      </ul>
	  
	   <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Allgemein<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li> <a href="http://handyhuelle24.de#warum-eine-handyhuelle-kaufen" title="Warum eine Handyhülle kaufen?">Warum eine Handyhülle kaufen?</a> </li> 
			<li> <a href="http://handyhuelle24.de#welches-material-fuer-die-handyhuelle" title="Welches Material ist das Beste?">Welches Material ist das Beste?</a> </li> 
			<li> <a href="http://handyhuelle24.de#robuste-wasserfeste-handyhuelle" title="Robuste Handyhüllen">Robuste Handyhüllen</a> </li> 
			<li> <a href="http://handyhuelle24.de#guenstige-handyhuellen" title="Günstige Handyhüllen">Günstige Handyhüllen</a> </li>
         	<li> <a href="/welche-handyhuelle-schuetzt.php" title=" Schutzhüllen">Welche Handyhülle schützt wirklich?</a> </li> 
         	<li> <a href="/welche-huelle-passt.php" title="Passende Handyhüllen">Welche Handyhülle passt zu mir?</a> </li> 
          </ul>
        </li>
      </ul>

</div> 
</div> </nav>


<!--
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Titel und Schalter werden für eine bessere mobile Ansicht zusammengefasst 
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Navigation ein-/ausblenden</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     <a  class="navbar-brand" href="http://handyhuelle24.de" title="handyhuelle24.de"> <img src="/img/logo-handyhuelle24.de.PNG" title="Finde deine Handyhülle online!" alt="Handyhüllen online - Finde die richtige Hülle auf handyhuellen24.de!" class="img-responsive"/></a> 
    </div>

    <!-- Alle Navigationslinks, Formulare und anderer Inhalt werden hier zusammengefasst und können dann ein- und ausgeblendet werden 
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Link <span class="sr-only">(aktuell)</span></a></li>
        <li><a href="#">Link</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menü <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Aktion</a></li>
            <li><a href="#">Andere Aktion</a></li>
            <li><a href="#">Irgendwas anderes</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Abgetrennter Link</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Noch ein abgetrennter Link</a></li>
          </ul>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Link</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menü <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Aktion</a></li>
            <li><a href="#">Andere Aktion</a></li>
            <li><a href="#">Irgendwas anderes</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Abgetrennter Link</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse 
  </div><!-- /.container-fluid 
</nav>-->


