<head>
	<!-- Google Analytics Opt-Out-Script -->
	

	<style>
	html {
		font-family:sans-serif;
		-webkit-text-size-adjust:100%;
		-ms-text-size-adjust:100%
	}
	body {
		margin:0
	}nav{
		display:block
	}
	a {
		background-color:transparent
	}
	b{
		font-weight:700
	}
	img {
		border:0
	}
	hr {
		height:0;
		-webkit-box-sizing:content-box;
		-moz-box-sizing:content-box;
		box-sizing:content-box
	}
	button,input{
		margin:0;
		font:inherit;
		color:inherit
	}
	button {
		overflow:visible
	}
	button{
		text-transform:none
	}
	button{
		-webkit-appearance:button;
		cursor:pointer
	}
	button::-moz-focus-inner,input::-moz-focus-inner {
		padding:0;
		border:0
	}
	input {
		line-height:normal
	}
	input[type=checkbox]{
		-webkit-box-sizing:border-box;
		-moz-box-sizing:border-box;
		box-sizing:border-box;
		padding:0
	}
	@media print {:after,:before {
			color:#000!important;
			text-shadow:none!important;
			background:0 0!important;
			-webkit-box-shadow:none!important;
			box-shadow:none!important
		}
	}

	.glyphicon {
		position:relative;
		top:1px;
		display:inline-block;
		font-family:'Glyphicons Halflings';
		font-style:normal;
		font-weight:400;
		line-height:1;
		-webkit-font-smoothing:antialiased;
		-moz-osx-font-smoothing:grayscale
	}
	.glyphicon-search:before {
		content:"\e003"
	}
	* {
		-webkit-box-sizing:border-box;
		-moz-box-sizing:border-box;
		box-sizing:border-box
	}
	:after,:before {
		-webkit-box-sizing:border-box;
		-moz-box-sizing:border-box;
		box-sizing:border-box
	}
	html {
		font-size:10px;
		-webkit-tap-highlight-color:rgba(0,0,0,0)
	}
	body {
		font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
		font-size:14px;
		line-height:1.42857143;
		color:#333;
		background-color:#fff
	}
	button,input{
		font-family:inherit;
		font-size:inherit;
		line-height:inherit
	}
	a {
		color:#337ab7;
		text-decoration:none
	}
	img {
		vertical-align:middle
	}.img-responsive,.thumbnail>img {
		display:block;
		max-width:100%;
		height:auto
	}
	hr {
		margin-top:20px;
		margin-bottom:20px;
		border:0;
		border-top:1px solid #eee
	}
	.sr-only {
		position:absolute;
		width:1px;
		height:1px;
		padding:0;
		margin:-1px;
		overflow:hidden;
		clip:rect(0,0,0,0);
		border:0
	}h4{
		font-family:inherit;
		font-weight:500;
		line-height:1.1;
		color:inherit
	}h4{
		margin-top:10px;
		margin-bottom:10px
	}h4 {
		font-size:18px
	}ul {
		margin-top:0;
		margin-bottom:10px
	}
	.container {
		padding-right:15px;
		padding-left:15px;
		margin-right:auto;
		margin-left:auto
	}
	@media (min-width:768px) {
		.container {
			width:750px
		}
	}
	@media (min-width:992px) {
		.container {
			width:970px
		}
	}
	@media (min-width:1200px) {
		.container {
			width:1170px
		}
	}
	.container-fluid {
		padding-right:15px;
		padding-left:15px;
		margin-right:auto;
		margin-left:auto
	}
	.row {
		margin-right:-15px;
		margin-left:-15px
	}.col-lg-8,.col-md-3,.col-sm-6,.col-xs-12,.col-xs-6{
		position:relative;
		min-height:1px;
		padding-right:15px;
		padding-left:15px
	}.col-xs-12,.col-xs-6{
		float:left
	}
	.col-xs-12 {
		width:100%
	}
	.col-xs-6 {
		width:50%
	}
	@media (min-width:768px) {.col-sm-6{
			float:left
		}
		.col-sm-6 {
			width:50%
		}
	}
	@media (min-width:992px) {.col-md-3{
			float:left
		}
		.col-md-3 {
			width:25%
		}
		.col-md-offset-2 {
			margin-left:16.66666667%
		}
	}
	@media (min-width:1200px) {.col-lg-8{
			float:left
		}
		.col-lg-8 {
			width:66.66666667%
		}
	}
	label {
		display:inline-block;
		max-width:100%;
		margin-bottom:5px;
		font-weight:700
	}
	input[type=checkbox]{
		margin:4px 0 0;
		margin-top:1px \9;
		line-height:normal
	}
	.form-control {
		display:block;
		width:100%;
		height:34px;
		padding:6px 12px;
		font-size:14px;
		line-height:1.42857143;
		color:#555;
		background-color:#fff;
		background-image:none;
		border:1px solid #ccc;
		border-radius:4px;
		-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);
		box-shadow:inset 0 1px 1px rgba(0,0,0,.075);
		-webkit-transition:border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
		-o-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;
		transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s
	}
	.form-control::-moz-placeholder {
		color:#999;
		opacity:1
	}
	.form-control:-ms-input-placeholder {
		color:#999
	}
	.form-control::-webkit-input-placeholder {
		color:#999
	}
	.form-group {
		margin-bottom:15px
	}
	.input-lg {
		height:46px;
		padding:10px 16px;
		font-size:18px;
		line-height:1.3333333;
		border-radius:6px
	}
	.btn {
		display:inline-block;
		padding:6px 12px;
		margin-bottom:0;
		font-size:14px;
		font-weight:400;
		line-height:1.42857143;
		text-align:center;
		white-space:nowrap;
		vertical-align:middle;
		-ms-touch-action:manipulation;
		touch-action:manipulation;
		cursor:pointer;
		-webkit-user-select:none;
		-moz-user-select:none;
		-ms-user-select:none;
		user-select:none;
		background-image:none;
		border:1px solid transparent;
		border-radius:4px
	}
	.btn-default {
		color:#333;
		background-color:#fff;
		border-color:#ccc
	}
	.btn-primary {
		color:#fff;
		background-color:#337ab7;
		border-color:#2e6da4
	}
	.btn-success {
		color:#fff;
		background-color:#5cb85c;
		border-color:#4cae4c
	}
	.btn-warning {
		color:#fff;
		background-color:#f0ad4e;
		border-color:#eea236
	}
	.btn-danger {
		color:#fff;
		background-color:#d9534f;
		border-color:#d43f3a
	}.btn-lg {
		padding:10px 16px;
		font-size:18px;
		line-height:1.3333333;
		border-radius:1px
	}
	.fade {
		opacity:0;
		-webkit-transition:opacity .15s linear;
		-o-transition:opacity .15s linear;
		transition:opacity .15s linear
	}
	.collapse {
		display:none;
		visibility:hidden
	}
	.caret {
		display:inline-block;
		width:0;
		height:0;
		margin-left:2px;
		vertical-align:middle;
		border-top:4px solid;
		border-right:4px solid transparent;
		border-left:4px solid transparent
	}
	.dropdown-menu {
		position:absolute;
		top:100%;
		left:0;
		z-index:1000;
		display:none;
		float:left;
		min-width:160px;
		padding:5px 0;
		margin:2px 0 0;
		font-size:14px;
		text-align:left;
		list-style:none;
		background-color:#fff;
		-webkit-background-clip:padding-box;
		background-clip:padding-box;
		border:1px solid #ccc;
		border:1px solid rgba(0,0,0,.15);
		border-radius:4px;
		-webkit-box-shadow:0 6px 12px rgba(0,0,0,.175);
		box-shadow:0 6px 12px rgba(0,0,0,.175)
	}
	.dropdown-menu>li>a {
		display:block;
		padding:3px 20px;
		clear:both;
		font-weight:400;
		line-height:1.42857143;
		color:#333;
		white-space:nowrap
	}
	.btn-group{
		position:relative;
		display:inline-block;
		vertical-align:middle
	}.btn-group>.btn {
		position:relative;
		float:left
	}
	.btn-group>.btn:first-child {
		margin-left:0
	}
	.btn .caret {
		margin-left:0
	}
	.input-group {
		position:relative;
		display:table;
		border-collapse:separate
	}
	.input-group[class*=col-] {
		float:none;
		padding-right:0;
		padding-left:0
	}
	.input-group .form-control {
		position:relative;
		z-index:2;
		float:left;
		width:100%;
		margin-bottom:0
	}
	.input-group .form-control,.input-group-btn {
		display:table-cell
	}.input-group-btn {
		width:1%;
		white-space:nowrap;
		vertical-align:middle
	}
	.input-group .form-control:first-child{
		border-top-right-radius:0;
		border-bottom-right-radius:0
	}.input-group-btn:last-child>.btn{
		border-top-left-radius:0;
		border-bottom-left-radius:0
	}
	.input-group-btn {
		position:relative;
		font-size:0;
		white-space:nowrap
	}
	.input-group-btn>.btn {
		position:relative
	}
	.input-group-btn:last-child>.btn{
		margin-left:-1px
	}
	.nav {
		padding-left:0;
		margin-bottom:0;
		list-style:none
	}
	.nav>li {
		position:relative;
		display:block
	}
	.nav>li>a {
		position:relative;
		display:block;
		padding:10px 15px
	}
	.navbar {
		position:relative;
		min-height:50px;
		margin-bottom:20px;
		border:1px solid transparent
	}
	@media (min-width:768px) {
		.navbar {
			border-radius:4px
		}
	}
	@media (min-width:768px) {
		.navbar-header {
			float:left
		}
	}
	.navbar-collapse {
		padding-right:15px;
		padding-left:15px;
		overflow-x:visible;
		-webkit-overflow-scrolling:touch;
		border-top:1px solid transparent;
		-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.1);
		box-shadow:inset 0 1px 0 rgba(255,255,255,.1)
	}
	@media (min-width:768px) {
		.navbar-collapse {
			width:auto;
			border-top:0;
			-webkit-box-shadow:none;
			box-shadow:none
		}
		.navbar-collapse.collapse {
			display:block!important;
			height:auto!important;
			padding-bottom:0;
			overflow:visible!important;
			visibility:visible!important
		}.navbar-fixed-top .navbar-collapse{
			padding-right:0;
			padding-left:0
		}
	}.navbar-fixed-top .navbar-collapse {
		max-height:340px
	}
	@media (max-device-width:480px) and (orientation:landscape) {.navbar-fixed-top .navbar-collapse {
			max-height:200px
		}
	}.container>.navbar-collapse,.container>.navbar-header {
		margin-right:-15px;
		margin-left:-15px
	}
	@media (min-width:768px) {.container>.navbar-collapse,.container>.navbar-header {
			margin-right:0;
			margin-left:0
		}
	}.navbar-fixed-top {
		position:fixed;
		right:0;
		left:0;
		z-index:1030
	}
	@media (min-width:768px) {.navbar-fixed-top {
			border-radius:0
		}
	}
	.navbar-fixed-top {
		top:0;
		border-width:0 0 1px
	}
	.navbar-toggle {
		position:relative;
		float:right;
		padding:9px 10px;
		margin-top:8px;
		margin-right:15px;
		margin-bottom:8px;
		background-color:transparent;
		background-image:none;
		border:1px solid transparent;
		border-radius:4px
	}
	.navbar-toggle .icon-bar {
		display:block;
		width:22px;
		height:2px;
		border-radius:1px
	}
	.navbar-toggle .icon-bar+.icon-bar {
		margin-top:4px
	}
	@media (min-width:768px) {
		.navbar-toggle {
			display:none
		}
	}
	.navbar-nav {
		margin:7.5px -15px
	}
	.navbar-nav>li>a {
		padding-top:10px;
		padding-bottom:10px;
		line-height:20px
	}
	@media (min-width:768px) {
		.navbar-nav {
			float:left;
			margin:0
		}
		.navbar-nav>li {
			float:left
		}
		.navbar-nav>li>a {
			padding-top:15px;
			padding-bottom:15px
		}
	}
	@media (min-width:768px) {
		.navbar-right {
			float:right!important;
			margin-right:-15px
		}
	}
	.navbar-default {
		background-color:#f8f8f8;
		border-color:#e7e7e7
	}
	.navbar-default .navbar-nav>li>a {
		color:#777
	}
	.navbar-default .navbar-toggle {
		border-color:#ddd
	}
	.navbar-default .navbar-toggle .icon-bar {
		background-color:#888
	}
	.navbar-default .navbar-collapse{
		border-color:#e7e7e7
	}
	.pagination {
		display:inline-block;
		padding-left:0;
		margin:20px 0;
		border-radius:4px
	}
	.pagination>li {
		display:inline
	}
	.pagination>li>a,.pagination>li>span {
		position:relative;
		float:left;
		padding:6px 12px;
		margin-left:-1px;
		line-height:1.42857143;
		color:#337ab7;
		text-decoration:none;
		background-color:#fff;
		border:1px solid #ddd
	}.pagination>li:first-child>span {
		margin-left:0;
		border-top-left-radius:4px;
		border-bottom-left-radius:4px
	}
	.pagination>li:last-child>a{
		border-top-right-radius:4px;
		border-bottom-right-radius:4px
	}
	.pagination>.active>a{
		z-index:2;
		color:#fff;
		cursor:default;
		background-color:#337ab7;
		border-color:#337ab7
	}
	.thumbnail {
		display:block;
		padding:4px;
		margin-bottom:20px;
		line-height:1.42857143;
		background-color:#fff;
		border:1px solid #ddd;
		border-radius:4px;
		-webkit-transition:border .2s ease-in-out;
		-o-transition:border .2s ease-in-out;
		transition:border .2s ease-in-out
	}.thumbnail>img {
		margin-right:auto;
		margin-left:auto
	}
	.thumbnail .caption {
		padding:9px;
		color:#333
	}
	.media-object {
		display:block
	}
	.close {
		float:right;
		font-size:21px;
		font-weight:700;
		line-height:1;
		color:#000;
		text-shadow:0 1px 0 #fff;
		filter:alpha(opacity=20);
		opacity:.2
	}
	button.close {
		-webkit-appearance:none;
		padding:0;
		cursor:pointer;
		background:0 0;
		border:0
	}
	.modal {
		position:fixed;
		top:0;
		right:0;
		bottom:0;
		left:0;
		z-index:1040;
		display:none;
		overflow:hidden;
		-webkit-overflow-scrolling:touch;
		outline:0
	}
	.modal.fade .modal-dialog {
		-webkit-transition:-webkit-transform .3s ease-out;
		-o-transition:-o-transform .3s ease-out;
		transition:transform .3s ease-out;
		-webkit-transform:translate(0,-25%);
		-ms-transform:translate(0,-25%);
		-o-transform:translate(0,-25%);
		transform:translate(0,-25%)
	}
	.modal-dialog {
		position:relative;
		width:auto;
		margin:10px
	}
	.modal-content {
		position:relative;
		background-color:#fff;
		-webkit-background-clip:padding-box;
		background-clip:padding-box;
		border:1px solid #999;
		border:1px solid rgba(0,0,0,.2);
		border-radius:6px;
		outline:0;
		-webkit-box-shadow:0 3px 9px rgba(0,0,0,.5);
		box-shadow:0 3px 9px rgba(0,0,0,.5)
	}
	.modal-header {
		min-height:16.43px;
		padding:15px;
		border-bottom:1px solid #e5e5e5
	}
	.modal-header .close {
		margin-top:-2px
	}
	.modal-title {
		margin:0;
		line-height:1.42857143
	}
	.modal-body {
		position:relative;
		padding:15px
	}
	.modal-footer {
		padding:15px;
		text-align:right;
		border-top:1px solid #e5e5e5
	}
	@media (min-width:768px) {
		.modal-dialog {
			width:600px;
			margin:30px auto
		}
		.modal-content {
			-webkit-box-shadow:0 5px 15px rgba(0,0,0,.5);
			box-shadow:0 5px 15px rgba(0,0,0,.5)
		}
	}.container-fluid:after,.container-fluid:before,.container:after,.container:before,.modal-footer:after,.modal-footer:before,.nav:after,.nav:before,.navbar-collapse:after,.navbar-collapse:before,.navbar-header:after,.navbar-header:before,.navbar:after,.navbar:before,.row:after,.row:before {
		display:table;
		content:" "
	}.container-fluid:after,.container:after,.modal-footer:after,.nav:after,.navbar-collapse:after,.navbar-header:after,.navbar:after,.row:after {
		clear:both
	}
	body,
	html{width:100%;height:100%;}
	body,
	h4{font-family:'Arial';/*font-weight:699;*/}
	.topnav{font-size:14px;}
	.input-lg{height:46px;padding:10px 16px;font-size:18px;line-height:1.33333;border-radius:1px;}
	.thumbnail img{margin-right:auto;margin-left:auto;}
	.thumbnail{display:block;max-width:100%;height:auto;}
	.thumbnail img{min-height:140px;height:140px;}
	.btn{border-radius:1px;}
	.btn-primary{width:49%;}
	.btn-warning{width:49%;}
	.thumbnail{border-radius:1px;}
	.scrollable-menu{height:auto;max-height:150px;overflow-x:hidden;}
	hr{border-color:#A1B5A4;}
	.scrollicon{text-align:center;text-decoration:none;width:40px;height:40px;background:#449d44;opacity:0.9;position:fixed;bottom:20px;right:25px;display:none;border:1px solid #5cb85c;z-index:100;margin:0;}
	.scrollicon div{font-weight:bold;font-size:28px;color:#fff;padding-top:0px;}
	@media(max-width:540px){.btn-primary{width:100%;margin-top:5px;}
	.btn-danger{width:100%;}
	.btn-warning{width:100%;}
	}
	@media (max-width:991px){.navbar-header{float:none;}
	.navbar-toggle{display:block;}
	.navbar-collapse{border-top:1px solid transparent;box-shadow:inset 0 1px 0 rgba(255,255,255,0.1);}
	.navbar-collapse.collapse{display:none!important;}
	.navbar-nav{float:none!important;margin:7.5px -15px;}
	.navbar-nav>li{float:none;}
	.navbar-nav>li>a{padding-top:10px;padding-bottom:10px;}
	}
	@media (max-width:1199px){.navbar-header{float:none;}
	.navbar-toggle{display:block;}
	.navbar-collapse{border-top:1px solid transparent;box-shadow:inset 0 1px 0 rgba(255,255,255,0.1);}
	.navbar-collapse.collapse{display:none!important;}
	.navbar-nav{float:none!important;margin:7.5px -15px;}
	.navbar-nav>li{float:none;}
	.navbar-nav>li>a{padding-top:10px;padding-bottom:10px;}
	}

	.fa {
		display:inline-block;
		font:normal normal normal 14px/1 FontAwesome;
		font-size:inherit;
		text-rendering:auto;
		-webkit-font-smoothing:antialiased;
		-moz-osx-font-smoothing:grayscale
	}
	.fa-arrow-circle-up:before {
		content:"\f0aa"
	}







	.pace {
	  -webkit-pointer-events: none;
	  pointer-events: none;

	  -webkit-user-select: none;
	  -moz-user-select: none;
	  user-select: none;
	}

	.pace .pace-progress {
	  background: #449D44;
	  position: fixed;
	  z-index: 2000;
	  top: 0;
	  right: 100%;
	  width: 100%;
	  height: 2px;
	}

	 .gefundo-color {
    color: #449d44;
  	}
	
.half {
    position:relative;
}
.font{
	font-size:6em;
}
.half:after {
    content:'';
    position:absolute;
    z-index:1;
    background:white;
    width: 50%;
    height: 100%;
    left: 47%;
}
  
	</style>
    <? 
    // Turn off all error reporting
    error_reporting(0);
    ?>
    
	<? if($page =="index"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Handyhülle 24 bietet eine große Auswahl an Handyhüllen. Finde deine passende Handyhülle für dein iPhone 6s, Galaxy S6 oder vielen weiteren Smartphones!">
	<meta name="keywords" content="Handyhülle, Handyhüllen, Handyschale, Handytasche, Schutzhülle">
    <meta name="author" content="handyhuelle24.de">
    <title>Handyhülle 24 | Finde deine passende Handyhülle online!</title>
	<?}?>

	<? if($page =="impressum"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="handyhuelle24.de">
	<meta name="robots" content="noindex, nofollow">
    <title>Handyhülle 24  | Impressum</title>
	<?}?>

	<? if($page =="kontakt"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="handyhuelle24.de">
    <title>Handyhülle 24  | Kontakt</title>
	<?}?>

	<? if($page =="handyhuelle-selbst-gestalten"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="handyhuelle24.de">
    <title>Handyhülle selbst gestalten | Handyhülle 24</title>
	<meta name="description" content="Handyhülle selbst gestalten! Du willst deine Handyhülle günstig selbst gestalten? Informiere dich hier über die Möglichkeiten und vergleiche Foto Anbieter.">

	<?}?>
	
<? if($page =="handyhuelle-fuer-deinen-style"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="handyhuelle24.de">
    <title>Welche Handyhülle pass zu deinen Style? | Handyhülle 24</title>
	<meta name="description" content="Welche Handyhülle pass zu deinen Style? Informiere dich hier über die verschiedenen Handyhüllen Arten und Formen und finde heraus welche Hülle zu dir passt!">

	<?}?>


	<? if($page =="datenschutzerklaerung"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="handyhuelle24.de">
	<meta name="robots" content="noindex, nofollow">
    <title>Handyhülle 24 | Datenschutzerklärung</title>
	<?}?>

	<? if($page =="sitemap"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="handyhuelle24.de">
    <title>Handyhülle 24  | Sitemap</title>
	<?}?>

	<? if($page =="result"){?>

    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
    	<meta name="author" content="handyhuelle24.de">

		<?if($_GET["search"] == "iphone-6"){
			$titel = "iPhone 6";
		}elseif($_GET["search"] == "iphone-6-plus"){$titel = "iPhone 6 Plus";
		}elseif($_GET["search"] == "iphone-5"){$titel = "iPhone 5";?>
			<? if (!$_GET["page"]){?>
				<link rel="canonical" href="http://handyhuelle24.de/iphone-5"/>
			<?}?>
		<?

		}elseif($_GET["search"] == "acer-liquid-jade-primo"){$titel ="ACER Liquid Jade Primo";
		}elseif($_GET["search"] == "acer-liquid-m320"){$titel ="Acer Liquid M320";
		}elseif($_GET["search"] == "acer-liquid-m330"){$titel ="Acer Liquid M330";
		}elseif($_GET["search"] == "acer-liquid-z320"){$titel ="Acer Liquid Z320";
		}elseif($_GET["search"] == "acer-liquid-z330"){$titel ="Acer Liquid Z330";
		}elseif($_GET["search"] == "acer-liquid-z410-plus"){$titel ="ACER Liquid Z410 Plus";
		}elseif($_GET["search"] == "acer-liquid-z530"){$titel ="Acer Liquid Z530";
		}elseif($_GET["search"] == "acer-liquid-z6"){$titel ="ACER Liquid Z6";
		}elseif($_GET["search"] == "acer-liquid-z6-plus"){$titel ="ACER Liquid Z6 Plus";
		}elseif($_GET["search"] == "acer-liquid-z630"){$titel ="Acer Liquid Z630";
		}elseif($_GET["search"] == "acer-liquid-z630s"){$titel ="Acer Liquid Z630S";
		}elseif($_GET["search"] == "acer-liquid-z6e"){$titel ="ACER Liquid Z6E";
		}elseif($_GET["search"] == "acer-liquid-zest"){$titel ="ACER Liquid Zest";
		}elseif($_GET["search"] == "acer-liquid-zest-plus"){$titel ="ACER Liquid Zest Plus";
		}elseif($_GET["search"] == "aeg-m1120"){$titel ="AEG M1120";
		}elseif($_GET["search"] == "aeg-m1250"){$titel ="AEG M1250";
		}elseif($_GET["search"] == "aeg-m1500"){$titel ="AEG M1500";
		}elseif($_GET["search"] == "aeg-m550"){$titel ="AEG M550";
		}elseif($_GET["search"] == "aeg-voxtel-m311"){$titel ="AEG Voxtel M311";
		}elseif($_GET["search"] == "aeg-voxtel-m320"){$titel ="AEG Voxtel M320";
		}elseif($_GET["search"] == "aeg-voxtel-m405"){$titel ="AEG Voxtel M405";
		}elseif($_GET["search"] == "aeg-voxtel-m410"){$titel ="AEG Voxtel M410";
		}elseif($_GET["search"] == "aeg-voxtel-sm250"){$titel ="AEG Voxtel SM250";
		}elseif($_GET["search"] == "aeg-voxtel-sm315"){$titel ="AEG Voxtel SM315";
		}elseif($_GET["search"] == "aeg-voxtel-sm420"){$titel ="AEG Voxtel SM420";
		}elseif($_GET["search"] == "alcatel-1c-dual-sim"){$titel ="Alcatel 1C Dual SIM";
		}elseif($_GET["search"] == "alcatel-1c-single-sim"){$titel ="Alcatel 1C Single SIM";
		}elseif($_GET["search"] == "alcatel-1t"){$titel ="Alcatel 1T";
		}elseif($_GET["search"] == "alcatel-1x"){$titel ="Alcatel 1X";
		}elseif($_GET["search"] == "alcatel-3"){$titel ="Alcatel 3";
		}elseif($_GET["search"] == "alcatel-3-2019"){$titel ="Alcatel 3 (2019";
		}elseif($_GET["search"] == "alcatel-3c"){$titel ="Alcatel 3C";
		}elseif($_GET["search"] == "alcatel-3l-2019"){$titel ="Alcatel 3L (2019";
		}elseif($_GET["search"] == "alcatel-3v"){$titel ="Alcatel 3V";
		}elseif($_GET["search"] == "alcatel-3x"){$titel ="Alcatel 3X";
		}elseif($_GET["search"] == "alcatel-5"){$titel ="Alcatel 5";
		}elseif($_GET["search"] == "alcatel-a3"){$titel ="Alcatel A3";
		}elseif($_GET["search"] == "alcatel-a3-xl"){$titel ="Alcatel A3 XL";
		}elseif($_GET["search"] == "alcatel-a30-plus"){$titel ="Alcatel A30 Plus";
		}elseif($_GET["search"] == "alcatel-a5-led"){$titel ="Alcatel A5 LED";
		}elseif($_GET["search"] == "alcatel-a50"){$titel ="Alcatel A50";
		}elseif($_GET["search"] == "alcatel-a7"){$titel ="Alcatel A7";
		}elseif($_GET["search"] == "alcatel-a7-xl"){$titel ="Alcatel A7 XL";
		}elseif($_GET["search"] == "alcatel-flash"){$titel ="Alcatel Flash";
		}elseif($_GET["search"] == "alcatel-idol-3c"){$titel ="Alcatel Idol 3c";
		}elseif($_GET["search"] == "alcatel-idol-4"){$titel ="Alcatel Idol 4";
		}elseif($_GET["search"] == "alcatel-idol-4-pro"){$titel ="Alcatel Idol 4 Pro";
		}elseif($_GET["search"] == "alcatel-idol-4s"){$titel ="Alcatel Idol 4S";
		}elseif($_GET["search"] == "alcatel-idol-5"){$titel ="Alcatel Idol 5";
		}elseif($_GET["search"] == "alcatel-idol-5s"){$titel ="Alcatel Idol 5S";
		}elseif($_GET["search"] == "alcatel-one-touch-go-play"){$titel ="Alcatel One Touch Go Play";
		}elseif($_GET["search"] == "alcatel-one-touch-idol-3"){$titel ="Alcatel One Touch Idol 3";
		}elseif($_GET["search"] == "alcatel-one-touch-idol-3-5-5-zoll"){$titel ="Alcatel One Touch Idol 3 (5,5 Zoll)";
		}elseif($_GET["search"] == "alcatel-one-touch-pop"){$titel ="Alcatel One Touch Pop";
		}elseif($_GET["search"] == "alcatel-one-touch-pop-4"){$titel ="Alcatel One Touch Pop 4";
		}elseif($_GET["search"] == "alcatel-one-touch-pop-4plus"){$titel ="Alcatel One Touch Pop 4+";
		}elseif($_GET["search"] == "alcatel-one-touch-pop-4s"){$titel ="Alcatel One Touch Pop 4S";
		}elseif($_GET["search"] == "alcatel-onetouch-pop-star"){$titel ="Alcatel Onetouch Pop Star";
		}elseif($_GET["search"] == "alcatel-onetouch-pop-up"){$titel ="Alcatel Onetouch Pop Up";
		}elseif($_GET["search"] == "alcatel-pixi-3"){$titel ="Alcatel Pixi 3";
		}elseif($_GET["search"] == "alcatel-pixi-4"){$titel ="Alcatel Pixi 4";
		}elseif($_GET["search"] == "alcatel-pixi-first"){$titel ="Alcatel Pixi First";
		}elseif($_GET["search"] == "alcatel-shine-lite"){$titel ="Alcatel Shine Lite";
		}elseif($_GET["search"] == "alcatel-u5"){$titel ="Alcatel U5";
		}elseif($_GET["search"] == "alcatel-u5-hd-dual-sim"){$titel ="Alcatel U5 HD Dual SIM";
		}elseif($_GET["search"] == "alcatel-u5-hd-single-sim"){$titel ="Alcatel U5 HD Single SIM";
		}elseif($_GET["search"] == "alcatel-lucent-1t-10"){$titel ="Alcatel-Lucent 1T 10";
		}elseif($_GET["search"] == "allview-a9-lite"){$titel ="Allview A9 Lite";
		}elseif($_GET["search"] == "allview-a9-plus"){$titel ="Allview A9 Plus";
		}elseif($_GET["search"] == "allview-e3-living"){$titel ="Allview E3 Living";
		}elseif($_GET["search"] == "allview-e4"){$titel ="Allview E4";
		}elseif($_GET["search"] == "allview-e4-lite"){$titel ="Allview E4 Lite";
		}elseif($_GET["search"] == "allview-p4-emagic"){$titel ="Allview P4 EMagic";
		}elseif($_GET["search"] == "allview-p4-pro"){$titel ="Allview P4 Pro";
		}elseif($_GET["search"] == "allview-p42"){$titel ="Allview P42";
		}elseif($_GET["search"] == "allview-p5-emagic"){$titel ="Allview P5 EMagic";
		}elseif($_GET["search"] == "allview-p5-energy"){$titel ="Allview P5 Energy";
		}elseif($_GET["search"] == "allview-p5-lite"){$titel ="Allview P5 Lite";
		}elseif($_GET["search"] == "allview-p6-emagic"){$titel ="Allview P6 EMagic";
		}elseif($_GET["search"] == "allview-p6-energy-lite"){$titel ="Allview P6 Energy Lite";
		}elseif($_GET["search"] == "allview-p6-energy-mini"){$titel ="Allview P6 Energy Mini";
		}elseif($_GET["search"] == "allview-p6-lite"){$titel ="Allview P6 Lite";
		}elseif($_GET["search"] == "allview-p6-plus"){$titel ="Allview P6 Plus";
		}elseif($_GET["search"] == "allview-p6-pro"){$titel ="Allview P6 Pro";
		}elseif($_GET["search"] == "allview-p6-qmax"){$titel ="Allview P6 Qmax";
		}elseif($_GET["search"] == "allview-p7-lite"){$titel ="Allview P7 Lite";
		}elseif($_GET["search"] == "allview-p7-pro"){$titel ="Allview P7 Pro";
		}elseif($_GET["search"] == "allview-p8-emagic"){$titel ="Allview P8 EMagic";
		}elseif($_GET["search"] == "allview-p8-energy"){$titel ="Allview P8 Energy";
		}elseif($_GET["search"] == "allview-p8-energy-mini"){$titel ="Allview P8 Energy Mini";
		}elseif($_GET["search"] == "allview-p8-energy-pro"){$titel ="Allview P8 Energy Pro";
		}elseif($_GET["search"] == "allview-p8-pro"){$titel ="Allview P8 Pro";
		}elseif($_GET["search"] == "allview-p9-energy"){$titel ="Allview P9 Energy";
		}elseif($_GET["search"] == "allview-p9-energy-lite"){$titel ="Allview P9 Energy Lite";
		}elseif($_GET["search"] == "allview-p9-energy-lite-2017"){$titel ="Allview P9 Energy Lite (2017)";
		}elseif($_GET["search"] == "allview-p9-energy-mini"){$titel ="Allview P9 Energy Mini";
		}elseif($_GET["search"] == "allview-soul-x5"){$titel ="Allview Soul X5";
		}elseif($_GET["search"] == "allview-soul-x5-pro"){$titel ="Allview Soul X5 Pro";
		}elseif($_GET["search"] == "allview-soul-x5-style"){$titel ="Allview Soul X5 Style";
		}elseif($_GET["search"] == "allview-v1-viper-l"){$titel ="Allview V1 Viper L";
		}elseif($_GET["search"] == "allview-v2-viper-e"){$titel ="Allview V2 Viper E";
		}elseif($_GET["search"] == "allview-v2-viper-i4g"){$titel ="Allview V2 Viper I4G";
		}elseif($_GET["search"] == "allview-v2-viper-s"){$titel ="Allview V2 Viper S";
		}elseif($_GET["search"] == "allview-v2-viper-xplus"){$titel ="Allview V2 Viper X+";
		}elseif($_GET["search"] == "allview-v2-viper-xe"){$titel ="Allview V2 Viper XE";
		}elseif($_GET["search"] == "allview-v3-viper"){$titel ="Allview V3 Viper";
		}elseif($_GET["search"] == "allview-viva-h7-extreme"){$titel ="Allview Viva H7 Extreme";
		}elseif($_GET["search"] == "allview-w1-i"){$titel ="Allview W1 I";
		}elseif($_GET["search"] == "allview-x2-soul-lite"){$titel ="Allview X2 Soul Lite";
		}elseif($_GET["search"] == "allview-x2-soul-pro"){$titel ="Allview X2 Soul Pro";
		}elseif($_GET["search"] == "allview-x3-soul"){$titel ="Allview X3 Soul";
		}elseif($_GET["search"] == "allview-x3-soul-lite"){$titel ="Allview X3 Soul Lite";
		}elseif($_GET["search"] == "allview-x3-soul-mini"){$titel ="Allview X3 Soul Mini";
		}elseif($_GET["search"] == "allview-x3-soul-plus"){$titel ="Allview X3 Soul Plus";
		}elseif($_GET["search"] == "allview-x3-soul-pro"){$titel ="Allview X3 Soul Pro";
		}elseif($_GET["search"] == "allview-x3-soul-style"){$titel ="Allview X3 Soul Style";
		}elseif($_GET["search"] == "allview-x4-soul"){$titel ="Allview X4 Soul";
		}elseif($_GET["search"] == "allview-x4-soul-infinity-l"){$titel ="Allview X4 Soul Infinity L";
		}elseif($_GET["search"] == "allview-x4-soul-infinity-n"){$titel ="Allview X4 Soul Infinity N";
		}elseif($_GET["search"] == "allview-x4-soul-infinity-plus"){$titel ="Allview X4 Soul Infinity Plus";
		}elseif($_GET["search"] == "allview-x4-soul-infinity-s"){$titel ="Allview X4 Soul Infinity S";
		}elseif($_GET["search"] == "allview-x4-soul-infinity-z"){$titel ="Allview X4 Soul Infinity Z";
		}elseif($_GET["search"] == "allview-x4-soul-lite"){$titel ="Allview X4 Soul Lite";
		}elseif($_GET["search"] == "allview-x4-soul-mini"){$titel ="Allview X4 Soul Mini";
		}elseif($_GET["search"] == "allview-x4-soul-mini-s"){$titel ="Allview X4 Soul Mini S";
		}elseif($_GET["search"] == "allview-x4-soul-style"){$titel ="Allview X4 Soul Style";
		}elseif($_GET["search"] == "allview-x4-xtreme"){$titel ="Allview X4 Xtreme";
		}elseif($_GET["search"] == "amazon-fire-7"){$titel ="Amazon Fire 7";
		}elseif($_GET["search"] == "amazon-fire-hd-10-2017"){$titel ="Amazon Fire HD 10 (2017)";
		}elseif($_GET["search"] == "amazon-fire-hd-10-kids-edition-2018"){$titel ="Amazon Fire HD 10 Kids Edition (2018)";
		}elseif($_GET["search"] == "amazon-fire-hd-8-2017"){$titel ="Amazon Fire HD 8 (2017)";
		}elseif($_GET["search"] == "amazon-fire-hd-8-2018"){$titel ="Amazon Fire HD 8 (2018)";
		}elseif($_GET["search"] == "apple-iphone-8"){$titel ="Apple IPhone 8";
		}elseif($_GET["search"] == "apple-iphone-8-plus"){$titel ="Apple IPhone 8 Plus";
		}elseif($_GET["search"] == "apple-iphone-se-2"){$titel ="Apple IPhone SE 2";
		}elseif($_GET["search"] == "apple-iphone-x"){$titel ="Apple IPhone X";
		}elseif($_GET["search"] == "apple-iphone-xi"){$titel ="Apple IPhone XI";
		}elseif($_GET["search"] == "apple-iphone-xs"){$titel ="Apple IPhone XS";
		}elseif($_GET["search"] == "apple-iphone-xs-max"){$titel ="Apple IPhone XS Max";
		}elseif($_GET["search"] == "archos-40-helium"){$titel ="Archos 40 Helium";
		}elseif($_GET["search"] == "archos-40-neon"){$titel ="Archos 40 Neon";
		}elseif($_GET["search"] == "archos-40-power"){$titel ="Archos 40 Power";
		}elseif($_GET["search"] == "archos-45-neon"){$titel ="Archos 45 Neon";
		}elseif($_GET["search"] == "archos-45b-neon"){$titel ="Archos 45b Neon";
		}elseif($_GET["search"] == "archos-45d-platinum"){$titel ="Archos 45d Platinum";
		}elseif($_GET["search"] == "archos-50-cesium"){$titel ="Archos 50 Cesium";
		}elseif($_GET["search"] == "archos-50-cobalt"){$titel ="Archos 50 Cobalt";
		}elseif($_GET["search"] == "archos-50-diamond"){$titel ="Archos 50 Diamond";
		}elseif($_GET["search"] == "archos-50-graphite"){$titel ="Archos 50 Graphite";
		}elseif($_GET["search"] == "archos-50-heliumplus"){$titel ="Archos 50 Helium+";
		}elseif($_GET["search"] == "archos-50-power"){$titel ="Archos 50 Power";
		}elseif($_GET["search"] == "archos-50-saphir"){$titel ="Archos 50 Saphir";
		}elseif($_GET["search"] == "archos-50-titanium-4g"){$titel ="Archos 50 Titanium 4G";
		}elseif($_GET["search"] == "archos-50b-cobalt-lite"){$titel ="Archos 50b Cobalt Lite";
		}elseif($_GET["search"] == "archos-50c-platinum"){$titel ="Archos 50c Platinum";
		}elseif($_GET["search"] == "archos-50d-neon"){$titel ="Archos 50d Neon";
		}elseif($_GET["search"] == "archos-50d-oxygen"){$titel ="Archos 50d Oxygen";
		}elseif($_GET["search"] == "archos-50e-helium"){$titel ="Archos 50e Helium";
		}elseif($_GET["search"] == "archos-50e-neon"){$titel ="Archos 50e Neon";
		}elseif($_GET["search"] == "archos-50f-helium"){$titel ="Archos 50f Helium";
		}elseif($_GET["search"] == "archos-50f-neon"){$titel ="Archos 50f Neon";
		}elseif($_GET["search"] == "archos-55-cobaltplus"){$titel ="Archos 55 Cobalt+";
		}elseif($_GET["search"] == "archos-55-diamond-selfie"){$titel ="Archos 55 Diamond Selfie";
		}elseif($_GET["search"] == "archos-55-diamond-selfie-lite"){$titel ="Archos 55 Diamond Selfie Lite";
		}elseif($_GET["search"] == "archos-55-graphite"){$titel ="Archos 55 Graphite";
		}elseif($_GET["search"] == "archos-55-helium"){$titel ="Archos 55 Helium";
		}elseif($_GET["search"] == "archos-55-helium-4seasons"){$titel ="Archos 55 Helium 4Seasons";
		}elseif($_GET["search"] == "archos-55-helium-ultra"){$titel ="Archos 55 Helium Ultra";
		}elseif($_GET["search"] == "archos-55-heliumplus"){$titel ="Archos 55 Helium+";
		}elseif($_GET["search"] == "archos-55-platinum"){$titel ="Archos 55 Platinum";
		}elseif($_GET["search"] == "archos-55b-cobalt-lite"){$titel ="Archos 55b Cobalt Lite";
		}elseif($_GET["search"] == "archos-55b-platinum"){$titel ="Archos 55b Platinum";
		}elseif($_GET["search"] == "archos-access-45"){$titel ="Archos Access 45";
		}elseif($_GET["search"] == "archos-access-50"){$titel ="Archos Access 50";
		}elseif($_GET["search"] == "archos-access-55"){$titel ="Archos Access 55";
		}elseif($_GET["search"] == "archos-access-57"){$titel ="Archos Access 57";
		}elseif($_GET["search"] == "archos-core-50"){$titel ="Archos Core 50";
		}elseif($_GET["search"] == "archos-core-50p"){$titel ="Archos Core 50P";
		}elseif($_GET["search"] == "archos-core-55"){$titel ="Archos Core 55";
		}elseif($_GET["search"] == "archos-core-55p"){$titel ="Archos Core 55P";
		}elseif($_GET["search"] == "archos-core-55s"){$titel ="Archos Core 55S";
		}elseif($_GET["search"] == "archos-core-57s"){$titel ="Archos Core 57S";
		}elseif($_GET["search"] == "archos-core-60s"){$titel ="Archos Core 60S";
		}elseif($_GET["search"] == "archos-diamond-2-note"){$titel ="Archos Diamond 2 Note";
		}elseif($_GET["search"] == "archos-diamond-2-plus"){$titel ="Archos Diamond 2 Plus";
		}elseif($_GET["search"] == "archos-diamond-2019"){$titel ="Archos Diamond 2019";
		}elseif($_GET["search"] == "archos-diamond-alpha"){$titel ="Archos Diamond Alpha";
		}elseif($_GET["search"] == "archos-diamond-alphaplus"){$titel ="Archos Diamond Alpha+";
		}elseif($_GET["search"] == "archos-diamond-gamma"){$titel ="Archos Diamond Gamma";
		}elseif($_GET["search"] == "archos-diamond-plus"){$titel ="Archos Diamond Plus";
		}elseif($_GET["search"] == "archos-diamond-s"){$titel ="Archos Diamond S";
		}elseif($_GET["search"] == "archos-oxygen-57"){$titel ="Archos Oxygen 57";
		}elseif($_GET["search"] == "archos-oxygen-63"){$titel ="Archos Oxygen 63";
		}elseif($_GET["search"] == "archos-oxygen-63xl"){$titel ="Archos Oxygen 63XL";
		}elseif($_GET["search"] == "archos-saphir-50x"){$titel ="Archos Saphir 50X";
		}elseif($_GET["search"] == "archos-sense-47x"){$titel ="Archos Sense 47X";
		}elseif($_GET["search"] == "archos-sense-50-x"){$titel ="Archos Sense 50 X";
		}elseif($_GET["search"] == "archos-sense-55-s"){$titel ="Archos Sense 55 S";
		}elseif($_GET["search"] == "ascend-g525"){$titel ="Ascend G525";
		}elseif($_GET["search"] == "ascend-g6"){$titel ="Ascend G6";
		}elseif($_GET["search"] == "ascend-g610"){$titel ="Ascend G610";
		}elseif($_GET["search"] == "ascend-g620s"){$titel ="Ascend G620s";
		}elseif($_GET["search"] == "ascend-g630"){$titel ="Ascend G630";
		}elseif($_GET["search"] == "ascend-g7"){$titel ="Ascend G7";
		}elseif($_GET["search"] == "ascend-g730"){$titel ="Ascend G730";
		}elseif($_GET["search"] == "ascend-mate-7"){$titel ="Ascend Mate 7";
		}elseif($_GET["search"] == "ascend-mate7"){$titel ="Ascend Mate7";
		}elseif($_GET["search"] == "ascend-p6"){$titel ="Ascend P6";
		}elseif($_GET["search"] == "ascend-p7"){$titel ="Ascend P7";
		}elseif($_GET["search"] == "ascend-p7-mini"){$titel ="Ascend P7 Mini";
		}elseif($_GET["search"] == "ascend-y300"){$titel ="Ascend Y300";
		}elseif($_GET["search"] == "ascend-y330"){$titel ="Ascend Y330";
		}elseif($_GET["search"] == "ascend-y530"){$titel ="Ascend Y530";
		}elseif($_GET["search"] == "ascend-y540"){$titel ="Ascend Y540";
		}elseif($_GET["search"] == "ascend-y550"){$titel ="Ascend Y550";
		}elseif($_GET["search"] == "ascend-y600"){$titel ="Ascend Y600";
		}elseif($_GET["search"] == "asus-rog-phone"){$titel ="Asus ROG Phone";
		}elseif($_GET["search"] == "asus-zenfone-2"){$titel ="Asus ZenFone 2";
		}elseif($_GET["search"] == "asus-zenfone-2-deluxe"){$titel ="Asus ZenFone 2 Deluxe";
		}elseif($_GET["search"] == "asus-zenfone-2-laser"){$titel ="Asus ZenFone 2 Laser";
		}elseif($_GET["search"] == "asus-zenfone-2-ze551ml"){$titel ="Asus ZenFone 2 ZE551ML";
		}elseif($_GET["search"] == "asus-zenfone-3"){$titel ="Asus ZenFone 3";
		}elseif($_GET["search"] == "asus-zenfone-3-deluxe"){$titel ="Asus ZenFone 3 Deluxe";
		}elseif($_GET["search"] == "asus-zenfone-3-deluxe-zs550kl"){$titel ="Asus ZenFone 3 Deluxe (ZS550KL)";
		}elseif($_GET["search"] == "asus-zenfone-3-laser"){$titel ="Asus ZenFone 3 Laser";
		}elseif($_GET["search"] == "asus-zenfone-3-max-zc520tl"){$titel ="Asus ZenFone 3 Max (ZC520TL)";
		}elseif($_GET["search"] == "asus-zenfone-3-ze520kl"){$titel ="Asus ZenFone 3 ZE520KL";
		}elseif($_GET["search"] == "asus-zenfone-4"){$titel ="Asus Zenfone 4";
		}elseif($_GET["search"] == "asus-zenfone-4-max"){$titel ="Asus ZenFone 4 Max";
		}elseif($_GET["search"] == "asus-zenfone-4-selfie-pro"){$titel ="Asus ZenFone 4 Selfie Pro";
		}elseif($_GET["search"] == "asus-zenfone-5-2018"){$titel ="Asus ZenFone 5 (2018)";
		}elseif($_GET["search"] == "asus-zenfone-5z"){$titel ="Asus ZenFone 5Z";
		}elseif($_GET["search"] == "asus-zenfone-ar"){$titel ="Asus ZenFone AR";
		}elseif($_GET["search"] == "asus-zenfone-go"){$titel ="Asus ZenFone Go";
		}elseif($_GET["search"] == "asus-zenfone-go-zb500kl"){$titel ="Asus ZenFone Go (ZB500KL)";
		}elseif($_GET["search"] == "asus-zenfone-go-tv"){$titel ="Asus ZenFone Go TV";
		}elseif($_GET["search"] == "asus-zenfone-live"){$titel ="Asus ZenFone Live";
		}elseif($_GET["search"] == "asus-zenfone-max"){$titel ="Asus ZenFone Max";
		}elseif($_GET["search"] == "asus-zenfone-max-m2"){$titel ="Asus Zenfone Max (M2)";
		}elseif($_GET["search"] == "asus-zenfone-max-plus-m1"){$titel ="Asus ZenFone Max Plus (M1)";
		}elseif($_GET["search"] == "asus-zenfone-max-pro-m2"){$titel ="Asus Zenfone Max Pro (M2)";
		}elseif($_GET["search"] == "asus-zenfone-selfie"){$titel ="Asus ZenFone Selfie";
		}elseif($_GET["search"] == "asus-zoom"){$titel ="Asus Zoom";
		}elseif($_GET["search"] == "asus:-zenfone-selfie-zd551kl"){$titel ="Asus: ZenFone Selfie ZD551KL";
		}elseif($_GET["search"] == "bea-fon-al250"){$titel ="Bea-fon AL250";
		}elseif($_GET["search"] == "bea-fon-al450"){$titel ="Bea-fon AL450";
		}elseif($_GET["search"] == "bea-fon-al550"){$titel ="Bea-fon AL550";
		}elseif($_GET["search"] == "bea-fon-c130"){$titel ="Bea-fon C130";
		}elseif($_GET["search"] == "bea-fon-c140"){$titel ="Bea-fon C140";
		}elseif($_GET["search"] == "bea-fon-c150"){$titel ="Bea-fon C150";
		}elseif($_GET["search"] == "bea-fon-c20"){$titel ="Bea-fon C20";
		}elseif($_GET["search"] == "bea-fon-c200"){$titel ="Bea-fon C200";
		}elseif($_GET["search"] == "bea-fon-c240"){$titel ="Bea-fon C240";
		}elseif($_GET["search"] == "bea-fon-c260"){$titel ="Bea-fon C260";
		}elseif($_GET["search"] == "bea-fon-c30"){$titel ="Bea-fon C30";
		}elseif($_GET["search"] == "bea-fon-c40"){$titel ="Bea-fon C40";
		}elseif($_GET["search"] == "bea-fon-c400"){$titel ="Bea-fon C400";
		}elseif($_GET["search"] == "bea-fon-c50"){$titel ="Bea-fon C50";
		}elseif($_GET["search"] == "bea-fon-c60"){$titel ="Bea-fon C60";
		}elseif($_GET["search"] == "bea-fon-sl150"){$titel ="Bea-fon SL150";
		}elseif($_GET["search"] == "bea-fon-sl240"){$titel ="Bea-fon SL240";
		}elseif($_GET["search"] == "bea-fon-sl250"){$titel ="Bea-fon SL250";
		}elseif($_GET["search"] == "bea-fon-sl340"){$titel ="Bea-fon SL340";
		}elseif($_GET["search"] == "bea-fon-sl340i"){$titel ="Bea-fon SL340i";
		}elseif($_GET["search"] == "bea-fon-sl470"){$titel ="Bea-fon SL470";
		}elseif($_GET["search"] == "bea-fon-sl480"){$titel ="Bea-fon SL480";
		}elseif($_GET["search"] == "bea-fon-sl570"){$titel ="Bea-fon SL570";
		}elseif($_GET["search"] == "bea-fon-sl580"){$titel ="Bea-fon SL580";
		}elseif($_GET["search"] == "bea-fon-sl670"){$titel ="Bea-fon SL670";
		}elseif($_GET["search"] == "bea-fon-sl820"){$titel ="Bea-fon SL820";
		}elseif($_GET["search"] == "bestore-star-note-5-n5d-n9200"){$titel ="Bestore Star Note 5 N5D N9200";
		}elseif($_GET["search"] == "bestore-z5"){$titel ="Bestore Z5";
		}elseif($_GET["search"] == "bestore-z6"){$titel ="Bestore Z6";
		}elseif($_GET["search"] == "blackberry-aurora"){$titel ="BlackBerry Aurora";
		}elseif($_GET["search"] == "blackberry-classic"){$titel ="Blackberry Classic";
		}elseif($_GET["search"] == "blackberry-dtek50"){$titel ="Blackberry DTEK50";
		}elseif($_GET["search"] == "blackberry-dtek60"){$titel ="Blackberry DTEK60";
		}elseif($_GET["search"] == "blackberry-key-2-le"){$titel ="Blackberry Key 2 LE";
		}elseif($_GET["search"] == "blackberry-key-2-le-dual-sim"){$titel ="Blackberry Key 2 LE Dual-SIM";
		}elseif($_GET["search"] == "blackberry-key2"){$titel ="Blackberry KEY2";
		}elseif($_GET["search"] == "blackberry-key2-dual-sim"){$titel ="Blackberry KEY2 (Dual-SIM)";
		}elseif($_GET["search"] == "blackberry-key2-red-edition"){$titel ="Blackberry KEY2 Red Edition";
		}elseif($_GET["search"] == "blackberry-keyone"){$titel ="BlackBerry KEYone";
		}elseif($_GET["search"] == "blackberry-keyone-black-edition"){$titel ="Blackberry KEYone Black Edition";
		}elseif($_GET["search"] == "blackberry-keyone-bronze-edition"){$titel ="Blackberry KEYone Bronze Edition";
		}elseif($_GET["search"] == "blackberry-leap"){$titel ="Blackberry Leap";
		}elseif($_GET["search"] == "blackberry-luna"){$titel ="BlackBerry Luna";
		}elseif($_GET["search"] == "blackberry-motion"){$titel ="Blackberry Motion";
		}elseif($_GET["search"] == "blackberry-p9982-porsche-design"){$titel ="Blackberry P9982 Porsche Design";
		}elseif($_GET["search"] == "blackberry-passport"){$titel ="Blackberry Passport";
		}elseif($_GET["search"] == "blackberry-priv"){$titel ="Blackberry Priv";
		}elseif($_GET["search"] == "blackberry-q10"){$titel ="Blackberry Q10";
		}elseif($_GET["search"] == "blackberry-q5"){$titel ="Blackberry Q5";
		}elseif($_GET["search"] == "blackberry-samoa-9720"){$titel ="Blackberry Samoa 9720";
		}elseif($_GET["search"] == "blackberry-z30"){$titel ="Blackberry Z30";
		}elseif($_GET["search"] == "blackview-a7"){$titel ="Blackview A7";
		}elseif($_GET["search"] == "blackview-bv-5000"){$titel ="Blackview BV 5000";
		}elseif($_GET["search"] == "blackview-bv4000"){$titel ="Blackview BV4000";
		}elseif($_GET["search"] == "blackview-bv8000-pro"){$titel ="Blackview BV8000 Pro";
		}elseif($_GET["search"] == "blackview-bv9000-pro"){$titel ="Blackview BV9000 Pro";
		}elseif($_GET["search"] == "blackview-e7"){$titel ="Blackview E7";
		}elseif($_GET["search"] == "blackview-p2"){$titel ="Blackview P2";
		}elseif($_GET["search"] == "blackview-p6"){$titel ="Blackview P6";
		}elseif($_GET["search"] == "blackview-p6000"){$titel ="Blackview P6000";
		}elseif($_GET["search"] == "blaupunkt-atlantis-a10"){$titel ="Blaupunkt Atlantis A10";
		}elseif($_GET["search"] == "blaupunkt-sl-01"){$titel ="Blaupunkt SL 01";
		}elseif($_GET["search"] == "blaupunkt-sl-04"){$titel ="Blaupunkt SL 04";
		}elseif($_GET["search"] == "blaupunkt-sl-plus-02"){$titel ="Blaupunkt SL Plus 02";
		}elseif($_GET["search"] == "blaupunkt-sl02"){$titel ="Blaupunkt SL02";
		}elseif($_GET["search"] == "blu-vivo-5"){$titel ="Blu Vivo 5";
		}elseif($_GET["search"] == "blu-vivo-xl"){$titel ="Blu Vivo XL";
		}elseif($_GET["search"] == "bluboo-d5-pro"){$titel ="Bluboo D5 Pro";
		}elseif($_GET["search"] == "bluboo-dual"){$titel ="Bluboo Dual";
		}elseif($_GET["search"] == "bluboo-edge"){$titel ="Bluboo Edge";
		}elseif($_GET["search"] == "bluboo-maya"){$titel ="Bluboo Maya";
		}elseif($_GET["search"] == "bluboo-maya-max"){$titel ="Bluboo Maya Max";
		}elseif($_GET["search"] == "bluboo-s1"){$titel ="Bluboo S1";
		}elseif($_GET["search"] == "bluboo-s8"){$titel ="Bluboo S8";
		}elseif($_GET["search"] == "bluboo-s8plus"){$titel ="Bluboo S8+";
		}elseif($_GET["search"] == "bq-aquaris-c"){$titel ="BQ Aquaris C";
		}elseif($_GET["search"] == "bq-aquaris-e4"){$titel ="BQ Aquaris E4";
		}elseif($_GET["search"] == "bq-aquaris-e5s"){$titel ="BQ Aquaris E5s";
		}elseif($_GET["search"] == "bq-aquaris-e6"){$titel ="BQ Aquaris E6";
		}elseif($_GET["search"] == "bq-aquaris-m-2017"){$titel ="BQ Aquaris M 2017";
		}elseif($_GET["search"] == "bq-aquaris-m-4-5"){$titel ="BQ Aquaris M 4.5";
		}elseif($_GET["search"] == "bq-aquaris-m5-5"){$titel ="BQ Aquaris M5.5";
		}elseif($_GET["search"] == "bq-aquaris-u"){$titel ="BQ Aquaris U";
		}elseif($_GET["search"] == "bq-aquaris-u-lite"){$titel ="BQ Aquaris U Lite";
		}elseif($_GET["search"] == "bq-aquaris-u-plus"){$titel ="BQ Aquaris U Plus";
		}elseif($_GET["search"] == "bq-aquaris-vs"){$titel ="BQ Aquaris VS";
		}elseif($_GET["search"] == "bq-aquaris-vs-plus"){$titel ="BQ Aquaris VS Plus";
		}elseif($_GET["search"] == "bq-aquaris-x"){$titel ="BQ Aquaris X";
		}elseif($_GET["search"] == "bq-aquaris-x-pro"){$titel ="BQ Aquaris X Pro";
		}elseif($_GET["search"] == "bq-aquaris-x2"){$titel ="BQ Aquaris X2";
		}elseif($_GET["search"] == "bq-aquaris-x2-pro"){$titel ="BQ Aquaris X2 Pro";
		}elseif($_GET["search"] == "bq-aquaris-x5"){$titel ="BQ Aquaris X5";
		}elseif($_GET["search"] == "bq-aquaris-x5-cyanogen-edition"){$titel ="BQ Aquaris X5 Cyanogen Edition";
		}elseif($_GET["search"] == "bq-aquaris-x5-plus"){$titel ="BQ Aquaris X5 Plus";
		}elseif($_GET["search"] == "bq-aquarius-e5"){$titel ="BQ Aquarius E5";
		}elseif($_GET["search"] == "bq-aquarius-m5"){$titel ="BQ Aquarius M5";
		}elseif($_GET["search"] == "bq-readers-aquaris-a4-5"){$titel ="BQ Readers Aquaris A4.5";
		}elseif($_GET["search"] == "bq-readers-aquaris-x5-cyanogen"){$titel ="BQ Readers Aquaris X5 Cyanogen";
		}elseif($_GET["search"] == "bq-readers-aquaris-x5-plus"){$titel ="BQ Readers Aquaris X5 Plus";
		}elseif($_GET["search"] == "bq-readers-aquarius-e5-hd"){$titel ="BQ Readers Aquarius E5 HD";
		}elseif($_GET["search"] == "cat-b100"){$titel ="Cat B100";
		}elseif($_GET["search"] == "cat-b25"){$titel ="Cat B25";
		}elseif($_GET["search"] == "cat-b30"){$titel ="Cat B30";
		}elseif($_GET["search"] == "cat-s30"){$titel ="Cat S30";
		}elseif($_GET["search"] == "cat-s40"){$titel ="Cat S40";
		}elseif($_GET["search"] == "cat-s60"){$titel ="Cat S60";
		}elseif($_GET["search"] == "caterpillar-cat-b30-dual-sim"){$titel ="Caterpillar Cat B30 Dual SIM";
		}elseif($_GET["search"] == "caterpillar-cat-s31"){$titel ="Caterpillar Cat S31";
		}elseif($_GET["search"] == "caterpillar-cat-s41"){$titel ="Caterpillar Cat S41";
		}elseif($_GET["search"] == "caterpillar-cat-s41-dual-sim"){$titel ="Caterpillar Cat S41 Dual-SIM";
		}elseif($_GET["search"] == "caterpillar-cat-s61"){$titel ="Caterpillar Cat S61";
		}elseif($_GET["search"] == "commodore-pet"){$titel ="Commodore PET";
		}elseif($_GET["search"] == "coolpad-cool-s1"){$titel ="Coolpad Cool S1";
		}elseif($_GET["search"] == "coolpad-max"){$titel ="Coolpad Max";
		}elseif($_GET["search"] == "coolpad-modena"){$titel ="Coolpad Modena";
		}elseif($_GET["search"] == "coolpad-modena-2"){$titel ="Coolpad Modena 2";
		}elseif($_GET["search"] == "coolpad-porto"){$titel ="Coolpad Porto";
		}elseif($_GET["search"] == "coolpad-porto-s"){$titel ="Coolpad Porto S";
		}elseif($_GET["search"] == "coolpad-torino"){$titel ="Coolpad Torino";
		}elseif($_GET["search"] == "coolpad-torino-s"){$titel ="Coolpad Torino S";
		}elseif($_GET["search"] == "crosscall-action-x3"){$titel ="Crosscall Action-X3";
		}elseif($_GET["search"] == "crosscall-core-x3"){$titel ="Crosscall Core-X3";
		}elseif($_GET["search"] == "crosscall-shark-x3"){$titel ="Crosscall Shark X3";
		}elseif($_GET["search"] == "crosscall-spider-x1"){$titel ="Crosscall Spider X1";
		}elseif($_GET["search"] == "crosscall-spider-x4"){$titel ="Crosscall Spider X4";
		}elseif($_GET["search"] == "crosscall-trekker-m1"){$titel ="Crosscall Trekker M1";
		}elseif($_GET["search"] == "crosscall-trekker-x3"){$titel ="Crosscall Trekker X3";
		}elseif($_GET["search"] == "crosscall-trekker-m1-core"){$titel ="Crosscall Trekker-M1 Core";
		}elseif($_GET["search"] == "crosscall-trekker-x4"){$titel ="Crosscall Trekker-X4";
		}elseif($_GET["search"] == "cubot-cheetahphone"){$titel ="Cubot Cheetahphone";
		}elseif($_GET["search"] == "cubot-h1"){$titel ="Cubot H1";
		}elseif($_GET["search"] == "cubot-h2"){$titel ="Cubot H2";
		}elseif($_GET["search"] == "cubot-h3-2018"){$titel ="Cubot H3 (2018)";
		}elseif($_GET["search"] == "cubot-max"){$titel ="Cubot Max";
		}elseif($_GET["search"] == "cubot-p11"){$titel ="Cubot P11";
		}elseif($_GET["search"] == "cubot-p201"){$titel ="Cubot P201";
		}elseif($_GET["search"] == "cubot-s500"){$titel ="Cubot S500";
		}elseif($_GET["search"] == "cubot-s600"){$titel ="Cubot S600";
		}elseif($_GET["search"] == "cubot-x12"){$titel ="Cubot X12";
		}elseif($_GET["search"] == "cubot-x15"){$titel ="Cubot X15";
		}elseif($_GET["search"] == "cubot-x16"){$titel ="Cubot X16";
		}elseif($_GET["search"] == "cubot-x18-2017"){$titel ="Cubot X18 (2017)";
		}elseif($_GET["search"] == "cubot-x9"){$titel ="Cubot X9";
		}elseif($_GET["search"] == "cubot-z100"){$titel ="Cubot Z100";
		}elseif($_GET["search"] == "cyrus-cm-1"){$titel ="Cyrus CM 1";
		}elseif($_GET["search"] == "cyrus-cm-15"){$titel ="Cyrus CM 15";
		}elseif($_GET["search"] == "cyrus-cm-16"){$titel ="Cyrus CM 16";
		}elseif($_GET["search"] == "cyrus-cm-5"){$titel ="Cyrus CM 5";
		}elseif($_GET["search"] == "cyrus-cm-6"){$titel ="Cyrus CM 6";
		}elseif($_GET["search"] == "cyrus-cm-7"){$titel ="Cyrus CM 7";
		}elseif($_GET["search"] == "cyrus-cm-8"){$titel ="Cyrus CM 8";
		}elseif($_GET["search"] == "cyrus-cs-18"){$titel ="Cyrus CS 18";
		}elseif($_GET["search"] == "cyrus-cs-19"){$titel ="Cyrus CS 19";
		}elseif($_GET["search"] == "cyrus-cs-20"){$titel ="Cyrus CS 20";
		}elseif($_GET["search"] == "cyrus-cs-22"){$titel ="Cyrus CS 22";
		}elseif($_GET["search"] == "cyrus-cs-23"){$titel ="Cyrus CS 23";
		}elseif($_GET["search"] == "cyrus-cs-24"){$titel ="Cyrus CS 24";
		}elseif($_GET["search"] == "cyrus-cs-25"){$titel ="Cyrus CS 25";
		}elseif($_GET["search"] == "cyrus-cs-27"){$titel ="Cyrus CS 27";
		}elseif($_GET["search"] == "cyrus-cs-28"){$titel ="Cyrus CS 28";
		}elseif($_GET["search"] == "cyrus-cs-30"){$titel ="Cyrus CS 30";
		}elseif($_GET["search"] == "cyrus-cs-35"){$titel ="Cyrus CS 35";
		}elseif($_GET["search"] == "cyrus-cs-40"){$titel ="Cyrus CS 40";
		}elseif($_GET["search"] == "cyrus-cs24"){$titel ="Cyrus CS24";
		}elseif($_GET["search"] == "cyrus-cs35"){$titel ="Cyrus CS35";
		}elseif($_GET["search"] == "desire-310"){$titel ="Desire 310";
		}elseif($_GET["search"] == "desire-320"){$titel ="Desire 320";
		}elseif($_GET["search"] == "desire-500"){$titel ="Desire 500";
		}elseif($_GET["search"] == "desire-510"){$titel ="Desire 510";
		}elseif($_GET["search"] == "desire-526g"){$titel ="Desire 526G";
		}elseif($_GET["search"] == "desire-530"){$titel ="Desire 530";
		}elseif($_GET["search"] == "desire-620"){$titel ="Desire 620";
		}elseif($_GET["search"] == "desire-626"){$titel ="Desire 626";
		}elseif($_GET["search"] == "desire-626g"){$titel ="Desire 626G";
		}elseif($_GET["search"] == "desire-630"){$titel ="Desire 630";
		}elseif($_GET["search"] == "desire-728g"){$titel ="Desire 728G";
		}elseif($_GET["search"] == "desire-816"){$titel ="Desire 816";
		}elseif($_GET["search"] == "desire-820"){$titel ="Desire 820";
		}elseif($_GET["search"] == "desire-825"){$titel ="Desire 825";
		}elseif($_GET["search"] == "desire-828w"){$titel ="Desire 828w";
		}elseif($_GET["search"] == "desire-eye"){$titel ="Desire Eye";
		}elseif($_GET["search"] == "doogee-bl12000"){$titel ="Doogee BL12000";
		}elseif($_GET["search"] == "doogee-bl5000"){$titel ="Doogee BL5000";
		}elseif($_GET["search"] == "doogee-bl7000"){$titel ="Doogee BL7000";
		}elseif($_GET["search"] == "doogee-f3"){$titel ="Doogee F3";
		}elseif($_GET["search"] == "doogee-f3-pro"){$titel ="Doogee F3 Pro";
		}elseif($_GET["search"] == "doogee-f5"){$titel ="Doogee F5";
		}elseif($_GET["search"] == "doogee-mix"){$titel ="Doogee MIX";
		}elseif($_GET["search"] == "doogee-mix-2"){$titel ="Doogee Mix 2";
		}elseif($_GET["search"] == "doogee-mix-lite"){$titel ="Doogee MIX Lite";
		}elseif($_GET["search"] == "doogee-nova-y100x"){$titel ="Doogee Nova Y100X";
		}elseif($_GET["search"] == "doogee-s30"){$titel ="Doogee S30";
		}elseif($_GET["search"] == "doogee-s50"){$titel ="Doogee S50";
		}elseif($_GET["search"] == "doogee-s60"){$titel ="Doogee S60";
		}elseif($_GET["search"] == "doogee-s60-lite"){$titel ="Doogee S60 Lite";
		}elseif($_GET["search"] == "doogee-s90"){$titel ="Doogee S90";
		}elseif($_GET["search"] == "doogee-shoot-1"){$titel ="Doogee Shoot 1";
		}elseif($_GET["search"] == "doogee-shoot-2"){$titel ="Doogee Shoot 2";
		}elseif($_GET["search"] == "doogee-t5"){$titel ="Doogee T5";
		}elseif($_GET["search"] == "doogee-t6"){$titel ="Doogee T6";
		}elseif($_GET["search"] == "doogee-titans2-dg700"){$titel ="Doogee TITANS2 DG700";
		}elseif($_GET["search"] == "doogee-v"){$titel ="Doogee V";
		}elseif($_GET["search"] == "doogee-valencia2-y100-plus"){$titel ="Doogee Valencia2 Y100 Plus";
		}elseif($_GET["search"] == "doogee-voyager2-dg310"){$titel ="Doogee VOYAGER2 DG310";
		}elseif($_GET["search"] == "doogee-x10"){$titel ="Doogee X10";
		}elseif($_GET["search"] == "doogee-x20"){$titel ="Doogee X20";
		}elseif($_GET["search"] == "doogee-x20l"){$titel ="Doogee X20L";
		}elseif($_GET["search"] == "doogee-x3"){$titel ="Doogee X3";
		}elseif($_GET["search"] == "doogee-x30"){$titel ="Doogee X30";
		}elseif($_GET["search"] == "doogee-x5"){$titel ="Doogee X5";
		}elseif($_GET["search"] == "doogee-x5-max"){$titel ="Doogee X5 Max";
		}elseif($_GET["search"] == "doogee-x5-pro"){$titel ="Doogee X5 Pro";
		}elseif($_GET["search"] == "doogee-x53"){$titel ="Doogee X53";
		}elseif($_GET["search"] == "doogee-x5s"){$titel ="Doogee X5S";
		}elseif($_GET["search"] == "doogee-x6"){$titel ="Doogee X6";
		}elseif($_GET["search"] == "doogee-x6-pro"){$titel ="Doogee X6 Pro";
		}elseif($_GET["search"] == "doogee-x6s"){$titel ="Doogee X6S";
		}elseif($_GET["search"] == "doogee-x9-pro"){$titel ="Doogee X9 Pro";
		}elseif($_GET["search"] == "doogee-y200"){$titel ="Doogee Y200";
		}elseif($_GET["search"] == "doogee-y300"){$titel ="Doogee Y300";
		}elseif($_GET["search"] == "doogee-y6-4g"){$titel ="Doogee Y6 4G";
		}elseif($_GET["search"] == "doogee-y6-max"){$titel ="Doogee Y6 MAX";
		}elseif($_GET["search"] == "doogee-y6c"){$titel ="Doogee Y6C";
		}elseif($_GET["search"] == "doro-1361"){$titel ="Doro 1361";
		}elseif($_GET["search"] == "doro-2404"){$titel ="Doro 2404";
		}elseif($_GET["search"] == "doro-2414"){$titel ="Doro 2414";
		}elseif($_GET["search"] == "doro-2424"){$titel ="Doro 2424";
		}elseif($_GET["search"] == "doro-5516"){$titel ="Doro 5516";
		}elseif($_GET["search"] == "doro-6030"){$titel ="Doro 6030";
		}elseif($_GET["search"] == "doro-6050"){$titel ="Doro 6050";
		}elseif($_GET["search"] == "doro-7060"){$titel ="Doro 7060";
		}elseif($_GET["search"] == "doro-8031"){$titel ="Doro 8031";
		}elseif($_GET["search"] == "doro-8031c"){$titel ="Doro 8031C";
		}elseif($_GET["search"] == "doro-8035"){$titel ="Doro 8035";
		}elseif($_GET["search"] == "doro-8040"){$titel ="Doro 8040";
		}elseif($_GET["search"] == "doro-liberto-650"){$titel ="Doro Liberto 650";
		}elseif($_GET["search"] == "doro-liberto-820"){$titel ="Doro Liberto 820";
		}elseif($_GET["search"] == "doro-liberto-820-mini"){$titel ="Doro Liberto 820 Mini";
		}elseif($_GET["search"] == "doro-liberto-825"){$titel ="Doro Liberto 825";
		}elseif($_GET["search"] == "doro-phoneeasy-508"){$titel ="Doro PhoneEasy 508";
		}elseif($_GET["search"] == "doro-phoneeasy-612"){$titel ="Doro PhoneEasy 612";
		}elseif($_GET["search"] == "doro-phoneeasy-613"){$titel ="Doro PhoneEasy 613";
		}elseif($_GET["search"] == "doro-phoneeasy-631"){$titel ="Doro PhoneEasy 631";
		}elseif($_GET["search"] == "doro-phoneeasy-632"){$titel ="Doro PhoneEasy 632";
		}elseif($_GET["search"] == "doro-secure-580"){$titel ="Doro Secure 580";
		}elseif($_GET["search"] == "doro-secure-580-ip"){$titel ="Doro Secure 580 IP";
		}elseif($_GET["search"] == "doro-secure-580iup"){$titel ="Doro Secure 580IUP";
		}elseif($_GET["search"] == "doro-secure-628"){$titel ="Doro Secure 628";
		}elseif($_GET["search"] == "elephone-g3"){$titel ="Elephone G3";
		}elseif($_GET["search"] == "elephone-m1-mtk6735a"){$titel ="Elephone M1 MTK6735A";
		}elseif($_GET["search"] == "elephone-m2"){$titel ="Elephone M2";
		}elseif($_GET["search"] == "elephone-p25"){$titel ="Elephone P25";
		}elseif($_GET["search"] == "elephone-p6000"){$titel ="Elephone P6000";
		}elseif($_GET["search"] == "elephone-p7000"){$titel ="Elephone P7000";
		}elseif($_GET["search"] == "elephone-p8-mini"){$titel ="Elephone P8 Mini";
		}elseif($_GET["search"] == "elephone-p8000"){$titel ="Elephone P8000";
		}elseif($_GET["search"] == "elephone-p9000"){$titel ="Elephone P9000";
		}elseif($_GET["search"] == "elephone-p9000-lite"){$titel ="Elephone P9000 Lite";
		}elseif($_GET["search"] == "elephone-q-2-45"){$titel ="Elephone Q 2.45";
		}elseif($_GET["search"] == "elephone-s1"){$titel ="Elephone S1";
		}elseif($_GET["search"] == "elephone-s1-touch"){$titel ="Elephone S1 Touch";
		}elseif($_GET["search"] == "elephone-s2"){$titel ="Elephone S2";
		}elseif($_GET["search"] == "elephone-s2-plus"){$titel ="Elephone S2 Plus";
		}elseif($_GET["search"] == "elephone-s3"){$titel ="Elephone S3";
		}elseif($_GET["search"] == "elephone-s3-lite"){$titel ="Elephone S3 Lite";
		}elseif($_GET["search"] == "elephone-s7"){$titel ="Elephone S7";
		}elseif($_GET["search"] == "elephone-trunk"){$titel ="Elephone Trunk";
		}elseif($_GET["search"] == "emporia-care-plus"){$titel ="Emporia CARE Plus";
		}elseif($_GET["search"] == "emporia-classic"){$titel ="Emporia CLASSIC";
		}elseif($_GET["search"] == "emporia-click"){$titel ="Emporia CLICK";
		}elseif($_GET["search"] == "emporia-comfort"){$titel ="Emporia COMFORT";
		}elseif($_GET["search"] == "emporia-connect"){$titel ="Emporia CONNECT";
		}elseif($_GET["search"] == "emporia-eco"){$titel ="Emporia ECO";
		}elseif($_GET["search"] == "emporia-emporiaone"){$titel ="Emporia EmporiaONE";
		}elseif($_GET["search"] == "emporia-emporiasmart-2"){$titel ="Emporia EmporiaSMART.2";
		}elseif($_GET["search"] == "emporia-euphoria"){$titel ="Emporia EUPHORIA";
		}elseif($_GET["search"] == "emporia-flip-basic"){$titel ="Emporia FLIP Basic";
		}elseif($_GET["search"] == "emporia-glam"){$titel ="Emporia GLAM";
		}elseif($_GET["search"] == "emporia-pure"){$titel ="Emporia PURE";
		}elseif($_GET["search"] == "emporia-select"){$titel ="Emporia SELECT";
		}elseif($_GET["search"] == "emporia-smart"){$titel ="Emporia SMART";
		}elseif($_GET["search"] == "emporia-smart-3"){$titel ="Emporia Smart.3";
		}elseif($_GET["search"] == "emporia-talk-comfort"){$titel ="Emporia TALK Comfort";
		}elseif($_GET["search"] == "emporia-touchsmart"){$titel ="Emporia TOUCHsmart";
		}elseif($_GET["search"] == "energizer-energy-e240s"){$titel ="Energizer ENERGY E240S";
		}elseif($_GET["search"] == "energizer-h20"){$titel ="Energizer H20";
		}elseif($_GET["search"] == "energizer-h240s"){$titel ="Energizer H240S";
		}elseif($_GET["search"] == "energizer-h500s"){$titel ="Energizer H500S";
		}elseif($_GET["search"] == "energizer-h550s"){$titel ="Energizer H550S";
		}elseif($_GET["search"] == "energizer-h570s"){$titel ="Energizer H570S";
		}elseif($_GET["search"] == "energizer-h590s"){$titel ="Energizer H590S";
		}elseif($_GET["search"] == "energizer-p16k"){$titel ="Energizer P16K";
		}elseif($_GET["search"] == "energizer-p20"){$titel ="Energizer P20";
		}elseif($_GET["search"] == "energizer-p490s"){$titel ="Energizer P490S";
		}elseif($_GET["search"] == "energizer-p600s"){$titel ="Energizer P600S";
		}elseif($_GET["search"] == "energizer-power-max-p490"){$titel ="Energizer Power Max P490";
		}elseif($_GET["search"] == "energy-sistem-phone-max"){$titel ="Energy Sistem Phone Max";
		}elseif($_GET["search"] == "energy-sistem-phone-max-4g"){$titel ="Energy Sistem Phone Max 4G";
		}elseif($_GET["search"] == "energy-sistem-phone-pro-hd"){$titel ="Energy Sistem Phone Pro HD";
		}elseif($_GET["search"] == "energy-sistem-phone-pro-qi"){$titel ="Energy Sistem Phone Pro Qi";
		}elseif($_GET["search"] == "essential-essential"){$titel ="Essential Essential";
		}elseif($_GET["search"] == "exynos-9820"){$titel ="Exynos 9820";
		}elseif($_GET["search"] == "fairphone"){$titel ="Fairphone";
		}elseif($_GET["search"] == "fairphone-2"){$titel ="Fairphone 2";
		}elseif($_GET["search"] == "fantec-boogy"){$titel ="FANTEC Boogy";
		}elseif($_GET["search"] == "fantec-limbo"){$titel ="FANTEC Limbo";
		}elseif($_GET["search"] == "galaxy-a3"){$titel ="Galaxy A3";
		}elseif($_GET["search"] == "galaxy-a3-2016"){$titel ="Galaxy A3 (2016)";
		}elseif($_GET["search"] == "galaxy-a3-2017"){$titel ="Galaxy A3 (2017)";
		}elseif($_GET["search"] == "galaxy-a3-2017"){$titel ="Galaxy A3 2017";
		}elseif($_GET["search"] == "galaxy-a5"){$titel ="Galaxy A5";
		}elseif($_GET["search"] == "galaxy-a5-2016"){$titel ="Galaxy A5 (2016)";
		}elseif($_GET["search"] == "galaxy-a5-2017"){$titel ="Galaxy A5 (2017)";
		}elseif($_GET["search"] == "galaxy-a5-2017"){$titel ="Galaxy A5 2017";
		}elseif($_GET["search"] == "galaxy-a6-plus"){$titel ="Galaxy A6 Plus";
		}elseif($_GET["search"] == "galaxy-a7"){$titel ="Galaxy A7";
		}elseif($_GET["search"] == "galaxy-a8"){$titel ="Galaxy A8";
		}elseif($_GET["search"] == "galaxy-a8s"){$titel ="Galaxy A8S";
		}elseif($_GET["search"] == "galaxy-a9"){$titel ="Galaxy A9";
		}elseif($_GET["search"] == "galaxy-a9-2018"){$titel ="Galaxy A9 (2018)";
		}elseif($_GET["search"] == "galaxy-ace-4"){$titel ="Galaxy Ace 4";
		}elseif($_GET["search"] == "galaxy-ace-style"){$titel ="Galaxy Ace Style";
		}elseif($_GET["search"] == "galaxy-alpha"){$titel ="Galaxy Alpha";
		}elseif($_GET["search"] == "galaxy-e5"){$titel ="Galaxy E5";
		}elseif($_GET["search"] == "galaxy-e7"){$titel ="Galaxy E7";
		}elseif($_GET["search"] == "galaxy-f"){$titel ="Galaxy F";
		}elseif($_GET["search"] == "galaxy-grand-on"){$titel ="Galaxy Grand On";
		}elseif($_GET["search"] == "galaxy-grand-prime"){$titel ="Galaxy Grand Prime";
		}elseif($_GET["search"] == "galaxy-j1"){$titel ="Galaxy J1";
		}elseif($_GET["search"] == "galaxy-j1-2016"){$titel ="Galaxy J1 (2016)";
		}elseif($_GET["search"] == "galaxy-j2"){$titel ="Galaxy J2";
		}elseif($_GET["search"] == "galaxy-j3"){$titel ="Galaxy J3";
		}elseif($_GET["search"] == "galaxy-j3-duos-2016"){$titel ="Galaxy J3 Duos (2016)";
		}elseif($_GET["search"] == "galaxy-j4-core"){$titel ="Galaxy J4 Core";
		}elseif($_GET["search"] == "galaxy-j4plus"){$titel ="Galaxy J4+";
		}elseif($_GET["search"] == "galaxy-j5"){$titel ="Galaxy J5";
		}elseif($_GET["search"] == "galaxy-j5-2016"){$titel ="Galaxy J5 (2016)";
		}elseif($_GET["search"] == "galaxy-j6plus"){$titel ="Galaxy J6+";
		}elseif($_GET["search"] == "galaxy-j7"){$titel ="Galaxy J7";
		}elseif($_GET["search"] == "galaxy-k-zoom"){$titel ="Galaxy K Zoom";
		}elseif($_GET["search"] == "galaxy-note-3"){$titel ="Galaxy Note 3";
		}elseif($_GET["search"] == "galaxy-note-3-neo"){$titel ="Galaxy Note 3 Neo";
		}elseif($_GET["search"] == "galaxy-note-4"){$titel ="Galaxy Note 4";
		}elseif($_GET["search"] == "galaxy-note-5"){$titel ="Galaxy Note 5";
		}elseif($_GET["search"] == "galaxy-note-8"){$titel ="Galaxy Note 8";
		}elseif($_GET["search"] == "galaxy-note-edge"){$titel ="Galaxy Note Edge";
		}elseif($_GET["search"] == "galaxy-o5"){$titel ="Galaxy O5";
		}elseif($_GET["search"] == "galaxy-o7"){$titel ="Galaxy O7";
		}elseif($_GET["search"] == "galaxy-on5"){$titel ="Galaxy On5";
		}elseif($_GET["search"] == "galaxy-on7"){$titel ="Galaxy On7";
		}elseif($_GET["search"] == "galaxy-s10"){$titel ="Galaxy S10";
		}elseif($_GET["search"] == "galaxy-s10-plus"){$titel ="Galaxy S10 Plus";
		}elseif($_GET["search"] == "galaxy-s10plus"){$titel ="Galaxy S10+";
		}elseif($_GET["search"] == "galaxy-s3"){$titel ="Galaxy S3";
		}elseif($_GET["search"] == "galaxy-s3-mini"){$titel ="Galaxy S3 Mini";
		}elseif($_GET["search"] == "galaxy-s3-neo"){$titel ="Galaxy S3 Neo";
		}elseif($_GET["search"] == "galaxy-s4"){$titel ="Galaxy S4";
		}elseif($_GET["search"] == "galaxy-s4-mini"){$titel ="Galaxy S4 Mini";
		}elseif($_GET["search"] == "galaxy-s4-mini-plus"){$titel ="Galaxy S4 Mini Plus";
		}elseif($_GET["search"] == "galaxy-s5"){$titel ="Galaxy S5";
		}elseif($_GET["search"] == "galaxy-s5-mini"){$titel ="Galaxy S5 Mini";
		}elseif($_GET["search"] == "galaxy-s5-neo"){$titel ="Galaxy S5 Neo";
		}elseif($_GET["search"] == "galaxy-s5-plus"){$titel ="Galaxy S5 Plus";
		}elseif($_GET["search"] == "galaxy-s6"){$titel ="Galaxy S6";
		}elseif($_GET["search"] == "galaxy-s6-active"){$titel ="Galaxy S6 Active";
		}elseif($_GET["search"] == "galaxy-s6-edge"){$titel ="Galaxy S6 Edge";
		}elseif($_GET["search"] == "galaxy-s6-edgeplus"){$titel ="Galaxy S6 Edge+";
		}elseif($_GET["search"] == "galaxy-s7"){$titel ="Galaxy S7";
		}elseif($_GET["search"] == "galaxy-s7-edge"){$titel ="Galaxy S7 Edge";
		}elseif($_GET["search"] == "galaxy-s7-edge-plus"){$titel ="Galaxy S7 Edge (Plus)";
		}elseif($_GET["search"] == "galaxy-s8plus"){$titel ="Galaxy S8+";
		}elseif($_GET["search"] == "galaxy-tab-a-10-5"){$titel ="Galaxy Tab A 10.5";
		}elseif($_GET["search"] == "galaxy-tab-active-2"){$titel ="Galaxy Tab Active 2";
		}elseif($_GET["search"] == "galaxy-tab-s4"){$titel ="Galaxy Tab S4";
		}elseif($_GET["search"] == "galaxy-x"){$titel ="Galaxy X";
		}elseif($_GET["search"] == "galaxy-xcover-3"){$titel ="Galaxy Xcover 3";
		}elseif($_GET["search"] == "general-mobile-4g"){$titel ="General Mobile 4G";
		}elseif($_GET["search"] == "general-mobile-5"){$titel ="General Mobile 5";
		}elseif($_GET["search"] == "general-mobile-gm-5-plus"){$titel ="General Mobile GM 5 Plus";
		}elseif($_GET["search"] == "general-mobile-gm-6"){$titel ="General Mobile GM 6";
		}elseif($_GET["search"] == "general-mobile-gm-8"){$titel ="General Mobile GM 8";
		}elseif($_GET["search"] == "general-mobile-gm-8-go"){$titel ="General Mobile GM 8 Go";
		}elseif($_GET["search"] == "gigaset-gs100"){$titel ="Gigaset GS100";
		}elseif($_GET["search"] == "gigaset-gs160"){$titel ="Gigaset GS160";
		}elseif($_GET["search"] == "gigaset-gs170"){$titel ="Gigaset GS170";
		}elseif($_GET["search"] == "gigaset-gs180"){$titel ="Gigaset GS180";
		}elseif($_GET["search"] == "gigaset-gs185"){$titel ="Gigaset GS185";
		}elseif($_GET["search"] == "gigaset-gs270"){$titel ="Gigaset GS270";
		}elseif($_GET["search"] == "gigaset-gs270-plus"){$titel ="Gigaset GS270 Plus";
		}elseif($_GET["search"] == "gigaset-gs280"){$titel ="Gigaset GS280";
		}elseif($_GET["search"] == "gigaset-gs370"){$titel ="Gigaset GS370";
		}elseif($_GET["search"] == "gigaset-gs370-plus"){$titel ="Gigaset GS370 Plus";
		}elseif($_GET["search"] == "gigaset-me"){$titel ="Gigaset ME";
		}elseif($_GET["search"] == "gigaset-me-pro"){$titel ="Gigaset ME Pro";
		}elseif($_GET["search"] == "gigaset-me-pure"){$titel ="Gigaset ME Pure";
		}elseif($_GET["search"] == "gionee-ctrl-v4s"){$titel ="Gionee Ctrl V4s";
		}elseif($_GET["search"] == "gionee-ctrl-v5"){$titel ="Gionee Ctrl V5";
		}elseif($_GET["search"] == "gionee-e8"){$titel ="Gionee E8";
		}elseif($_GET["search"] == "gionee-elife-e7"){$titel ="Gionee Elife E7";
		}elseif($_GET["search"] == "gionee-elife-e7-mini"){$titel ="Gionee Elife E7 Mini";
		}elseif($_GET["search"] == "gionee-elife-s-plus"){$titel ="Gionee Elife S Plus";
		}elseif($_GET["search"] == "gionee-elife-s7"){$titel ="Gionee Elife S7";
		}elseif($_GET["search"] == "gionee-f103"){$titel ="Gionee F103";
		}elseif($_GET["search"] == "gionee-gpad-g5"){$titel ="Gionee Gpad G5";
		}elseif($_GET["search"] == "gionee-m5lite"){$titel ="Gionee M5lite";
		}elseif($_GET["search"] == "gionee-marathon-m4"){$titel ="Gionee Marathon M4";
		}elseif($_GET["search"] == "gionee-marathon-m5"){$titel ="Gionee Marathon M5";
		}elseif($_GET["search"] == "gionee-p5w"){$titel ="Gionee P5W";
		}elseif($_GET["search"] == "gionee-pioneer-p2s"){$titel ="Gionee Pioneer P2s";
		}elseif($_GET["search"] == "gionee-pioneer-p3"){$titel ="Gionee Pioneer P3";
		}elseif($_GET["search"] == "gionee-s5-1"){$titel ="Gionee S5.1";
		}elseif($_GET["search"] == "gionee-s5-5"){$titel ="Gionee S5.5";
		}elseif($_GET["search"] == "gionee-s7"){$titel ="Gionee S7";
		}elseif($_GET["search"] == "google-nexus-4"){$titel ="Google Nexus 4";
		}elseif($_GET["search"] == "google-nexus-5"){$titel ="Google Nexus 5";
		}elseif($_GET["search"] == "google-nexus-5x"){$titel ="Google Nexus 5X";
		}elseif($_GET["search"] == "google-nexus-6"){$titel ="Google Nexus 6";
		}elseif($_GET["search"] == "google-nexus-6p"){$titel ="Google Nexus 6P";
		}elseif($_GET["search"] == "google-nexus-s"){$titel ="Google Nexus S";
		}elseif($_GET["search"] == "google-pixel"){$titel ="Google Pixel";
		}elseif($_GET["search"] == "google-pixel-2"){$titel ="Google Pixel 2";
		}elseif($_GET["search"] == "google-pixel-3"){$titel ="Google Pixel 3";
		}elseif($_GET["search"] == "google-pixel-3-xl"){$titel ="Google Pixel 3 XL";
		}elseif($_GET["search"] == "google-pixel-xl"){$titel ="Google Pixel XL";
		}elseif($_GET["search"] == "haier-g21"){$titel ="Haier G21";
		}elseif($_GET["search"] == "haier-ginger-g7"){$titel ="Haier Ginger G7";
		}elseif($_GET["search"] == "haier-ginger-g7s"){$titel ="Haier Ginger G7s";
		}elseif($_GET["search"] == "haier-haierphone-l55s"){$titel ="Haier HaierPhone L55S";
		}elseif($_GET["search"] == "haier-leisure-l56"){$titel ="Haier Leisure L56";
		}elseif($_GET["search"] == "haier-leisure-l60"){$titel ="Haier Leisure L60";
		}elseif($_GET["search"] == "haier-leisure-l7"){$titel ="Haier Leisure L7";
		}elseif($_GET["search"] == "haier-phone-l50"){$titel ="Haier Phone L50";
		}elseif($_GET["search"] == "haier-phone-l52"){$titel ="Haier Phone L52";
		}elseif($_GET["search"] == "haier-phone-l53"){$titel ="Haier Phone L53";
		}elseif($_GET["search"] == "haier-phone-w858"){$titel ="Haier Phone W858";
		}elseif($_GET["search"] == "haier-phone-w867"){$titel ="Haier Phone W867";
		}elseif($_GET["search"] == "haier-voyage-g31"){$titel ="Haier Voyage G31";
		}elseif($_GET["search"] == "haier-voyage-v3"){$titel ="Haier Voyage V3";
		}elseif($_GET["search"] == "haier-voyage-v5"){$titel ="Haier Voyage V5";
		}elseif($_GET["search"] == "haier-voyage-v6"){$titel ="Haier Voyage V6";
		}elseif($_GET["search"] == "hisense-a1"){$titel ="Hisense A1";
		}elseif($_GET["search"] == "hisense-a2"){$titel ="Hisense A2";
		}elseif($_GET["search"] == "hisense-a2-pro"){$titel ="Hisense A2 Pro";
		}elseif($_GET["search"] == "hisense-c1"){$titel ="Hisense C1";
		}elseif($_GET["search"] == "hisense-c30"){$titel ="Hisense C30";
		}elseif($_GET["search"] == "hisense-f20-dual-sim"){$titel ="Hisense F20 Dual-SIM";
		}elseif($_GET["search"] == "hisense-hs-g610m"){$titel ="Hisense HS-G610M";
		}elseif($_GET["search"] == "hisense-hs-u602"){$titel ="Hisense HS-U602";
		}elseif($_GET["search"] == "hisense-hs-u610"){$titel ="Hisense HS-U610";
		}elseif($_GET["search"] == "hisense-hs-u800"){$titel ="Hisense HS-U800";
		}elseif($_GET["search"] == "hisense-hs-u970e-8"){$titel ="Hisense HS-U970E-8";
		}elseif($_GET["search"] == "hisense-hs-u971ae"){$titel ="Hisense HS-U971AE";
		}elseif($_GET["search"] == "hisense-hs-u972"){$titel ="Hisense HS-U972";
		}elseif($_GET["search"] == "hisense-hs-u980be-2"){$titel ="Hisense HS-U980BE-2";
		}elseif($_GET["search"] == "hisense-hs-u988"){$titel ="Hisense HS-U988";
		}elseif($_GET["search"] == "hisense-infinity-h11-pro"){$titel ="Hisense Infinity H11 Pro";
		}elseif($_GET["search"] == "hisense-king-kong-2"){$titel ="Hisense King Kong 2";
		}elseif($_GET["search"] == "hisense-l671"){$titel ="Hisense L671";
		}elseif($_GET["search"] == "hisense-l695"){$titel ="Hisense L695";
		}elseif($_GET["search"] == "hisense-rock-lite"){$titel ="Hisense Rock Lite";
		}elseif($_GET["search"] == "hisense-sero-5"){$titel ="Hisense Sero 5";
		}elseif($_GET["search"] == "hisense-u988"){$titel ="Hisense U988";
		}elseif($_GET["search"] == "homtom-ht10"){$titel ="Homtom HT10";
		}elseif($_GET["search"] == "homtom-ht3"){$titel ="Homtom HT3";
		}elseif($_GET["search"] == "homtom-ht3-pro"){$titel ="Homtom HT3 Pro";
		}elseif($_GET["search"] == "homtom-ht5"){$titel ="Homtom HT5";
		}elseif($_GET["search"] == "homtom-ht50"){$titel ="Homtom HT50";
		}elseif($_GET["search"] == "homtom-ht6"){$titel ="Homtom HT6";
		}elseif($_GET["search"] == "homtom-ht7"){$titel ="Homtom HT7";
		}elseif($_GET["search"] == "homtom-ht7-pro"){$titel ="Homtom HT7 Pro";
		}elseif($_GET["search"] == "homtom-s7"){$titel ="Homtom S7";
		}elseif($_GET["search"] == "homtom-s8"){$titel ="Homtom S8";
		}elseif($_GET["search"] == "honor-10-lite"){$titel ="Honor 10 Lite";
		}elseif($_GET["search"] == "honor-6"){$titel ="Honor 6";
		}elseif($_GET["search"] == "honor-6-plus"){$titel ="Honor 6 Plus";
		}elseif($_GET["search"] == "honor-note-10"){$titel ="Honor Note 10";
		}elseif($_GET["search"] == "honor-view-20"){$titel ="Honor View 20";
		}elseif($_GET["search"] == "hp-elite-x3"){$titel ="HP Elite X3";
		}elseif($_GET["search"] == "hp-spectre-x360"){$titel ="HP Spectre X360";
		}elseif($_GET["search"] == "htc-10"){$titel ="HTC 10";
		}elseif($_GET["search"] == "htc-10-evo"){$titel ="HTC 10 Evo";
		}elseif($_GET["search"] == "htc-desire-10-lifestyle"){$titel ="HTC Desire 10 Lifestyle";
		}elseif($_GET["search"] == "htc-desire-12"){$titel ="HTC Desire 12";
		}elseif($_GET["search"] == "htc-desire-12plus"){$titel ="HTC Desire 12+";
		}elseif($_GET["search"] == "htc-desire-12s"){$titel ="HTC Desire 12s";
		}elseif($_GET["search"] == "htc-desire-620g-dual-sim"){$titel ="HTC Desire 620G Dual SIM";
		}elseif($_GET["search"] == "htc-desire-628"){$titel ="HTC Desire 628";
		}elseif($_GET["search"] == "htc-desire-650"){$titel ="HTC Desire 650";
		}elseif($_GET["search"] == "htc-exodus-1"){$titel ="HTC Exodus 1";
		}elseif($_GET["search"] == "htc-nexus-m1-marlin"){$titel ="HTC Nexus M1 Marlin";
		}elseif($_GET["search"] == "htc-nexus-s1-sailfish"){$titel ="HTC Nexus S1 Sailfish";
		}elseif($_GET["search"] == "htc-one-a9"){$titel ="HTC One A9";
		}elseif($_GET["search"] == "htc-one-a9s"){$titel ="HTC One A9s";
		}elseif($_GET["search"] == "htc-one-m10"){$titel ="HTC One M10";
		}elseif($_GET["search"] == "htc-one-m9-prime-camera-edition"){$titel ="HTC One M9 (Prime Camera Edition)";
		}elseif($_GET["search"] == "htc-one-m9plus"){$titel ="HTC One M9+";
		}elseif($_GET["search"] == "htc-one-m9s"){$titel ="HTC One M9s";
		}elseif($_GET["search"] == "htc-one-s9"){$titel ="HTC One S9";
		}elseif($_GET["search"] == "htc-one-x10"){$titel ="HTC One X10";
		}elseif($_GET["search"] == "htc-one-x9"){$titel ="HTC One X9";
		}elseif($_GET["search"] == "htc-u"){$titel ="HTC U";
		}elseif($_GET["search"] == "htc-u-play"){$titel ="HTC U Play";
		}elseif($_GET["search"] == "htc-u-ultra"){$titel ="HTC U Ultra";
		}elseif($_GET["search"] == "htc-u11"){$titel ="HTC U11";
		}elseif($_GET["search"] == "htc-u11-dual-sim"){$titel ="HTC U11 Dual-SIM";
		}elseif($_GET["search"] == "htc-u11-life"){$titel ="HTC U11 Life";
		}elseif($_GET["search"] == "htc-u11plus"){$titel ="HTC U11+";
		}elseif($_GET["search"] == "htc-u12-life"){$titel ="HTC U12 Life";
		}elseif($_GET["search"] == "htc-u12plus"){$titel ="HTC U12+";
		}elseif($_GET["search"] == "huawei-g-play-mini"){$titel ="Huawei G Play Mini";
		}elseif($_GET["search"] == "huawei-g7-plus"){$titel ="Huawei G7 Plus";
		}elseif($_GET["search"] == "huawei-g8"){$titel ="Huawei G8";
		}elseif($_GET["search"] == "huawei-gr3"){$titel ="Huawei GR3";
		}elseif($_GET["search"] == "huawei-gr5"){$titel ="Huawei GR5";
		}elseif($_GET["search"] == "huawei-gt3"){$titel ="HUAWEI GT3";
		}elseif($_GET["search"] == "huawei-gx8"){$titel ="Huawei GX8";
		}elseif($_GET["search"] == "huawei-honor-10"){$titel ="Huawei Honor 10";
		}elseif($_GET["search"] == "huawei-honor-3c"){$titel ="Huawei Honor 3C";
		}elseif($_GET["search"] == "huawei-honor-4c"){$titel ="Huawei Honor 4C";
		}elseif($_GET["search"] == "huawei-honor-4x"){$titel ="Huawei Honor 4X";
		}elseif($_GET["search"] == "huawei-honor-5c"){$titel ="Huawei Honor 5C";
		}elseif($_GET["search"] == "huawei-honor-5x"){$titel ="Huawei Honor 5X";
		}elseif($_GET["search"] == "huawei-honor-6a"){$titel ="Huawei Honor 6A";
		}elseif($_GET["search"] == "huawei-honor-6c"){$titel ="Huawei Honor 6C";
		}elseif($_GET["search"] == "huawei-honor-6c-pro"){$titel ="Huawei Honor 6C Pro";
		}elseif($_GET["search"] == "huawei-honor-6x"){$titel ="Huawei Honor 6X";
		}elseif($_GET["search"] == "huawei-honor-7"){$titel ="Huawei Honor 7";
		}elseif($_GET["search"] == "huawei-honor-7-premium"){$titel ="Huawei Honor 7 Premium";
		}elseif($_GET["search"] == "huawei-honor-7a"){$titel ="Huawei Honor 7A";
		}elseif($_GET["search"] == "huawei-honor-7c"){$titel ="Huawei Honor 7C";
		}elseif($_GET["search"] == "huawei-honor-7i"){$titel ="Huawei Honor 7i";
		}elseif($_GET["search"] == "huawei-honor-7s"){$titel ="Huawei Honor 7S";
		}elseif($_GET["search"] == "huawei-honor-7x"){$titel ="Huawei Honor 7X";
		}elseif($_GET["search"] == "huawei-honor-8"){$titel ="Huawei Honor 8";
		}elseif($_GET["search"] == "huawei-honor-8-premium"){$titel ="Huawei Honor 8 Premium";
		}elseif($_GET["search"] == "huawei-honor-8-pro"){$titel ="Huawei Honor 8 Pro";
		}elseif($_GET["search"] == "huawei-honor-8a"){$titel ="Huawei Honor 8A";
		}elseif($_GET["search"] == "huawei-honor-8x"){$titel ="Huawei Honor 8X";
		}elseif($_GET["search"] == "huawei-honor-9"){$titel ="Huawei Honor 9";
		}elseif($_GET["search"] == "huawei-honor-9-lite"){$titel ="Huawei Honor 9 Lite";
		}elseif($_GET["search"] == "huawei-honor-magic-2"){$titel ="Huawei Honor Magic 2";
		}elseif($_GET["search"] == "huawei-honor-note-8"){$titel ="Huawei Honor Note 8";
		}elseif($_GET["search"] == "huawei-honor-play"){$titel ="Huawei Honor Play";
		}elseif($_GET["search"] == "huawei-honor-play-8a"){$titel ="Huawei Honor Play 8A";
		}elseif($_GET["search"] == "huawei-honor-view-10"){$titel ="Huawei Honor View 10";
		}elseif($_GET["search"] == "huawei-honor-view-20"){$titel ="Huawei Honor View 20";
		}elseif($_GET["search"] == "huawei-mate-10"){$titel ="Huawei Mate 10";
		}elseif($_GET["search"] == "huawei-mate-10-lite"){$titel ="Huawei Mate 10 Lite";
		}elseif($_GET["search"] == "huawei-mate-10-pro-dual-sim"){$titel ="Huawei Mate 10 Pro Dual SIM";
		}elseif($_GET["search"] == "huawei-mate-20"){$titel ="Huawei Mate 20";
		}elseif($_GET["search"] == "huawei-mate-20-lite"){$titel ="Huawei Mate 20 Lite";
		}elseif($_GET["search"] == "huawei-mate-20-pro"){$titel ="Huawei Mate 20 Pro";
		}elseif($_GET["search"] == "huawei-mate-20-rs"){$titel ="Huawei Mate 20 RS";
		}elseif($_GET["search"] == "huawei-mate-20-x"){$titel ="Huawei Mate 20 X";
		}elseif($_GET["search"] == "huawei-mate-7-plus"){$titel ="Huawei Mate 7 Plus";
		}elseif($_GET["search"] == "huawei-mate-7s"){$titel ="Huawei Mate 7S";
		}elseif($_GET["search"] == "huawei-mate-8"){$titel ="Huawei Mate 8";
		}elseif($_GET["search"] == "huawei-mate-9"){$titel ="HUAWEI Mate 9";
		}elseif($_GET["search"] == "huawei-mate-9-dual-sim"){$titel ="Huawei Mate 9 Dual-SIM";
		}elseif($_GET["search"] == "huawei-mate-9-porsche-design"){$titel ="Huawei Mate 9 Porsche Design";
		}elseif($_GET["search"] == "huawei-mate-9-pro"){$titel ="HUAWEI Mate 9 Pro";
		}elseif($_GET["search"] == "huawei-mate-rs-porsche-design"){$titel ="Huawei Mate RS Porsche Design";
		}elseif($_GET["search"] == "huawei-mate-s"){$titel ="Huawei Mate S";
		}elseif($_GET["search"] == "huawei-mate-x"){$titel ="Huawei Mate X";
		}elseif($_GET["search"] == "huawei-mediapad-m3"){$titel ="Huawei MediaPad M3";
		}elseif($_GET["search"] == "huawei-mediapad-m5"){$titel ="Huawei MediaPad M5";
		}elseif($_GET["search"] == "huawei-mediapad-m5-8-4"){$titel ="Huawei MediaPad M5 8.4";
		}elseif($_GET["search"] == "huawei-mediapad-t5"){$titel ="Huawei MediaPad T5";
		}elseif($_GET["search"] == "huawei-nexus-6p"){$titel ="Huawei Nexus 6P";
		}elseif($_GET["search"] == "huawei-nova"){$titel ="Huawei Nova";
		}elseif($_GET["search"] == "huawei-nova-2"){$titel ="Huawei Nova 2";
		}elseif($_GET["search"] == "huawei-nova-2-plus"){$titel ="Huawei Nova 2 Plus";
		}elseif($_GET["search"] == "huawei-nova-3"){$titel ="Huawei Nova 3";
		}elseif($_GET["search"] == "huawei-nova-4"){$titel ="Huawei Nova 4";
		}elseif($_GET["search"] == "huawei-nova-plus"){$titel ="Huawei Nova Plus";
		}elseif($_GET["search"] == "huawei-p-smart"){$titel ="Huawei P Smart";
		}elseif($_GET["search"] == "huawei-p-smart-2"){$titel ="Huawei P Smart 2";
		}elseif($_GET["search"] == "huawei-p-smart-2019"){$titel ="Huawei P Smart 2019";
		}elseif($_GET["search"] == "huawei-p-smart-plus"){$titel ="Huawei P Smart Plus";
		}elseif($_GET["search"] == "huawei-p-smartplus"){$titel ="Huawei P Smart+";
		}elseif($_GET["search"] == "huawei-p-smartplus-2019"){$titel ="Huawei P Smart+ 2019";
		}elseif($_GET["search"] == "huawei-p10"){$titel ="Huawei P10";
		}elseif($_GET["search"] == "huawei-p10-lite"){$titel ="Huawei P10 Lite";
		}elseif($_GET["search"] == "huawei-p10-lite-dual-sim"){$titel ="Huawei P10 Lite Dual-SIM";
		}elseif($_GET["search"] == "huawei-p10-plus"){$titel ="Huawei P10 Plus";
		}elseif($_GET["search"] == "huawei-p20-dual-sim"){$titel ="Huawei P20 Dual-SIM";
		}elseif($_GET["search"] == "huawei-p20-lite-dual-sim"){$titel ="Huawei P20 Lite Dual-SIM";
		}elseif($_GET["search"] == "huawei-p20-lite-single-sim"){$titel ="Huawei P20 Lite Single-SIM";
		}elseif($_GET["search"] == "huawei-p20-pro-dual-sim"){$titel ="Huawei P20 Pro Dual-SIM";
		}elseif($_GET["search"] == "huawei-p20-pro-single-sim"){$titel ="Huawei P20 Pro Single-SIM";
		}elseif($_GET["search"] == "huawei-p20-single-sim"){$titel ="Huawei P20 Single-SIM";
		}elseif($_GET["search"] == "huawei-p30"){$titel ="Huawei P30";
		}elseif($_GET["search"] == "huawei-p30-lite"){$titel ="Huawei P30 Lite";
		}elseif($_GET["search"] == "huawei-p30-pro"){$titel ="Huawei P30 Pro";
		}elseif($_GET["search"] == "huawei-p8"){$titel ="Huawei P8";
		}elseif($_GET["search"] == "huawei-p8-energy"){$titel ="Huawei P8 Energy";
		}elseif($_GET["search"] == "huawei-p8-lite"){$titel ="Huawei P8 Lite";
		}elseif($_GET["search"] == "huawei-p8-lite-2017"){$titel ="Huawei P8 Lite 2017";
		}elseif($_GET["search"] == "huawei-p8-lite-dual-sim"){$titel ="Huawei P8 Lite Dual-SIM";
		}elseif($_GET["search"] == "huawei-p8-max"){$titel ="Huawei P8 Max";
		}elseif($_GET["search"] == "huawei-p8-premium"){$titel ="Huawei P8 Premium";
		}elseif($_GET["search"] == "huawei-p9"){$titel ="Huawei P9";
		}elseif($_GET["search"] == "huawei-p9-lite"){$titel ="Huawei P9 Lite";
		}elseif($_GET["search"] == "huawei-p9-lite-dual-sim"){$titel ="Huawei P9 Lite Dual SIM";
		}elseif($_GET["search"] == "huawei-p9-max"){$titel ="Huawei P9 Max";
		}elseif($_GET["search"] == "huawei-p9-plus"){$titel ="Huawei P9 Plus";
		}elseif($_GET["search"] == "huawei-p9-pro"){$titel ="Huawei P9 Pro";
		}elseif($_GET["search"] == "huawei-shotx"){$titel ="Huawei ShotX";
		}elseif($_GET["search"] == "huawei-y3"){$titel ="Huawei Y3";
		}elseif($_GET["search"] == "huawei-y3-ii-dual-sim"){$titel ="Huawei Y3 II Dual-SIM";
		}elseif($_GET["search"] == "huawei-y5"){$titel ="Huawei Y5";
		}elseif($_GET["search"] == "huawei-y5-2018"){$titel ="Huawei Y5 (2018)";
		}elseif($_GET["search"] == "huawei-y5-ii-dual-sim"){$titel ="Huawei Y5 II Dual-SIM";
		}elseif($_GET["search"] == "huawei-y5-ii-single-sim"){$titel ="Huawei Y5 II Single SIM";
		}elseif($_GET["search"] == "huawei-y6"){$titel ="Huawei Y6";
		}elseif($_GET["search"] == "huawei-y6-2018"){$titel ="Huawei Y6 (2018)";
		}elseif($_GET["search"] == "huawei-y6-2018-dual-sim"){$titel ="Huawei Y6 (2018) Dual-SIM";
		}elseif($_GET["search"] == "huawei-y6-2019"){$titel ="Huawei Y6 (2019";
		}elseif($_GET["search"] == "huawei-y6-2017-dual-sim"){$titel ="Huawei Y6 2017 Dual SIM";
		}elseif($_GET["search"] == "huawei-y6-2017-single-sim"){$titel ="Huawei Y6 2017 Single SIM";
		}elseif($_GET["search"] == "huawei-y6-ii-compact"){$titel ="Huawei Y6 II Compact";
		}elseif($_GET["search"] == "huawei-y6-pro-2017"){$titel ="Huawei Y6 Pro 2017";
		}elseif($_GET["search"] == "huawei-y6-pro-2017-dual-sim"){$titel ="Huawei Y6 Pro 2017 Dual SIM";
		}elseif($_GET["search"] == "huawei-y625"){$titel ="Huawei Y625";
		}elseif($_GET["search"] == "huawei-y635"){$titel ="Huawei Y635";
		}elseif($_GET["search"] == "huawei-y6pro-lte"){$titel ="Huawei Y6Pro LTE";
		}elseif($_GET["search"] == "huawei-y7"){$titel ="Huawei Y7";
		}elseif($_GET["search"] == "huawei-y7-2018"){$titel ="Huawei Y7 (2018)";
		}elseif($_GET["search"] == "huawei-y7-2019"){$titel ="Huawei Y7 (2019";
		}elseif($_GET["search"] == "huawei-y7-dual-sim"){$titel ="Huawei Y7 Dual SIM";
		}elseif($_GET["search"] == "huaweis-mate-20-pro"){$titel ="Huaweis Mate 20 Pro";
		}elseif($_GET["search"] == "huaweis-nova-4"){$titel ="Huaweis Nova 4";
		}elseif($_GET["search"] == "id2me-id1"){$titel ="ID2ME ID1";
		}elseif($_GET["search"] == "impressum"){$titel ="Impressum";
		}elseif($_GET["search"] == "ipad-2018"){$titel ="IPad (2018";
		}elseif($_GET["search"] == "ipad-air-2019"){$titel ="IPad Air (2019";
		}elseif($_GET["search"] == "ipad-mini-2019"){$titel ="IPad Mini (2019";
		}elseif($_GET["search"] == "ipad-pro-10-5"){$titel ="IPad Pro 10.5";
		}elseif($_GET["search"] == "ipad-pro-11"){$titel ="IPad Pro 11";
		}elseif($_GET["search"] == "ipad-pro-12-9-2018"){$titel ="IPad Pro 12.9 (2018";
		}elseif($_GET["search"] == "iphone-4"){$titel ="iPhone 4";
		}elseif($_GET["search"] == "iphone-4s"){$titel ="iPhone 4s";
		}elseif($_GET["search"] == "iphone-5c"){$titel ="iPhone 5c";
		}elseif($_GET["search"] == "iphone-6s"){$titel ="iPhone 6S";
		}elseif($_GET["search"] == "iphone-6s-plus"){$titel ="iPhone 6s Plus";
		}elseif($_GET["search"] == "iphone-7"){$titel ="IPhone 7";
		}elseif($_GET["search"] == "iphone-7-plus"){$titel ="IPhone 7 Plus";
		}elseif($_GET["search"] == "iphone-se"){$titel ="iPhone SE";
		}elseif($_GET["search"] == "iphone-se-2"){$titel ="IPhone SE 2";
		}elseif($_GET["search"] == "iphone-xr"){$titel ="IPhone XR";
		}elseif($_GET["search"] == "iphone-xs"){$titel ="IPhone Xs";
		}elseif($_GET["search"] == "iphone-xs-max"){$titel ="IPhone XS Max";
		}elseif($_GET["search"] == "iphone-xs-plus"){$titel ="IPhone Xs Plus";
		}elseif($_GET["search"] == "jiayu-f1"){$titel ="Jiayu F1";
		}elseif($_GET["search"] == "jiayu-f2"){$titel ="Jiayu F2";
		}elseif($_GET["search"] == "jiayu-g2"){$titel ="Jiayu G2";
		}elseif($_GET["search"] == "jiayu-g2f"){$titel ="Jiayu G2F";
		}elseif($_GET["search"] == "jiayu-g4"){$titel ="Jiayu G4";
		}elseif($_GET["search"] == "jiayu-g5"){$titel ="Jiayu G5";
		}elseif($_GET["search"] == "jiayu-s2"){$titel ="Jiayu S2";
		}elseif($_GET["search"] == "jiayu-s3"){$titel ="Jiayu S3";
		}elseif($_GET["search"] == "jiayu-s3-advanced"){$titel ="Jiayu S3 Advanced";
		}elseif($_GET["search"] == "jiayu-s3plusplus"){$titel ="Jiayu S3++";
		}elseif($_GET["search"] == "jiayu-s4c"){$titel ="Jiayu S4C";
		}elseif($_GET["search"] == "jvc-j20"){$titel ="JVC J20";
		}elseif($_GET["search"] == "kazam-life-b1"){$titel ="Kazam Life B1";
		}elseif($_GET["search"] == "kazam-life-b4"){$titel ="Kazam Life B4";
		}elseif($_GET["search"] == "kazam-life-b5"){$titel ="Kazam Life B5";
		}elseif($_GET["search"] == "kazam-life-b6"){$titel ="Kazam Life B6";
		}elseif($_GET["search"] == "kazam-life-c4"){$titel ="Kazam Life C4";
		}elseif($_GET["search"] == "kazam-life-c5"){$titel ="Kazam Life C5";
		}elseif($_GET["search"] == "kazam-life-r2"){$titel ="Kazam Life R2";
		}elseif($_GET["search"] == "kazam-life-r5"){$titel ="Kazam Life R5";
		}elseif($_GET["search"] == "kazam-thunder-340w"){$titel ="Kazam Thunder 340W";
		}elseif($_GET["search"] == "kazam-thunder-345"){$titel ="Kazam Thunder 345";
		}elseif($_GET["search"] == "kazam-thunder-347"){$titel ="Kazam Thunder 347";
		}elseif($_GET["search"] == "kazam-thunder-350l"){$titel ="Kazam Thunder 350L";
		}elseif($_GET["search"] == "kazam-thunder-q45"){$titel ="Kazam Thunder Q45";
		}elseif($_GET["search"] == "kazam-tornado-348"){$titel ="Kazam Tornado 348";
		}elseif($_GET["search"] == "kazam-tornado-350"){$titel ="Kazam Tornado 350";
		}elseif($_GET["search"] == "kazam-tornado-4-5l"){$titel ="Kazam Tornado 4.5L";
		}elseif($_GET["search"] == "kazam-tornado-5-0"){$titel ="Kazam Tornado 5.0";
		}elseif($_GET["search"] == "kazam-trooper-4-0"){$titel ="Kazam Trooper 4.0";
		}elseif($_GET["search"] == "kazam-trooper-4-5"){$titel ="Kazam Trooper 4.5";
		}elseif($_GET["search"] == "kazam-trooper-5-0"){$titel ="Kazam Trooper 5.0";
		}elseif($_GET["search"] == "kazam-trooper-6-0"){$titel ="Kazam Trooper 6.0";
		}elseif($_GET["search"] == "kiano-elegance-5-0"){$titel ="Kiano Elegance 5.0";
		}elseif($_GET["search"] == "kirin-980"){$titel ="Kirin 980";
		}elseif($_GET["search"] == "kodak-ektra"){$titel ="Kodak Ektra";
		}elseif($_GET["search"] == "kodak-im5"){$titel ="Kodak IM5";
		}elseif($_GET["search"] == "kyocera-torque"){$titel ="Kyocera Torque";
		}elseif($_GET["search"] == "leagoo-kiica-mix"){$titel ="Leagoo KIICA Mix";
		}elseif($_GET["search"] == "leagoo-kiica-power"){$titel ="Leagoo KIICA Power";
		}elseif($_GET["search"] == "leagoo-m9"){$titel ="Leagoo M9";
		}elseif($_GET["search"] == "leagoo-s8"){$titel ="Leagoo S8";
		}elseif($_GET["search"] == "leagoo-s8-pro"){$titel ="Leagoo S8 Pro";
		}elseif($_GET["search"] == "leagoo-s9"){$titel ="Leagoo S9";
		}elseif($_GET["search"] == "leagoo-t5"){$titel ="Leagoo T5";
		}elseif($_GET["search"] == "leagoo-t5c"){$titel ="Leagoo T5C";
		}elseif($_GET["search"] == "leagoo-z6"){$titel ="Leagoo Z6";
		}elseif($_GET["search"] == "leagoo-z7"){$titel ="Leagoo Z7";
		}elseif($_GET["search"] == "leeco-le-2"){$titel ="LeEco Le 2";
		}elseif($_GET["search"] == "leeco-le-2-pro"){$titel ="LeEco Le 2 Pro";
		}elseif($_GET["search"] == "leeco-le-max-2"){$titel ="LeEco Le Max 2";
		}elseif($_GET["search"] == "leeco-le-pro-3"){$titel ="LeEco Le Pro 3";
		}elseif($_GET["search"] == "leeco-le-x850"){$titel ="LeEco Le X850";
		}elseif($_GET["search"] == "lenovo-a-plus"){$titel ="Lenovo A Plus";
		}elseif($_GET["search"] == "lenovo-a1000"){$titel ="Lenovo A1000";
		}elseif($_GET["search"] == "lenovo-a2010"){$titel ="Lenovo A2010";
		}elseif($_GET["search"] == "lenovo-a5000"){$titel ="Lenovo A5000";
		}elseif($_GET["search"] == "lenovo-a6000"){$titel ="Lenovo A6000";
		}elseif($_GET["search"] == "lenovo-a7000-plus"){$titel ="Lenovo A7000 Plus";
		}elseif($_GET["search"] == "lenovo-a7010"){$titel ="Lenovo A7010";
		}elseif($_GET["search"] == "lenovo-b"){$titel ="Lenovo B";
		}elseif($_GET["search"] == "lenovo-c2"){$titel ="Lenovo C2";
		}elseif($_GET["search"] == "lenovo-k5"){$titel ="Lenovo K5";
		}elseif($_GET["search"] == "lenovo-k6"){$titel ="Lenovo K6";
		}elseif($_GET["search"] == "lenovo-k6-note"){$titel ="Lenovo K6 Note";
		}elseif($_GET["search"] == "lenovo-k6-power"){$titel ="Lenovo K6 Power";
		}elseif($_GET["search"] == "lenovo-lemon-x"){$titel ="Lenovo Lemon X";
		}elseif($_GET["search"] == "lenovo-moto-c-lte"){$titel ="Lenovo Moto C LTE";
		}elseif($_GET["search"] == "lenovo-moto-c-plus"){$titel ="Lenovo Moto C Plus";
		}elseif($_GET["search"] == "lenovo-moto-e3"){$titel ="Lenovo Moto E3";
		}elseif($_GET["search"] == "lenovo-moto-g-4-gen"){$titel ="Lenovo Moto G (4. Gen.)";
		}elseif($_GET["search"] == "lenovo-moto-g-4-gen-plus"){$titel ="Lenovo Moto G (4. Gen.) Plus";
		}elseif($_GET["search"] == "lenovo-moto-g-play"){$titel ="Lenovo Moto G Play";
		}elseif($_GET["search"] == "lenovo-moto-g4-play"){$titel ="Lenovo Moto G4 Play";
		}elseif($_GET["search"] == "lenovo-moto-g5-dual-sim"){$titel ="Lenovo Moto G5 Dual-SIM";
		}elseif($_GET["search"] == "lenovo-moto-g5-single-sim"){$titel ="Lenovo Moto G5 Single-SIM";
		}elseif($_GET["search"] == "lenovo-moto-x-2017"){$titel ="Lenovo Moto X 2017";
		}elseif($_GET["search"] == "lenovo-moto-z"){$titel ="Lenovo Moto Z";
		}elseif($_GET["search"] == "lenovo-moto-z-force"){$titel ="Lenovo Moto Z Force";
		}elseif($_GET["search"] == "lenovo-moto-z-play"){$titel ="Lenovo Moto Z Play";
		}elseif($_GET["search"] == "lenovo-p-70"){$titel ="Lenovo P 70";
		}elseif($_GET["search"] == "lenovo-p2"){$titel ="Lenovo P2";
		}elseif($_GET["search"] == "lenovo-phab"){$titel ="Lenovo Phab";
		}elseif($_GET["search"] == "lenovo-phab-plus"){$titel ="Lenovo Phab Plus";
		}elseif($_GET["search"] == "lenovo-phab2"){$titel ="Lenovo Phab2";
		}elseif($_GET["search"] == "lenovo-phab2-plus"){$titel ="Lenovo Phab2 Plus";
		}elseif($_GET["search"] == "lenovo-phab2-pro"){$titel ="Lenovo Phab2 Pro";
		}elseif($_GET["search"] == "lenovo-tab-4-10-plus"){$titel ="Lenovo Tab 4 10 Plus";
		}elseif($_GET["search"] == "lenovo-tab-e10"){$titel ="Lenovo Tab E10";
		}elseif($_GET["search"] == "lenovo-tab-e7"){$titel ="Lenovo Tab E7";
		}elseif($_GET["search"] == "lenovo-tab-p10"){$titel ="Lenovo Tab P10";
		}elseif($_GET["search"] == "lenovo-tablet-10"){$titel ="Lenovo Tablet 10";
		}elseif($_GET["search"] == "lenovo-vibe-p1"){$titel ="Lenovo Vibe P1";
		}elseif($_GET["search"] == "lenovo-vibe-p1m"){$titel ="Lenovo Vibe P1m";
		}elseif($_GET["search"] == "lenovo-vibe-s1"){$titel ="Lenovo Vibe S1";
		}elseif($_GET["search"] == "lenovo-vibe-s1-lite"){$titel ="Lenovo Vibe S1 Lite";
		}elseif($_GET["search"] == "lenovo-vibe-shot"){$titel ="Lenovo Vibe Shot";
		}elseif($_GET["search"] == "lenovo-vibe-x3"){$titel ="Lenovo Vibe X3";
		}elseif($_GET["search"] == "lenovo-vibe-x3-lite"){$titel ="Lenovo Vibe X3 Lite";
		}elseif($_GET["search"] == "lenovo-z5s"){$titel ="Lenovo Z5s";
		}elseif($_GET["search"] == "lg-bello-ii"){$titel ="LG Bello II";
		}elseif($_GET["search"] == "lg-c50"){$titel ="LG C50";
		}elseif($_GET["search"] == "lg-class"){$titel ="LG Class";
		}elseif($_GET["search"] == "lg-g-flex-2"){$titel ="LG G Flex 2";
		}elseif($_GET["search"] == "lg-g2"){$titel ="LG G2";
		}elseif($_GET["search"] == "lg-g2-mini"){$titel ="LG G2 Mini";
		}elseif($_GET["search"] == "lg-g3"){$titel ="LG G3";
		}elseif($_GET["search"] == "lg-g3-s"){$titel ="LG G3 S";
		}elseif($_GET["search"] == "lg-g4"){$titel ="LG G4";
		}elseif($_GET["search"] == "lg-g4-fashion-edition"){$titel ="LG G4 Fashion Edition";
		}elseif($_GET["search"] == "lg-g4-pro"){$titel ="LG G4 Pro";
		}elseif($_GET["search"] == "lg-g4-s"){$titel ="LG G4 S";
		}elseif($_GET["search"] == "lg-g4-stylus"){$titel ="LG G4 Stylus";
		}elseif($_GET["search"] == "lg-g4c"){$titel ="LG G4c";
		}elseif($_GET["search"] == "lg-g5"){$titel ="LG G5";
		}elseif($_GET["search"] == "lg-g5-se"){$titel ="LG G5 SE";
		}elseif($_GET["search"] == "lg-g6"){$titel ="LG G6";
		}elseif($_GET["search"] == "lg-g6plus"){$titel ="LG G6+";
		}elseif($_GET["search"] == "lg-g7-fit"){$titel ="LG G7 Fit";
		}elseif($_GET["search"] == "lg-g7-one"){$titel ="LG G7 One";
		}elseif($_GET["search"] == "lg-g7-thinq"){$titel ="LG G7 ThinQ";
		}elseif($_GET["search"] == "lg-g8-thinq"){$titel ="LG G8 ThinQ";
		}elseif($_GET["search"] == "lg-g8s-thinq"){$titel ="LG G8s ThinQ";
		}elseif($_GET["search"] == "lg-k10-2018"){$titel ="LG K10 (2018)";
		}elseif($_GET["search"] == "lg-k10-3g"){$titel ="LG K10 (3G)";
		}elseif($_GET["search"] == "lg-k10plus-2018"){$titel ="LG K10+ (2018)";
		}elseif($_GET["search"] == "lg-k3"){$titel ="LG K3";
		}elseif($_GET["search"] == "lg-k4"){$titel ="LG K4";
		}elseif($_GET["search"] == "lg-k40"){$titel ="LG K40";
		}elseif($_GET["search"] == "lg-k5"){$titel ="LG K5";
		}elseif($_GET["search"] == "lg-k50"){$titel ="LG K50";
		}elseif($_GET["search"] == "lg-k8"){$titel ="LG K8";
		}elseif($_GET["search"] == "lg-k8-2018"){$titel ="LG K8 (2018)";
		}elseif($_GET["search"] == "lg-k9"){$titel ="LG K9";
		}elseif($_GET["search"] == "lg-l-bello"){$titel ="LG L Bello";
		}elseif($_GET["search"] == "lg-l-fino"){$titel ="LG L Fino";
		}elseif($_GET["search"] == "lg-l90"){$titel ="LG L90";
		}elseif($_GET["search"] == "lg-nexus-5x"){$titel ="LG Nexus 5X";
		}elseif($_GET["search"] == "lg-optimus-g-pro-lite"){$titel ="LG Optimus G Pro Lite";
		}elseif($_GET["search"] == "lg-q-stylus"){$titel ="LG Q Stylus";
		}elseif($_GET["search"] == "lg-q-stylus-plus"){$titel ="LG Q Stylus +";
		}elseif($_GET["search"] == "lg-q6"){$titel ="LG Q6";
		}elseif($_GET["search"] == "lg-q60"){$titel ="LG Q60";
		}elseif($_GET["search"] == "lg-q7"){$titel ="LG Q7";
		}elseif($_GET["search"] == "lg-q7-alfa"){$titel ="LG Q7 Alfa";
		}elseif($_GET["search"] == "lg-q7-plus"){$titel ="LG Q7 Plus";
		}elseif($_GET["search"] == "lg-ray"){$titel ="LG Ray";
		}elseif($_GET["search"] == "lg-stylus-2"){$titel ="LG Stylus 2";
		}elseif($_GET["search"] == "lg-stylus-2-dabplus"){$titel ="LG Stylus 2 DAB+";
		}elseif($_GET["search"] == "lg-stylus-2-plus"){$titel ="LG Stylus 2 Plus";
		}elseif($_GET["search"] == "lg-v10"){$titel ="LG V10";
		}elseif($_GET["search"] == "lg-v20"){$titel ="LG V20";
		}elseif($_GET["search"] == "lg-v30"){$titel ="LG V30";
		}elseif($_GET["search"] == "lg-v30s-thinq"){$titel ="LG V30S ThinQ";
		}elseif($_GET["search"] == "lg-v30splus-thinq"){$titel ="LG V30S+ ThinQ";
		}elseif($_GET["search"] == "lg-v35-thinq"){$titel ="LG V35 ThinQ";
		}elseif($_GET["search"] == "lg-v40-thinq"){$titel ="LG V40 ThinQ";
		}elseif($_GET["search"] == "lg-v50-thinq"){$titel ="LG V50 ThinQ";
		}elseif($_GET["search"] == "lg-winesmart"){$titel ="LG WineSmart";
		}elseif($_GET["search"] == "lg-x-cam"){$titel ="LG X Cam";
		}elseif($_GET["search"] == "lg-x-mach"){$titel ="LG X Mach";
		}elseif($_GET["search"] == "lg-x-power"){$titel ="LG X Power";
		}elseif($_GET["search"] == "lg-x-power2"){$titel ="LG X Power2";
		}elseif($_GET["search"] == "lg-x-screen"){$titel ="LG X Screen";
		}elseif($_GET["search"] == "lg-x-venture"){$titel ="LG X Venture";
		}elseif($_GET["search"] == "lg-y30-yoy"){$titel ="LG Y30 Yoy";
		}elseif($_GET["search"] == "lg-y70"){$titel ="LG Y70";
		}elseif($_GET["search"] == "lg-zero"){$titel ="LG Zero";
		}elseif($_GET["search"] == "lifetab-p10603-md-60876"){$titel ="LifeTab P10603 (MD 60876";
		}elseif($_GET["search"] == "lifetab-x10311-md-60654"){$titel ="LifeTab X10311 (MD 60654";
		}elseif($_GET["search"] == "lifetab-x10607-md-60658"){$titel ="LifeTab X10607 (MD 60658";
		}elseif($_GET["search"] == "lumia-1520"){$titel ="Lumia 1520";
		}elseif($_GET["search"] == "lumia-435"){$titel ="Lumia 435";
		}elseif($_GET["search"] == "lumia-530"){$titel ="Lumia 530";
		}elseif($_GET["search"] == "lumia-532"){$titel ="Lumia 532";
		}elseif($_GET["search"] == "lumia-535"){$titel ="Lumia 535";
		}elseif($_GET["search"] == "lumia-550"){$titel ="Lumia 550";
		}elseif($_GET["search"] == "lumia-625"){$titel ="Lumia 625";
		}elseif($_GET["search"] == "lumia-630"){$titel ="Lumia 630";
		}elseif($_GET["search"] == "lumia-635"){$titel ="Lumia 635";
		}elseif($_GET["search"] == "lumia-640-dual-sim"){$titel ="Lumia 640 Dual SIM";
		}elseif($_GET["search"] == "lumia-640-lte"){$titel ="Lumia 640 LTE";
		}elseif($_GET["search"] == "lumia-640-xl-dual-sim"){$titel ="Lumia 640 XL Dual SIM";
		}elseif($_GET["search"] == "lumia-650"){$titel ="Lumia 650";
		}elseif($_GET["search"] == "lumia-650-dual-sim"){$titel ="Lumia 650 Dual-SIM";
		}elseif($_GET["search"] == "lumia-730"){$titel ="Lumia 730";
		}elseif($_GET["search"] == "lumia-730-dual-sim"){$titel ="Lumia 730 Dual SIM";
		}elseif($_GET["search"] == "lumia-735"){$titel ="Lumia 735";
		}elseif($_GET["search"] == "lumia-830"){$titel ="Lumia 830";
		}elseif($_GET["search"] == "lumia-840"){$titel ="Lumia 840";
		}elseif($_GET["search"] == "lumia-930"){$titel ="Lumia 930";
		}elseif($_GET["search"] == "lumia-940"){$titel ="Lumia 940";
		}elseif($_GET["search"] == "lumia-940-xl"){$titel ="Lumia 940 XL";
		}elseif($_GET["search"] == "lumia-950"){$titel ="Lumia 950";
		}elseif($_GET["search"] == "lumia-950-xl"){$titel ="Lumia 950 XL";
		}elseif($_GET["search"] == "lumigon-t1"){$titel ="Lumigon T1";
		}elseif($_GET["search"] == "lumigon-t2"){$titel ="Lumigon T2";
		}elseif($_GET["search"] == "lumigon-t3"){$titel ="Lumigon T3";
		}elseif($_GET["search"] == "m-horse-power-2"){$titel ="M-Horse Power 2";
		}elseif($_GET["search"] == "m-horse-pure-1"){$titel ="M-Horse Pure 1";
		}elseif($_GET["search"] == "m-horse-pure-2"){$titel ="M-Horse Pure 2";
		}elseif($_GET["search"] == "m-horse-pure-3"){$titel ="M-Horse Pure 3";
		}elseif($_GET["search"] == "marshall-london"){$titel ="Marshall London";
		}elseif($_GET["search"] == "mate-20-pro"){$titel ="Mate 20 Pro";
		}elseif($_GET["search"] == "matebook-e"){$titel ="MateBook E";
		}elseif($_GET["search"] == "maze-blade"){$titel ="Maze Blade";
		}elseif($_GET["search"] == "mediapad-m5-10"){$titel ="MediaPad M5 10";
		}elseif($_GET["search"] == "mediapad-m5-10-pro"){$titel ="MediaPad M5 10 Pro";
		}elseif($_GET["search"] == "mediapad-m5-8"){$titel ="MediaPad M5 8";
		}elseif($_GET["search"] == "mediapad-m5-lite-10"){$titel ="MediaPad M5 Lite 10";
		}elseif($_GET["search"] == "mediapad-t3-10"){$titel ="MediaPad T3 10";
		}elseif($_GET["search"] == "mediapad-t5-10"){$titel ="MediaPad T5 10";
		}elseif($_GET["search"] == "medion-e5008"){$titel ="Medion E5008";
		}elseif($_GET["search"] == "medion-life-e4005"){$titel ="Medion Life E4005";
		}elseif($_GET["search"] == "medion-life-e4503"){$titel ="Medion Life E4503";
		}elseif($_GET["search"] == "medion-life-e4504"){$titel ="Medion Life E4504";
		}elseif($_GET["search"] == "medion-life-e5001"){$titel ="Medion Life E5001";
		}elseif($_GET["search"] == "medion-life-e5005"){$titel ="Medion Life E5005";
		}elseif($_GET["search"] == "medion-life-e5006"){$titel ="Medion Life E5006";
		}elseif($_GET["search"] == "medion-life-e5020"){$titel ="Medion Life E5020";
		}elseif($_GET["search"] == "medion-life-p5004"){$titel ="Medion Life P5004";
		}elseif($_GET["search"] == "medion-life-p5005"){$titel ="Medion Life P5005";
		}elseif($_GET["search"] == "medion-life-p5006"){$titel ="Medion Life P5006";
		}elseif($_GET["search"] == "medion-life-p5015"){$titel ="Medion Life P5015";
		}elseif($_GET["search"] == "medion-life-x5001"){$titel ="Medion Life X5001";
		}elseif($_GET["search"] == "medion-life-x6001"){$titel ="Medion Life X6001";
		}elseif($_GET["search"] == "medion-s5004"){$titel ="Medion S5004";
		}elseif($_GET["search"] == "medion-s5504"){$titel ="Medion S5504";
		}elseif($_GET["search"] == "medion-x5004-(md-99238)"){$titel ="Medion X5004 (MD 99238)";
		}elseif($_GET["search"] == "medion-x5020"){$titel ="Medion X5020";
		}elseif($_GET["search"] == "medion-x5520"){$titel ="Medion X5520";
		}elseif($_GET["search"] == "meizu-15"){$titel ="Meizu 15";
		}elseif($_GET["search"] == "meizu-15-plus"){$titel ="Meizu 15 Plus";
		}elseif($_GET["search"] == "meizu-m15"){$titel ="Meizu M15";
		}elseif($_GET["search"] == "meizu-m2-note"){$titel ="Meizu M2 Note";
		}elseif($_GET["search"] == "meizu-m3-max"){$titel ="Meizu M3 Max";
		}elseif($_GET["search"] == "meizu-m3-note"){$titel ="Meizu M3 Note";
		}elseif($_GET["search"] == "meizu-m5"){$titel ="Meizu M5";
		}elseif($_GET["search"] == "meizu-m5-note"){$titel ="Meizu M5 Note";
		}elseif($_GET["search"] == "meizu-m5c"){$titel ="Meizu M5c";
		}elseif($_GET["search"] == "meizu-m5s"){$titel ="Meizu M5s";
		}elseif($_GET["search"] == "meizu-m6s"){$titel ="Meizu M6S";
		}elseif($_GET["search"] == "meizu-mx4-pro"){$titel ="Meizu MX4 Pro";
		}elseif($_GET["search"] == "meizu-mx6"){$titel ="Meizu MX6";
		}elseif($_GET["search"] == "meizu-niux"){$titel ="Meizu Niux";
		}elseif($_GET["search"] == "meizu-pro-5"){$titel ="Meizu Pro 5";
		}elseif($_GET["search"] == "meizu-pro-5-mini"){$titel ="Meizu Pro 5 Mini";
		}elseif($_GET["search"] == "meizu-pro-6"){$titel ="Meizu Pro 6";
		}elseif($_GET["search"] == "meizu-pro-6-plus"){$titel ="Meizu Pro 6 Plus";
		}elseif($_GET["search"] == "meizu-pro-6s"){$titel ="Meizu Pro 6S";
		}elseif($_GET["search"] == "meizu-pro-7"){$titel ="Meizu Pro 7";
		}elseif($_GET["search"] == "meizu-pro-7-plus"){$titel ="Meizu Pro 7 Plus";
		}elseif($_GET["search"] == "microsoft-lumia-950-xl-dual-sim"){$titel ="Microsoft Lumia 950 XL Dual SIM";
		}elseif($_GET["search"] == "microsoft-surface-go"){$titel ="Microsoft Surface Go";
		}elseif($_GET["search"] == "mobistel-cynus-e4"){$titel ="Mobistel Cynus E4";
		}elseif($_GET["search"] == "mobistel-cynus-e7"){$titel ="Mobistel Cynus E7";
		}elseif($_GET["search"] == "mobistel-cynus-f10"){$titel ="Mobistel Cynus F10";
		}elseif($_GET["search"] == "mobiwire-ahiga"){$titel ="Mobiwire Ahiga";
		}elseif($_GET["search"] == "mobiwire-aponi"){$titel ="Mobiwire Aponi";
		}elseif($_GET["search"] == "mobiwire-dakota"){$titel ="Mobiwire Dakota";
		}elseif($_GET["search"] == "mobiwire-dyami"){$titel ="MobiWire Dyami";
		}elseif($_GET["search"] == "mobiwire-elki"){$titel ="Mobiwire Elki";
		}elseif($_GET["search"] == "mobiwire-lansa"){$titel ="Mobiwire Lansa";
		}elseif($_GET["search"] == "mobiwire-nayati"){$titel ="Mobiwire Nayati";
		}elseif($_GET["search"] == "mobiwire-pegasus"){$titel ="MobiWire Pegasus";
		}elseif($_GET["search"] == "mobiwire-pictor"){$titel ="Mobiwire Pictor";
		}elseif($_GET["search"] == "mobiwire-taima"){$titel ="MobiWire Taima";
		}elseif($_GET["search"] == "mobiwire-taurus-2"){$titel ="Mobiwire Taurus²";
		}elseif($_GET["search"] == "mobiwire-winona"){$titel ="MobiWire Winona";
		}elseif($_GET["search"] == "moto-e"){$titel ="Moto E";
		}elseif($_GET["search"] == "moto-e-2-generation"){$titel ="Moto E (2. Generation)";
		}elseif($_GET["search"] == "moto-g"){$titel ="Moto G";
		}elseif($_GET["search"] == "moto-g-2-generation"){$titel ="Moto G (2. Generation)";
		}elseif($_GET["search"] == "moto-g-2-generation-4g-lte"){$titel ="Moto G (2. Generation) 4G LTE";
		}elseif($_GET["search"] == "moto-g-3-generation"){$titel ="Moto G (3. Generation)";
		}elseif($_GET["search"] == "moto-maker"){$titel ="Moto Maker";
		}elseif($_GET["search"] == "moto-x"){$titel ="Moto X";
		}elseif($_GET["search"] == "moto-x-force"){$titel ="Moto X Force";
		}elseif($_GET["search"] == "moto-x-play"){$titel ="Moto X Play";
		}elseif($_GET["search"] == "moto-x-style"){$titel ="Moto X Style";
		}elseif($_GET["search"] == "motorola-droid-turbo-2"){$titel ="Motorola Droid Turbo 2";
		}elseif($_GET["search"] == "motorola-g7"){$titel ="Motorola G7";
		}elseif($_GET["search"] == "motorola-g7-plus"){$titel ="Motorola G7 Plus";
		}elseif($_GET["search"] == "motorola-moto-c"){$titel ="Motorola Moto C";
		}elseif($_GET["search"] == "motorola-moto-e4"){$titel ="Motorola Moto E4";
		}elseif($_GET["search"] == "motorola-moto-e4-plus"){$titel ="Motorola Moto E4 Plus";
		}elseif($_GET["search"] == "motorola-moto-e5"){$titel ="Motorola Moto E5";
		}elseif($_GET["search"] == "motorola-moto-e5-dual-sim"){$titel ="Motorola Moto E5 Dual SIM";
		}elseif($_GET["search"] == "motorola-moto-e5-play"){$titel ="Motorola Moto E5 Play";
		}elseif($_GET["search"] == "motorola-moto-e5-plus"){$titel ="Motorola Moto E5 Plus";
		}elseif($_GET["search"] == "motorola-moto-e5-plus-dual-sim"){$titel ="Motorola Moto E5 Plus Dual-SIM";
		}elseif($_GET["search"] == "motorola-moto-g5"){$titel ="Motorola Moto G5";
		}elseif($_GET["search"] == "motorola-moto-g5-plus"){$titel ="Motorola Moto G5 Plus";
		}elseif($_GET["search"] == "motorola-moto-g5s"){$titel ="Motorola Moto G5s";
		}elseif($_GET["search"] == "motorola-moto-g5s-plus"){$titel ="Motorola Moto G5s Plus";
		}elseif($_GET["search"] == "motorola-moto-g6"){$titel ="Motorola Moto G6";
		}elseif($_GET["search"] == "motorola-moto-g6-play"){$titel ="Motorola Moto G6 Play";
		}elseif($_GET["search"] == "motorola-moto-g6-plus"){$titel ="Motorola Moto G6 Plus";
		}elseif($_GET["search"] == "motorola-moto-g7"){$titel ="Motorola Moto G7";
		}elseif($_GET["search"] == "motorola-moto-g7-play"){$titel ="Motorola Moto G7 Play";
		}elseif($_GET["search"] == "motorola-moto-g7-plus"){$titel ="Motorola Moto G7 Plus";
		}elseif($_GET["search"] == "motorola-moto-g7-power"){$titel ="Motorola Moto G7 Power";
		}elseif($_GET["search"] == "motorola-moto-x-2-generation"){$titel ="Motorola Moto X (2. Generation)";
		}elseif($_GET["search"] == "motorola-moto-x4"){$titel ="Motorola Moto X4";
		}elseif($_GET["search"] == "motorola-moto-z2-force"){$titel ="Motorola Moto Z2 Force";
		}elseif($_GET["search"] == "motorola-moto-z2-play"){$titel ="Motorola Moto Z2 Play";
		}elseif($_GET["search"] == "motorola-moto-z3"){$titel ="Motorola Moto Z3";
		}elseif($_GET["search"] == "motorola-moto-z3-play"){$titel ="Motorola Moto Z3 Play";
		}elseif($_GET["search"] == "motorola-one"){$titel ="Motorola One";
		}elseif($_GET["search"] == "nextbit-robin"){$titel ="Nextbit Robin";
		}elseif($_GET["search"] == "ninetec-ultratab-10-pro"){$titel ="Ninetec Ultratab 10 Pro";
		}elseif($_GET["search"] == "noa-h10le"){$titel ="NOA H10le";
		}elseif($_GET["search"] == "nokia-1"){$titel ="Nokia 1";
		}elseif($_GET["search"] == "nokia-1-plus"){$titel ="Nokia 1 Plus";
		}elseif($_GET["search"] == "nokia-105-dual-sim-2017"){$titel ="Nokia 105 Dual-SIM (2017)";
		}elseif($_GET["search"] == "nokia-105-single-sim-2017"){$titel ="Nokia 105 Single-SIM (2017)";
		}elseif($_GET["search"] == "nokia-130-dual-sim-2017"){$titel ="Nokia 130 Dual-SIM (2017)";
		}elseif($_GET["search"] == "nokia-130-single-sim-2017"){$titel ="Nokia 130 Single-SIM (2017)";
		}elseif($_GET["search"] == "nokia-2-dual-sim"){$titel ="Nokia 2 Dual-SIM";
		}elseif($_GET["search"] == "nokia-2-1"){$titel ="Nokia 2.1";
		}elseif($_GET["search"] == "nokia-210"){$titel ="Nokia 210";
		}elseif($_GET["search"] == "nokia-215"){$titel ="Nokia 215";
		}elseif($_GET["search"] == "nokia-216"){$titel ="Nokia 216";
		}elseif($_GET["search"] == "nokia-230"){$titel ="Nokia 230";
		}elseif($_GET["search"] == "nokia-3"){$titel ="Nokia 3";
		}elseif($_GET["search"] == "nokia-3-dual-sim"){$titel ="Nokia 3 Dual-SIM";
		}elseif($_GET["search"] == "nokia-3-1"){$titel ="Nokia 3.1";
		}elseif($_GET["search"] == "nokia-3-1-plus"){$titel ="Nokia 3.1 Plus";
		}elseif($_GET["search"] == "nokia-3-2"){$titel ="Nokia 3.2";
		}elseif($_GET["search"] == "nokia-3310"){$titel ="Nokia 3310";
		}elseif($_GET["search"] == "nokia-3310-2017"){$titel ="Nokia 3310 (2017)";
		}elseif($_GET["search"] == "nokia-3310-4g-2018"){$titel ="Nokia 3310 4G (2017)";
		}elseif($_GET["search"] == "nokia-3310-dual-sim"){$titel ="Nokia 3310 Dual SIM";
		}elseif($_GET["search"] == "nokia-4-2"){$titel ="Nokia 4.2";
		}elseif($_GET["search"] == "nokia-5"){$titel ="Nokia 5";
		}elseif($_GET["search"] == "nokia-5-dual-sim"){$titel ="Nokia 5 Dual-SIM";
		}elseif($_GET["search"] == "nokia-5-1"){$titel ="Nokia 5.1";
		}elseif($_GET["search"] == "nokia-5-1-plus"){$titel ="Nokia 5.1 Plus";
		}elseif($_GET["search"] == "nokia-6"){$titel ="Nokia 6";
		}elseif($_GET["search"] == "nokia-6-2018"){$titel ="Nokia 6 (2018)";
		}elseif($_GET["search"] == "nokia-6-dual-sim"){$titel ="Nokia 6 Dual-SIM";
		}elseif($_GET["search"] == "nokia-6-1"){$titel ="Nokia 6.1";
		}elseif($_GET["search"] == "nokia-6-1-plus"){$titel ="Nokia 6.1 Plus";
		}elseif($_GET["search"] == "nokia-6-2"){$titel ="Nokia 6.2";
		}elseif($_GET["search"] == "nokia-7-plus"){$titel ="Nokia 7 Plus";
		}elseif($_GET["search"] == "nokia-7-1"){$titel ="Nokia 7.1";
		}elseif($_GET["search"] == "nokia-8"){$titel ="Nokia 8";
		}elseif($_GET["search"] == "nokia-8-pro"){$titel ="Nokia 8 Pro";
		}elseif($_GET["search"] == "nokia-8-sirocco"){$titel ="Nokia 8 Sirocco";
		}elseif($_GET["search"] == "nokia-8-1"){$titel ="Nokia 8.1";
		}elseif($_GET["search"] == "nokia-8110-4g"){$titel ="Nokia 8110 4G";
		}elseif($_GET["search"] == "nokia-8810-4g"){$titel ="Nokia 8810 4G";
		}elseif($_GET["search"] == "nokia-9"){$titel ="Nokia 9";
		}elseif($_GET["search"] == "nokia-9-pureview"){$titel ="Nokia 9 PureView";
		}elseif($_GET["search"] == "nokia-new-105"){$titel ="Nokia New 105";
		}elseif($_GET["search"] == "nokia-p1"){$titel ="Nokia P1";
		}elseif($_GET["search"] == "nubia-alpha"){$titel ="Nubia Alpha";
		}elseif($_GET["search"] == "nubia-m2"){$titel ="Nubia M2";
		}elseif($_GET["search"] == "nubia-n1"){$titel ="Nubia N1";
		}elseif($_GET["search"] == "nubia-n2"){$titel ="Nubia N2";
		}elseif($_GET["search"] == "nubia-red-magic"){$titel ="Nubia Red Magic";
		}elseif($_GET["search"] == "nubia-red-magic-mars"){$titel ="Nubia Red Magic Mars";
		}elseif($_GET["search"] == "nubia-x"){$titel ="Nubia X";
		}elseif($_GET["search"] == "nubia-z11"){$titel ="Nubia Z11";
		}elseif($_GET["search"] == "nubia-z11-max"){$titel ="Nubia Z11 Max";
		}elseif($_GET["search"] == "nubia-z11-mini"){$titel ="Nubia Z11 Mini";
		}elseif($_GET["search"] == "nubia-z11-mini-s"){$titel ="Nubia Z11 Mini S";
		}elseif($_GET["search"] == "nubia-z17-mini"){$titel ="Nubia Z17 Mini";
		}elseif($_GET["search"] == "nubia-z17-mini-s"){$titel ="Nubia Z17 Mini S";
		}elseif($_GET["search"] == "nubia-z17s"){$titel ="Nubia Z17S";
		}elseif($_GET["search"] == "nubia-z18"){$titel ="Nubia Z18";
		}elseif($_GET["search"] == "obi-worldphone-mv1"){$titel ="Obi Worldphone MV1";
		}elseif($_GET["search"] == "obi-worldphone-sf1"){$titel ="Obi Worldphone SF1";
		}elseif($_GET["search"] == "obi-worldphone-sj1-5"){$titel ="Obi Worldphone SJ1.5";
		}elseif($_GET["search"] == "odys-ace-10-tablet"){$titel ="Odys Ace 10 Tablet";
		}elseif($_GET["search"] == "olympia-janus"){$titel ="Olympia Janus";
		}elseif($_GET["search"] == "olympia-mira"){$titel ="Olympia Mira";
		}elseif($_GET["search"] == "one"){$titel ="One";
		}elseif($_GET["search"] == "one-e8"){$titel ="One E8";
		}elseif($_GET["search"] == "one-m8"){$titel ="One M8";
		}elseif($_GET["search"] == "one-m8s"){$titel ="One M8s";
		}elseif($_GET["search"] == "one-m9"){$titel ="One M9";
		}elseif($_GET["search"] == "one-m9-plus"){$titel ="One M9 Plus";
		}elseif($_GET["search"] == "one-mini-2"){$titel ="One Mini 2";
		}elseif($_GET["search"] == "one-s"){$titel ="One S";
		}elseif($_GET["search"] == "oneplus-2"){$titel ="OnePlus 2";
		}elseif($_GET["search"] == "oneplus-2-mini"){$titel ="OnePlus 2 Mini";
		}elseif($_GET["search"] == "oneplus-3"){$titel ="OnePlus 3";
		}elseif($_GET["search"] == "oneplus-3t"){$titel ="OnePlus 3T";
		}elseif($_GET["search"] == "oneplus-5"){$titel ="OnePlus 5";
		}elseif($_GET["search"] == "oneplus-5t"){$titel ="OnePlus 5T";
		}elseif($_GET["search"] == "oneplus-6"){$titel ="OnePlus 6";
		}elseif($_GET["search"] == "oneplus-6t"){$titel ="OnePlus 6T";
		}elseif($_GET["search"] == "oneplus-6t-mclaren-edition"){$titel ="OnePlus 6T McLaren Edition";
		}elseif($_GET["search"] == "oneplus-7"){$titel ="OnePlus 7";
		}elseif($_GET["search"] == "oneplus-7-pro"){$titel ="OnePlus 7 Pro";
		}elseif($_GET["search"] == "oneplus-one"){$titel ="OnePlus One";
		}elseif($_GET["search"] == "oneplus-two"){$titel ="OnePlus Two";
		}elseif($_GET["search"] == "oneplus-x"){$titel ="OnePlus X";
		}elseif($_GET["search"] == "oppo-f1"){$titel ="Oppo F1";
		}elseif($_GET["search"] == "oppo-f1-plus"){$titel ="Oppo F1 Plus";
		}elseif($_GET["search"] == "oppo-f3-plus"){$titel ="Oppo F3 Plus";
		}elseif($_GET["search"] == "oppo-f7"){$titel ="Oppo F7";
		}elseif($_GET["search"] == "oppo-find-5-mini"){$titel ="Oppo Find 5 Mini";
		}elseif($_GET["search"] == "oppo-find-7"){$titel ="Oppo Find 7";
		}elseif($_GET["search"] == "oppo-find-a"){$titel ="Oppo Find A";
		}elseif($_GET["search"] == "oppo-find-x"){$titel ="Oppo Find X";
		}elseif($_GET["search"] == "oppo-joy"){$titel ="Oppo Joy";
		}elseif($_GET["search"] == "oppo-joy-3"){$titel ="Oppo Joy 3";
		}elseif($_GET["search"] == "oppo-joy-plus"){$titel ="Oppo Joy Plus";
		}elseif($_GET["search"] == "oppo-mirror-3"){$titel ="Oppo Mirror 3";
		}elseif($_GET["search"] == "oppo-mirror-5"){$titel ="Oppo Mirror 5";
		}elseif($_GET["search"] == "oppo-mirror-5s"){$titel ="Oppo Mirror 5s";
		}elseif($_GET["search"] == "oppo-n1"){$titel ="Oppo N1";
		}elseif($_GET["search"] == "oppo-n1-mini"){$titel ="Oppo N1 Mini";
		}elseif($_GET["search"] == "oppo-n3"){$titel ="Oppo N3";
		}elseif($_GET["search"] == "oppo-neo"){$titel ="Oppo Neo";
		}elseif($_GET["search"] == "oppo-neo-3"){$titel ="Oppo Neo 3";
		}elseif($_GET["search"] == "oppo-neo-5"){$titel ="Oppo Neo 5";
		}elseif($_GET["search"] == "oppo-neo-5s"){$titel ="Oppo Neo 5s";
		}elseif($_GET["search"] == "oppo-neo-7"){$titel ="Oppo Neo 7";
		}elseif($_GET["search"] == "oppo-r1"){$titel ="Oppo R1";
		}elseif($_GET["search"] == "oppo-r1k"){$titel ="Oppo R1k";
		}elseif($_GET["search"] == "oppo-r1l"){$titel ="Oppo R1L";
		}elseif($_GET["search"] == "oppo-r1x"){$titel ="Oppo R1x";
		}elseif($_GET["search"] == "oppo-r3"){$titel ="Oppo R3";
		}elseif($_GET["search"] == "oppo-r5"){$titel ="Oppo R5";
		}elseif($_GET["search"] == "oppo-r5s"){$titel ="Oppo R5s";
		}elseif($_GET["search"] == "oppo-r7"){$titel ="Oppo R7";
		}elseif($_GET["search"] == "oppo-r7-lite"){$titel ="Oppo R7 Lite";
		}elseif($_GET["search"] == "oppo-r7-plus"){$titel ="Oppo R7 Plus";
		}elseif($_GET["search"] == "oppo-r7-plus-golden"){$titel ="Oppo R7 Plus Golden";
		}elseif($_GET["search"] == "oppo-r7s"){$titel ="Oppo R7s";
		}elseif($_GET["search"] == "oppo-r9-plus"){$titel ="Oppo R9 Plus";
		}elseif($_GET["search"] == "oppo-reno"){$titel ="Oppo Reno";
		}elseif($_GET["search"] == "oppo-yoyo"){$titel ="Oppo Yoyo";
		}elseif($_GET["search"] == "oukitel-a8"){$titel ="Oukitel A8";
		}elseif($_GET["search"] == "oukitel-c2"){$titel ="Oukitel C2";
		}elseif($_GET["search"] == "oukitel-c3"){$titel ="Oukitel C3";
		}elseif($_GET["search"] == "oukitel-c4"){$titel ="Oukitel C4";
		}elseif($_GET["search"] == "oukitel-c5"){$titel ="Oukitel C5";
		}elseif($_GET["search"] == "oukitel-c5-pro"){$titel ="Oukitel C5 Pro";
		}elseif($_GET["search"] == "oukitel-c8"){$titel ="Oukitel C8";
		}elseif($_GET["search"] == "oukitel-k10"){$titel ="Oukitel K10";
		}elseif($_GET["search"] == "oukitel-k10000"){$titel ="Oukitel K10000";
		}elseif($_GET["search"] == "oukitel-k10000-max"){$titel ="Oukitel K10000 MAX";
		}elseif($_GET["search"] == "oukitel-k10000-pro"){$titel ="Oukitel K10000 Pro";
		}elseif($_GET["search"] == "oukitel-k3"){$titel ="Oukitel K3";
		}elseif($_GET["search"] == "oukitel-k4000"){$titel ="Oukitel K4000";
		}elseif($_GET["search"] == "oukitel-k4000-lite"){$titel ="Oukitel K4000 Lite";
		}elseif($_GET["search"] == "oukitel-k4000-plus"){$titel ="Oukitel K4000 Plus";
		}elseif($_GET["search"] == "oukitel-k4000-pro"){$titel ="Oukitel K4000 Pro";
		}elseif($_GET["search"] == "oukitel-k5"){$titel ="Oukitel K5";
		}elseif($_GET["search"] == "oukitel-k5000"){$titel ="Oukitel K5000";
		}elseif($_GET["search"] == "oukitel-k6"){$titel ="Oukitel K6";
		}elseif($_GET["search"] == "oukitel-k6000"){$titel ="Oukitel K6000";
		}elseif($_GET["search"] == "oukitel-k6000-plus"){$titel ="Oukitel K6000 Plus";
		}elseif($_GET["search"] == "oukitel-k6000-pro"){$titel ="Oukitel K6000 Pro";
		}elseif($_GET["search"] == "oukitel-k8000"){$titel ="Oukitel K8000";
		}elseif($_GET["search"] == "oukitel-mix-2"){$titel ="Oukitel MIX 2";
		}elseif($_GET["search"] == "oukitel-u11-plus"){$titel ="Oukitel U11 Plus";
		}elseif($_GET["search"] == "oukitel-u13"){$titel ="Oukitel U13";
		}elseif($_GET["search"] == "oukitel-u15s"){$titel ="Oukitel U15S";
		}elseif($_GET["search"] == "oukitel-u16-max"){$titel ="Oukitel U16 Max";
		}elseif($_GET["search"] == "oukitel-u2"){$titel ="Oukitel U2";
		}elseif($_GET["search"] == "oukitel-u20-plus"){$titel ="Oukitel U20 Plus";
		}elseif($_GET["search"] == "oukitel-u22"){$titel ="Oukitel U22";
		}elseif($_GET["search"] == "oukitel-u7"){$titel ="Oukitel U7";
		}elseif($_GET["search"] == "oukitel-u7-max"){$titel ="Oukitel U7 Max";
		}elseif($_GET["search"] == "oukitel-u7-plus"){$titel ="Oukitel U7 Plus";
		}elseif($_GET["search"] == "oukitel-u7-pro"){$titel ="Oukitel U7 Pro";
		}elseif($_GET["search"] == "padfone-s"){$titel ="Padfone S";
		}elseif($_GET["search"] == "panasonic-kx-tu327"){$titel ="Panasonic KX-TU327";
		}elseif($_GET["search"] == "panasonic-kx-tu328"){$titel ="Panasonic KX-TU328";
		}elseif($_GET["search"] == "panasonic-kx-tu339"){$titel ="Panasonic KX-TU339";
		}elseif($_GET["search"] == "panasonic-kx-tu349"){$titel ="Panasonic KX-TU349";
		}elseif($_GET["search"] == "panasonic-lumix-smart-camera-(dmc-cm1)"){$titel ="Panasonic Lumix Smart Camera (DMC-CM1)";
		}elseif($_GET["search"] == "panasonic-toughpad-fz-f1"){$titel ="Panasonic Toughpad FZ-F1";
		}elseif($_GET["search"] == "panasonic-toughpad-fz-n1"){$titel ="Panasonic Toughpad FZ-N1";
		}elseif($_GET["search"] == "phicomm-clue-2s"){$titel ="Phicomm Clue 2S";
		}elseif($_GET["search"] == "phicomm-clue-l"){$titel ="Phicomm Clue L";
		}elseif($_GET["search"] == "phicomm-clue-m"){$titel ="Phicomm Clue M";
		}elseif($_GET["search"] == "phicomm-clue-m-eol"){$titel ="Phicomm Clue M EOL";
		}elseif($_GET["search"] == "phicomm-clue-plus"){$titel ="Phicomm Clue Plus";
		}elseif($_GET["search"] == "phicomm-energy-2"){$titel ="Phicomm Energy 2";
		}elseif($_GET["search"] == "phicomm-energy-3plus"){$titel ="Phicomm Energy 3+";
		}elseif($_GET["search"] == "phicomm-energy-4s"){$titel ="Phicomm Energy 4s";
		}elseif($_GET["search"] == "phicomm-energy-l"){$titel ="Phicomm Energy L";
		}elseif($_GET["search"] == "phicomm-energy-mplus-eol"){$titel ="Phicomm Energy M+ EOL";
		}elseif($_GET["search"] == "phicomm-passion"){$titel ="Phicomm Passion";
		}elseif($_GET["search"] == "phicomm-passion-(p660)"){$titel ="Phicomm Passion (P660)";
		}elseif($_GET["search"] == "phicomm-passion-2s"){$titel ="Phicomm Passion 2S";
		}elseif($_GET["search"] == "phicomm-passion-3"){$titel ="Phicomm Passion 3";
		}elseif($_GET["search"] == "phicomm-passion-4"){$titel ="Phicomm Passion 4";
		}elseif($_GET["search"] == "pixel-3"){$titel ="Pixel 3";
		}elseif($_GET["search"] == "pixel-3-xl"){$titel ="Pixel 3 XL";
		}elseif($_GET["search"] == "planet-computers-cosmo-communicator"){$titel ="Planet Computers Cosmo Communicator";
		}elseif($_GET["search"] == "poco-f1"){$titel ="Poco F1";
		}elseif($_GET["search"] == "primo-215-by-doro"){$titel ="Primo 215 By Doro";
		}elseif($_GET["search"] == "primo-305-by-doro"){$titel ="Primo 305 By Doro";
		}elseif($_GET["search"] == "primo-365-by-doro"){$titel ="Primo 365 By Doro";
		}elseif($_GET["search"] == "primo-401-by-doro"){$titel ="Primo 401 By Doro";
		}elseif($_GET["search"] == "primo-405-by-doro"){$titel ="Primo 405 By Doro";
		}elseif($_GET["search"] == "primo-406-by-doro"){$titel ="Primo 406 By Doro";
		}elseif($_GET["search"] == "primo-413-by-doro"){$titel ="Primo 413 By Doro";
		}elseif($_GET["search"] == "razer-phone"){$titel ="Razer Phone";
		}elseif($_GET["search"] == "razer-phone-2"){$titel ="Razer Phone 2";
		}elseif($_GET["search"] == "royole-flexpai"){$titel ="Royole FlexPai";
		}elseif($_GET["search"] == "ruggear-rg100"){$titel ="Ruggear RG100";
		}elseif($_GET["search"] == "ruggear-rg129"){$titel ="Ruggear RG129";
		}elseif($_GET["search"] == "ruggear-rg150"){$titel ="Ruggear RG150";
		}elseif($_GET["search"] == "ruggear-rg310"){$titel ="Ruggear RG310";
		}elseif($_GET["search"] == "ruggear-rg500"){$titel ="Ruggear RG500";
		}elseif($_GET["search"] == "ruggear-rg650"){$titel ="Ruggear RG650";
		}elseif($_GET["search"] == "ruggear-rg720"){$titel ="Ruggear RG720";
		}elseif($_GET["search"] == "ruggear-rg725"){$titel ="Ruggear RG725";
		}elseif($_GET["search"] == "ruggear-rg730"){$titel ="Ruggear RG730";
		}elseif($_GET["search"] == "ruggear-rg740"){$titel ="Ruggear RG740";
		}elseif($_GET["search"] == "ruggear-rg760"){$titel ="Ruggear RG760";
		}elseif($_GET["search"] == "ruggear-rg850"){$titel ="Ruggear RG850";
		}elseif($_GET["search"] == "ruggear-rg905"){$titel ="Ruggear RG905";
		}elseif($_GET["search"] == "samsung-galaxy-a20"){$titel ="Samsung Galaxy A20";
		}elseif($_GET["search"] == "samsung-galaxy-a20e"){$titel ="Samsung Galaxy A20e";
		}elseif($_GET["search"] == "samsung-galaxy-a3-2018"){$titel ="Samsung Galaxy A3 (2018)";
		}elseif($_GET["search"] == "samsung-galaxy-a40"){$titel ="Samsung Galaxy A40";
		}elseif($_GET["search"] == "samsung-galaxy-a5-2018"){$titel ="Samsung Galaxy A5 (2018)";
		}elseif($_GET["search"] == "samsung-galaxy-a50"){$titel ="Samsung Galaxy A50";
		}elseif($_GET["search"] == "samsung-galaxy-a6-2018"){$titel ="Samsung Galaxy A6 (2018)";
		}elseif($_GET["search"] == "samsung-galaxy-a6plus-2018"){$titel ="Samsung Galaxy A6+ (2018)";
		}elseif($_GET["search"] == "samsung-galaxy-a7-2018"){$titel ="Samsung Galaxy A7 (2018)";
		}elseif($_GET["search"] == "samsung-galaxy-a8-2018"){$titel ="Samsung Galaxy A8 (2018)";
		}elseif($_GET["search"] == "samsung-galaxy-a8-2018-duos"){$titel ="Samsung Galaxy A8 (2018) Duos";
		}elseif($_GET["search"] == "samsung-galaxy-a8plus-2018"){$titel ="Samsung Galaxy A8+ (2018)";
		}elseif($_GET["search"] == "samsung-galaxy-a8plus-2018-duos"){$titel ="Samsung Galaxy A8+ (2018) Duos";
		}elseif($_GET["search"] == "samsung-galaxy-a8s"){$titel ="Samsung Galaxy A8S";
		}elseif($_GET["search"] == "samsung-galaxy-a9-2018"){$titel ="Samsung Galaxy A9 (2018";
		}elseif($_GET["search"] == "samsung-galaxy-j3-2017-duos"){$titel ="Samsung Galaxy J3 (2017) Duos";
		}elseif($_GET["search"] == "samsung-galaxy-j4-core"){$titel ="Samsung Galaxy J4 Core";
		}elseif($_GET["search"] == "samsung-galaxy-j4plus"){$titel ="Samsung Galaxy J4+";
		}elseif($_GET["search"] == "samsung-galaxy-j5-2017-duos"){$titel ="Samsung Galaxy J5 (2017) Duos";
		}elseif($_GET["search"] == "samsung-galaxy-j5-duos"){$titel ="Samsung Galaxy J5 Duos";
		}elseif($_GET["search"] == "samsung-galaxy-j6-2018"){$titel ="Samsung Galaxy J6 (2018)";
		}elseif($_GET["search"] == "samsung-galaxy-j6plus"){$titel ="Samsung Galaxy J6+";
		}elseif($_GET["search"] == "samsung-galaxy-j7-2016"){$titel ="Samsung Galaxy J7 (2016)";
		}elseif($_GET["search"] == "samsung-galaxy-j7-2017-duos"){$titel ="Samsung Galaxy J7 (2017) Duos";
		}elseif($_GET["search"] == "samsung-galaxy-m10"){$titel ="Samsung Galaxy M10";
		}elseif($_GET["search"] == "samsung-galaxy-m20"){$titel ="Samsung Galaxy M20";
		}elseif($_GET["search"] == "samsung-galaxy-note-8-duos"){$titel ="Samsung Galaxy Note 8 Duos";
		}elseif($_GET["search"] == "samsung-galaxy-note-9"){$titel ="Samsung Galaxy Note 9";
		}elseif($_GET["search"] == "samsung-galaxy-s10"){$titel ="Samsung Galaxy S10";
		}elseif($_GET["search"] == "samsung-galaxy-s10-duos"){$titel ="Samsung Galaxy S10 (DUOS";
		}elseif($_GET["search"] == "samsung-galaxy-s10-5g"){$titel ="Samsung Galaxy S10 5G";
		}elseif($_GET["search"] == "samsung-galaxy-s10plus"){$titel ="Samsung Galaxy S10+";
		}elseif($_GET["search"] == "samsung-galaxy-s10plus-duos"){$titel ="Samsung Galaxy S10+ (DUOS";
		}elseif($_GET["search"] == "samsung-galaxy-s10e"){$titel ="Samsung Galaxy S10e";
		}elseif($_GET["search"] == "samsung-galaxy-s10e-duos"){$titel ="Samsung Galaxy S10e (DUOS";
		}elseif($_GET["search"] == "samsung-galaxy-s5-duos"){$titel ="Samsung Galaxy S5 Duos";
		}elseif($_GET["search"] == "samsung-galaxy-s8"){$titel ="Samsung Galaxy S8";
		}elseif($_GET["search"] == "samsung-galaxy-s8-active"){$titel ="Samsung Galaxy S8 Active";
		}elseif($_GET["search"] == "samsung-galaxy-s8-plus"){$titel ="Samsung Galaxy S8 Plus";
		}elseif($_GET["search"] == "samsung-galaxy-s8plus-duos"){$titel ="Samsung Galaxy S8+ Duos";
		}elseif($_GET["search"] == "samsung-galaxy-s9"){$titel ="Samsung Galaxy S9";
		}elseif($_GET["search"] == "samsung-galaxy-s9-duos"){$titel ="Samsung Galaxy S9 Duos";
		}elseif($_GET["search"] == "samsung-galaxy-s9plus"){$titel ="Samsung Galaxy S9+";
		}elseif($_GET["search"] == "samsung-galaxy-s9plus-duos"){$titel ="Samsung Galaxy S9+ Duos";
		}elseif($_GET["search"] == "samsung-galaxy-tab-a"){$titel ="Samsung Galaxy Tab A";
		}elseif($_GET["search"] == "samsung-galaxy-xcover-4"){$titel ="Samsung Galaxy Xcover 4";
		}elseif($_GET["search"] == "samsung-j6"){$titel ="Samsung J6";
		}elseif($_GET["search"] == "samsung-note8"){$titel ="Samsung Note8";
		}elseif($_GET["search"] == "samsung-xcover-550"){$titel ="Samsung Xcover 550";
		}elseif($_GET["search"] == "samsung-z3"){$titel ="Samsung Z3";
		}elseif($_GET["search"] == "sharp-aquos-b10"){$titel ="Sharp Aquos B10";
		}elseif($_GET["search"] == "sharp-aquos-c10"){$titel ="Sharp Aquos C10";
		}elseif($_GET["search"] == "sharp-aquos-d10"){$titel ="Sharp Aquos D10";
		}elseif($_GET["search"] == "sharp-b10"){$titel ="Sharp B10";
		}elseif($_GET["search"] == "shift-shift4"){$titel ="Shift Shift4";
		}elseif($_GET["search"] == "shift-shift5-1"){$titel ="Shift Shift5.1";
		}elseif($_GET["search"] == "shift-shift5-3"){$titel ="Shift Shift5.3";
		}elseif($_GET["search"] == "shift-shift5pro"){$titel ="Shift Shift5pro";
		}elseif($_GET["search"] == "shift-shift6m"){$titel ="Shift Shift6m";
		}elseif($_GET["search"] == "shift-shift6mq"){$titel ="Shift Shift6mq";
		}elseif($_GET["search"] == "simvalley-mobile-pico-rx-484"){$titel ="Simvalley MOBILE Pico RX-484";
		}elseif($_GET["search"] == "simvalley-mobile-pico-rx-492"){$titel ="Simvalley MOBILE Pico RX-492";
		}elseif($_GET["search"] == "simvalley-mobile-spt-210"){$titel ="Simvalley MOBILE SPT-210";
		}elseif($_GET["search"] == "simvalley-mobile-spt-940"){$titel ="Simvalley MOBILE SPT-940";
		}elseif($_GET["search"] == "simvalley-mobile-sx-305"){$titel ="Simvalley Mobile SX-305";
		}elseif($_GET["search"] == "simvalley-mobile-sx-305-dual-sim"){$titel ="Simvalley MOBILE SX-305 Dual-SIM";
		}elseif($_GET["search"] == "simvalley-mobile-xl-915-v3"){$titel ="Simvalley MOBILE XL-915 V3";
		}elseif($_GET["search"] == "simvalley-mobile-xl-930"){$titel ="Simvalley MOBILE XL-930";
		}elseif($_GET["search"] == "simvalley-mobile-xt-690"){$titel ="Simvalley MOBILE XT-690";
		}elseif($_GET["search"] == "simvalley-rx-482"){$titel ="Simvalley RX-482";
		}elseif($_GET["search"] == "simvalley-spt-900-v2"){$titel ="Simvalley SPT-900 V2";
		}elseif($_GET["search"] == "simvalley-spx-34"){$titel ="Simvalley SPX-34";
		}elseif($_GET["search"] == "simvalley-xl-915-v2"){$titel ="Simvalley XL-915 V2";
		}elseif($_GET["search"] == "simvalley-xt-680"){$titel ="Simvalley XT-680";
		}elseif($_GET["search"] == "siswoo-a4plus"){$titel ="Siswoo A4+";
		}elseif($_GET["search"] == "siswoo-a4plus-chocolate"){$titel ="Siswoo A4+ Chocolate";
		}elseif($_GET["search"] == "siswoo-a5"){$titel ="Siswoo A5";
		}elseif($_GET["search"] == "siswoo-a5-chocolate"){$titel ="Siswoo A5 Chocolate";
		}elseif($_GET["search"] == "siswoo-c50-longbow"){$titel ="Siswoo C50 Longbow";
		}elseif($_GET["search"] == "siswoo-c55-longbow"){$titel ="Siswoo C55 Longbow";
		}elseif($_GET["search"] == "siswoo-i7-cooper"){$titel ="Siswoo I7 Cooper";
		}elseif($_GET["search"] == "siswoo-i8-panther"){$titel ="Siswoo I8 Panther";
		}elseif($_GET["search"] == "siswoo-r2-phantom"){$titel ="Siswoo R2 Phantom";
		}elseif($_GET["search"] == "siswoo-r8-monster"){$titel ="Siswoo R8 Monster";
		}elseif($_GET["search"] == "siswoo-r9-darkmoon"){$titel ="Siswoo R9 Darkmoon";
		}elseif($_GET["search"] == "sitemap"){$titel ="Sitemap";
		}elseif($_GET["search"] == "slok-c2"){$titel ="Slok C2";
		}elseif($_GET["search"] == "slok-c3"){$titel ="Slok C3";
		}elseif($_GET["search"] == "slok-d1"){$titel ="Slok D1";
		}elseif($_GET["search"] == "slok-e1"){$titel ="Slok E1";
		}elseif($_GET["search"] == "slok-s2"){$titel ="Slok S2";
		}elseif($_GET["search"] == "smart-4-power"){$titel ="Smart 4 Power";
		}elseif($_GET["search"] == "smartisan-t1"){$titel ="Smartisan T1";
		}elseif($_GET["search"] == "smartisan-t2"){$titel ="Smartisan T2";
		}elseif($_GET["search"] == "smartisan-u1"){$titel ="Smartisan U1";
		}elseif($_GET["search"] == "snapdragon-855"){$titel ="Snapdragon 855";
		}elseif($_GET["search"] == "sony-xperia-1"){$titel ="Sony Xperia 1";
		}elseif($_GET["search"] == "sony-xperia-10"){$titel ="Sony Xperia 10";
		}elseif($_GET["search"] == "sony-xperia-10-plus"){$titel ="Sony Xperia 10 Plus";
		}elseif($_GET["search"] == "sony-xperia-e5"){$titel ="Sony Xperia E5";
		}elseif($_GET["search"] == "sony-xperia-l1"){$titel ="Sony Xperia L1";
		}elseif($_GET["search"] == "sony-xperia-l2"){$titel ="Sony Xperia L2";
		}elseif($_GET["search"] == "sony-xperia-l2-dual-sim"){$titel ="Sony Xperia L2 Dual-SIM";
		}elseif($_GET["search"] == "sony-xperia-l3"){$titel ="Sony Xperia L3";
		}elseif($_GET["search"] == "sony-xperia-x-compact"){$titel ="Sony Xperia X Compact";
		}elseif($_GET["search"] == "sony-xperia-x-performance"){$titel ="Sony Xperia X Performance";
		}elseif($_GET["search"] == "sony-xperia-xa1"){$titel ="Sony Xperia XA1";
		}elseif($_GET["search"] == "sony-xperia-xa1-plus"){$titel ="Sony Xperia XA1 Plus";
		}elseif($_GET["search"] == "sony-xperia-xa1-ultra"){$titel ="Sony Xperia XA1 Ultra";
		}elseif($_GET["search"] == "sony-xperia-xa1-ultra-dual"){$titel ="Sony Xperia XA1 Ultra Dual";
		}elseif($_GET["search"] == "sony-xperia-xa2"){$titel ="Sony Xperia XA2";
		}elseif($_GET["search"] == "sony-xperia-xa2-plus"){$titel ="Sony Xperia XA2 Plus";
		}elseif($_GET["search"] == "sony-xperia-xa2-ultra"){$titel ="Sony Xperia XA2 Ultra";
		}elseif($_GET["search"] == "sony-xperia-xa2-ultra-dual-sim"){$titel ="Sony Xperia XA2 Ultra Dual-SIM";
		}elseif($_GET["search"] == "sony-xperia-xz"){$titel ="Sony Xperia XZ";
		}elseif($_GET["search"] == "sony-xperia-xz-premium"){$titel ="Sony Xperia XZ Premium";
		}elseif($_GET["search"] == "sony-xperia-xz1"){$titel ="Sony Xperia XZ1";
		}elseif($_GET["search"] == "sony-xperia-xz1-compact"){$titel ="Sony Xperia XZ1 Compact";
		}elseif($_GET["search"] == "sony-xperia-xz2"){$titel ="Sony Xperia XZ2";
		}elseif($_GET["search"] == "sony-xperia-xz2-compact"){$titel ="Sony Xperia XZ2 Compact";
		}elseif($_GET["search"] == "sony-xperia-xz2-premium"){$titel ="Sony Xperia XZ2 Premium";
		}elseif($_GET["search"] == "sony-xperia-xz3"){$titel ="Sony Xperia XZ3";
		}elseif($_GET["search"] == "sony-xperia-xzs"){$titel ="Sony Xperia XZs";
		}elseif($_GET["search"] == "sony-xperia-xzs-dual-sim"){$titel ="Sony Xperia XZs Dual SIM";
		}elseif($_GET["search"] == "startseite"){$titel ="Startseite";
		}elseif($_GET["search"] == "surface-go"){$titel ="Surface Go";
		}elseif($_GET["search"] == "surface-pro-2017"){$titel ="Surface Pro (2017";
		}elseif($_GET["search"] == "surface-pro-6"){$titel ="Surface Pro 6";
		}elseif($_GET["search"] == "swees-godon-x589"){$titel ="Swees Godon X589";
		}elseif($_GET["search"] == "switel-45d"){$titel ="Switel 45D";
		}elseif($_GET["search"] == "switel-armor-s4000d"){$titel ="Switel Armor S4000D";
		}elseif($_GET["search"] == "switel-ava-s5090d"){$titel ="Switel AVA S5090D";
		}elseif($_GET["search"] == "switel-bravo-m170"){$titel ="Switel Bravo M170";
		}elseif($_GET["search"] == "switel-champ-s5003d"){$titel ="Switel Champ S5003D";
		}elseif($_GET["search"] == "switel-classico-m-102d"){$titel ="Switel Classico M 102D";
		}elseif($_GET["search"] == "switel-cute-s3510d"){$titel ="Switel Cute S3510D";
		}elseif($_GET["search"] == "switel-esmart-e2"){$titel ="Switel ESmart E2";
		}elseif($_GET["search"] == "switel-esmart-h1"){$titel ="Switel ESmart H1";
		}elseif($_GET["search"] == "switel-esmart-m3"){$titel ="Switel ESmart M3";
		}elseif($_GET["search"] == "switel-hello-m105"){$titel ="Switel Hello M105";
		}elseif($_GET["search"] == "switel-hello-m107d-3g"){$titel ="Switel Hello M107D 3G";
		}elseif($_GET["search"] == "switel-m190"){$titel ="Switel M190";
		}elseif($_GET["search"] == "switel-m220"){$titel ="Switel M220";
		}elseif($_GET["search"] == "switel-mambo-s4018d"){$titel ="Switel Mambo S4018D";
		}elseif($_GET["search"] == "switel-mapa-m270"){$titel ="Switel Mapa M270";
		}elseif($_GET["search"] == "switel-nemo-s4017d"){$titel ="Switel Nemo S4017D";
		}elseif($_GET["search"] == "switel-s4010d"){$titel ="Switel S4010D";
		}elseif($_GET["search"] == "switel-s5003d"){$titel ="Switel S5003D";
		}elseif($_GET["search"] == "switel-s5502d"){$titel ="Switel S5502D";
		}elseif($_GET["search"] == "switel-spark-s-5002-d"){$titel ="Switel Spark S 5002 D";
		}elseif($_GET["search"] == "switel-star-s4019d-b"){$titel ="Switel Star S4019D B";
		}elseif($_GET["search"] == "switel-star-s4019d-w"){$titel ="Switel Star S4019D W";
		}elseif($_GET["search"] == "switel-sunny-turbo-s53d"){$titel ="Switel Sunny Turbo S53D";
		}elseif($_GET["search"] == "switel-trophy-s4530d"){$titel ="Switel Trophy S4530D";
		}elseif($_GET["search"] == "switel-wind-s5510d"){$titel ="Switel Wind S5510D";
		}elseif($_GET["search"] == "switel-zurich-m210"){$titel ="Switel Zurich M210";
		}elseif($_GET["search"] == "thomson-connect-th701"){$titel ="Thomson Connect TH701";
		}elseif($_GET["search"] == "thomson-delight-th201"){$titel ="Thomson Delight TH201";
		}elseif($_GET["search"] == "thomson-friendly-th101"){$titel ="Thomson Friendly TH101";
		}elseif($_GET["search"] == "tipel-6242"){$titel ="Tipel 6242";
		}elseif($_GET["search"] == "tipel-6243"){$titel ="Tipel 6243";
		}elseif($_GET["search"] == "tiptel-6240"){$titel ="Tiptel 6240";
		}elseif($_GET["search"] == "tiptel-6242"){$titel ="Tiptel 6242";
		}elseif($_GET["search"] == "tiptel-6243"){$titel ="Tiptel 6243";
		}elseif($_GET["search"] == "tiptel-ergophone-6210"){$titel ="Tiptel Ergophone 6210";
		}elseif($_GET["search"] == "tiptel-ergophone-6222"){$titel ="Tiptel Ergophone 6222";
		}elseif($_GET["search"] == "tiptel-ergophone-6223"){$titel ="Tiptel Ergophone 6223";
		}elseif($_GET["search"] == "tiptel-ergophone-6224"){$titel ="Tiptel Ergophone 6224";
		}elseif($_GET["search"] == "tiptel-ergophone-6260"){$titel ="Tiptel Ergophone 6260";
		}elseif($_GET["search"] == "tiptel-tiptel-ergophone-6120"){$titel ="Tiptel Tiptel Ergophone 6120";
		}elseif($_GET["search"] == "tiptel-tiptel-ergophone-6122"){$titel ="Tiptel Tiptel Ergophone 6122";
		}elseif($_GET["search"] == "tolino-shine-2"){$titel ="Tolino Shine 2";
		}elseif($_GET["search"] == "tolino-shine-3"){$titel ="Tolino Shine 3";
		}elseif($_GET["search"] == "tp-link-neffos-c5"){$titel ="TP-LINK Neffos C5";
		}elseif($_GET["search"] == "tp-link-neffos-c5-max"){$titel ="TP-LINK Neffos C5 Max";
		}elseif($_GET["search"] == "tp-link-neffos-c5a"){$titel ="TP-LINK Neffos C5A";
		}elseif($_GET["search"] == "tp-link-neffos-c5l"){$titel ="TP-LINK Neffos C5L";
		}elseif($_GET["search"] == "tp-link-neffos-c5s"){$titel ="TP-LINK Neffos C5S";
		}elseif($_GET["search"] == "tp-link-neffos-c7"){$titel ="TP-LINK Neffos C7";
		}elseif($_GET["search"] == "tp-link-neffos-c7a"){$titel ="TP-LINK Neffos C7A";
		}elseif($_GET["search"] == "tp-link-neffos-c9"){$titel ="TP-LINK Neffos C9";
		}elseif($_GET["search"] == "tp-link-neffos-c9a"){$titel ="TP-LINK Neffos C9A";
		}elseif($_GET["search"] == "tp-link-neffos-n1"){$titel ="TP-LINK Neffos N1";
		}elseif($_GET["search"] == "tp-link-neffos-x1"){$titel ="TP-LINK Neffos X1";
		}elseif($_GET["search"] == "tp-link-neffos-x1-lite"){$titel ="TP-LINK Neffos X1 Lite";
		}elseif($_GET["search"] == "tp-link-neffos-x1-max"){$titel ="TP-LINK Neffos X1 Max";
		}elseif($_GET["search"] == "tp-link-neffos-x9"){$titel ="TP-LINK Neffos X9";
		}elseif($_GET["search"] == "tp-link-neffos-y50"){$titel ="TP-LINK Neffos Y50";
		}elseif($_GET["search"] == "tp-link-neffos-y5s"){$titel ="TP-LINK Neffos Y5S";
		}elseif($_GET["search"] == "trekstor-primetab-t13b-co"){$titel ="Trekstor Primetab T13B-CO";
		}elseif($_GET["search"] == "turing-robotic-industries-turing-phone"){$titel ="Turing Robotic Industries Turing Phone";
		}elseif($_GET["search"] == "ulefone-be-touch-3"){$titel ="Ulefone Be Touch 3";
		}elseif($_GET["search"] == "ulefone-be-x"){$titel ="Ulefone Be X";
		}elseif($_GET["search"] == "ulefone-f1"){$titel ="Ulefone F1";
		}elseif($_GET["search"] == "ulefone-future"){$titel ="Ulefone Future";
		}elseif($_GET["search"] == "ulefone-gemini"){$titel ="Ulefone Gemini";
		}elseif($_GET["search"] == "ulefone-paris"){$titel ="Ulefone Paris";
		}elseif($_GET["search"] == "ulefone-paris-arc-hd"){$titel ="Ulefone Paris Arc HD";
		}elseif($_GET["search"] == "ulefone-power"){$titel ="Ulefone Power";
		}elseif($_GET["search"] == "ulefone-power-2"){$titel ="Ulefone Power 2";
		}elseif($_GET["search"] == "ulefone-power-3"){$titel ="Ulefone Power 3";
		}elseif($_GET["search"] == "ulefone-power-wooden"){$titel ="Ulefone Power Wooden";
		}elseif($_GET["search"] == "ulefone-t1"){$titel ="Ulefone T1";
		}elseif($_GET["search"] == "ulefone-vienna"){$titel ="Ulefone Vienna";
		}elseif($_GET["search"] == "umi-emax"){$titel ="Umi EMax";
		}elseif($_GET["search"] == "umi-emax-mini"){$titel ="Umi EMax Mini";
		}elseif($_GET["search"] == "umi-fair"){$titel ="Umi Fair";
		}elseif($_GET["search"] == "umi-hammer-s"){$titel ="UMI Hammer S";
		}elseif($_GET["search"] == "umi-iron"){$titel ="Umi Iron";
		}elseif($_GET["search"] == "umi-iron-pro"){$titel ="Umi Iron Pro";
		}elseif($_GET["search"] == "umi-rome"){$titel ="Umi Rome";
		}elseif($_GET["search"] == "umi-rome-x"){$titel ="Umi Rome X";
		}elseif($_GET["search"] == "umi-touch"){$titel ="Umi Touch";
		}elseif($_GET["search"] == "umidigi-a3"){$titel ="UMIDIGI A3";
		}elseif($_GET["search"] == "umidigi-c2"){$titel ="UMIDIGI C2";
		}elseif($_GET["search"] == "umidigi-crystal"){$titel ="UMIDIGI Crystal";
		}elseif($_GET["search"] == "umidigi-diamond-x"){$titel ="UMIDIGI Diamond X";
		}elseif($_GET["search"] == "umidigi-london"){$titel ="UMIDIGI London";
		}elseif($_GET["search"] == "umidigi-max"){$titel ="UMIDIGI MAX";
		}elseif($_GET["search"] == "umidigi-plus"){$titel ="UMIDIGI PLUS";
		}elseif($_GET["search"] == "umidigi-z-pro"){$titel ="UmiDigi Z Pro";
		}elseif($_GET["search"] == "umidigi-z1"){$titel ="UMIDIGI Z1";
		}elseif($_GET["search"] == "umidigi-z1-pro"){$titel ="UMIDIGI Z1 Pro";
		}elseif($_GET["search"] == "vaio-phone-a"){$titel ="Vaio Phone A";
		}elseif($_GET["search"] == "vernee-apollo"){$titel ="Vernee Apollo";
		}elseif($_GET["search"] == "vernee-apollo-2"){$titel ="Vernee Apollo 2";
		}elseif($_GET["search"] == "vernee-apollo-2-pro"){$titel ="Vernee Apollo 2 Pro";
		}elseif($_GET["search"] == "vernee-apollo-lite"){$titel ="Vernee Apollo Lite";
		}elseif($_GET["search"] == "vernee-apollo-x"){$titel ="Vernee Apollo X";
		}elseif($_GET["search"] == "vernee-m6"){$titel ="Vernee M6";
		}elseif($_GET["search"] == "vernee-mars"){$titel ="Vernee Mars";
		}elseif($_GET["search"] == "vernee-mars-pro"){$titel ="Vernee Mars Pro";
		}elseif($_GET["search"] == "vernee-mars-pro-4g"){$titel ="Vernee Mars Pro 4G";
		}elseif($_GET["search"] == "vernee-thor"){$titel ="Vernee Thor";
		}elseif($_GET["search"] == "vernee-thor-e"){$titel ="Vernee Thor E";
		}elseif($_GET["search"] == "vernee-thor-pro"){$titel ="Vernee Thor Pro";
		}elseif($_GET["search"] == "vernee-x"){$titel ="Vernee X";
		}elseif($_GET["search"] == "vertu-constellation-2017"){$titel ="Vertu Constellation (2017)";
		}elseif($_GET["search"] == "vertu-v06"){$titel ="Vertu V06";
		}elseif($_GET["search"] == "vestel-5000-dual-sim"){$titel ="Vestel 5000 Dual-SIM";
		}elseif($_GET["search"] == "vestel-5530"){$titel ="Vestel 5530";
		}elseif($_GET["search"] == "vestel-v3-5030"){$titel ="Vestel V3 5030";
		}elseif($_GET["search"] == "vestel-v3-5040"){$titel ="Vestel V3 5040";
		}elseif($_GET["search"] == "vestel-v3-5570"){$titel ="Vestel V3 5570";
		}elseif($_GET["search"] == "vestel-v3-5580"){$titel ="Vestel V3 5580";
		}elseif($_GET["search"] == "vestel-v3-5580-dual-sim"){$titel ="Vestel V3 5580 Dual-SIM";
		}elseif($_GET["search"] == "vivo-nex"){$titel ="Vivo Nex";
		}elseif($_GET["search"] == "vivo-v11"){$titel ="Vivo V11";
		}elseif($_GET["search"] == "vodafone-smart-e8"){$titel ="Vodafone Smart E8";
		}elseif($_GET["search"] == "vodafone-smart-n8"){$titel ="Vodafone Smart N8";
		}elseif($_GET["search"] == "vodafone-smart-platinum-7"){$titel ="Vodafone Smart Platinum 7";
		}elseif($_GET["search"] == "vodafone-smart-prime-7"){$titel ="Vodafone Smart Prime 7";
		}elseif($_GET["search"] == "vodafone-smart-ultra-6"){$titel ="Vodafone Smart Ultra 6";
		}elseif($_GET["search"] == "vonino-zun-xo"){$titel ="Vonino Zun XO";
		}elseif($_GET["search"] == "wiko-b-kool"){$titel ="Wiko B-kool";
		}elseif($_GET["search"] == "wiko-barry"){$titel ="Wiko Barry";
		}elseif($_GET["search"] == "wiko-birdy"){$titel ="Wiko Birdy";
		}elseif($_GET["search"] == "wiko-bloom"){$titel ="Wiko Bloom";
		}elseif($_GET["search"] == "wiko-cink-peax-2"){$titel ="Wiko Cink Peax 2";
		}elseif($_GET["search"] == "wiko-darkfull"){$titel ="Wiko Darkfull";
		}elseif($_GET["search"] == "wiko-darkmoon"){$titel ="Wiko Darkmoon";
		}elseif($_GET["search"] == "wiko-darknight"){$titel ="Wiko Darknight";
		}elseif($_GET["search"] == "wiko-darkside"){$titel ="Wiko Darkside";
		}elseif($_GET["search"] == "wiko-fever-4g"){$titel ="Wiko Fever 4G";
		}elseif($_GET["search"] == "wiko-fever-special-edition"){$titel ="Wiko Fever Special Edition";
		}elseif($_GET["search"] == "wiko-fizz"){$titel ="Wiko Fizz";
		}elseif($_GET["search"] == "wiko-freddy"){$titel ="Wiko Freddy";
		}elseif($_GET["search"] == "wiko-getaway"){$titel ="Wiko Getaway";
		}elseif($_GET["search"] == "wiko-harry"){$titel ="Wiko Harry";
		}elseif($_GET["search"] == "wiko-harry-2"){$titel ="Wiko Harry 2";
		}elseif($_GET["search"] == "wiko-highway"){$titel ="Wiko Highway";
		}elseif($_GET["search"] == "wiko-highway-4g"){$titel ="Wiko Highway 4G";
		}elseif($_GET["search"] == "wiko-highway-pure"){$titel ="Wiko Highway Pure";
		}elseif($_GET["search"] == "wiko-highway-signs"){$titel ="Wiko Highway Signs";
		}elseif($_GET["search"] == "wiko-highway-star"){$titel ="Wiko Highway Star";
		}elseif($_GET["search"] == "wiko-jerry"){$titel ="Wiko Jerry";
		}elseif($_GET["search"] == "wiko-jerry-2"){$titel ="Wiko Jerry 2";
		}elseif($_GET["search"] == "wiko-jerry-3"){$titel ="Wiko Jerry 3";
		}elseif($_GET["search"] == "wiko-jimmy"){$titel ="Wiko Jimmy";
		}elseif($_GET["search"] == "wiko-k-kool"){$titel ="Wiko K-kool";
		}elseif($_GET["search"] == "wiko-kite"){$titel ="Wiko Kite";
		}elseif($_GET["search"] == "wiko-lenny"){$titel ="Wiko Lenny";
		}elseif($_GET["search"] == "wiko-lenny-2"){$titel ="Wiko Lenny 2";
		}elseif($_GET["search"] == "wiko-lenny-3"){$titel ="Wiko Lenny 3";
		}elseif($_GET["search"] == "wiko-lenny-4"){$titel ="Wiko Lenny 4";
		}elseif($_GET["search"] == "wiko-lenny-4-plus"){$titel ="Wiko Lenny 4 Plus";
		}elseif($_GET["search"] == "wiko-lenny-5"){$titel ="Wiko Lenny 5";
		}elseif($_GET["search"] == "wiko-lubi-3"){$titel ="Wiko Lubi 3";
		}elseif($_GET["search"] == "wiko-ozzy"){$titel ="Wiko Ozzy";
		}elseif($_GET["search"] == "wiko-pulp"){$titel ="Wiko Pulp";
		}elseif($_GET["search"] == "wiko-pulp-fab"){$titel ="Wiko Pulp Fab";
		}elseif($_GET["search"] == "wiko-rainbow"){$titel ="Wiko Rainbow";
		}elseif($_GET["search"] == "wiko-rainbow-4g"){$titel ="Wiko Rainbow 4G";
		}elseif($_GET["search"] == "wiko-rainbow-jam"){$titel ="Wiko Rainbow Jam";
		}elseif($_GET["search"] == "wiko-rainbow-lite"){$titel ="Wiko Rainbow Lite";
		}elseif($_GET["search"] == "wiko-rainbow-up"){$titel ="Wiko Rainbow Up";
		}elseif($_GET["search"] == "wiko-ridge-4g"){$titel ="Wiko Ridge 4G";
		}elseif($_GET["search"] == "wiko-ridge-fab-4g"){$titel ="Wiko Ridge Fab 4G";
		}elseif($_GET["search"] == "wiko-riff"){$titel ="Wiko Riff";
		}elseif($_GET["search"] == "wiko-robby"){$titel ="Wiko Robby";
		}elseif($_GET["search"] == "wiko-s-kool"){$titel ="Wiko S-kool";
		}elseif($_GET["search"] == "wiko-selfy-4g"){$titel ="Wiko Selfy 4G";
		}elseif($_GET["search"] == "wiko-slide"){$titel ="Wiko Slide";
		}elseif($_GET["search"] == "wiko-stairway"){$titel ="Wiko Stairway";
		}elseif($_GET["search"] == "wiko-sublim"){$titel ="Wiko Sublim";
		}elseif($_GET["search"] == "wiko-sunny"){$titel ="Wiko Sunny";
		}elseif($_GET["search"] == "wiko-sunny-2"){$titel ="Wiko Sunny 2";
		}elseif($_GET["search"] == "wiko-sunny-2-plus"){$titel ="Wiko Sunny 2 Plus";
		}elseif($_GET["search"] == "wiko-sunny-3"){$titel ="Wiko Sunny 3";
		}elseif($_GET["search"] == "wiko-sunny-3-mini"){$titel ="Wiko Sunny 3 Mini";
		}elseif($_GET["search"] == "wiko-sunset"){$titel ="Wiko Sunset";
		}elseif($_GET["search"] == "wiko-sunset-2"){$titel ="Wiko Sunset 2";
		}elseif($_GET["search"] == "wiko-tommy"){$titel ="Wiko Tommy";
		}elseif($_GET["search"] == "wiko-tommy-2"){$titel ="Wiko Tommy 2";
		}elseif($_GET["search"] == "wiko-tommy-2-plus"){$titel ="Wiko Tommy 2 Plus";
		}elseif($_GET["search"] == "wiko-tommy-3"){$titel ="Wiko Tommy 3";
		}elseif($_GET["search"] == "wiko-u-feel-fab"){$titel ="Wiko U Feel Fab";
		}elseif($_GET["search"] == "wiko-u-feel-lite"){$titel ="Wiko U Feel Lite";
		}elseif($_GET["search"] == "wiko-u-feel-prime"){$titel ="Wiko U Feel Prime";
		}elseif($_GET["search"] == "wiko-ufeel"){$titel ="Wiko Ufeel";
		}elseif($_GET["search"] == "wiko-ufeel-lite"){$titel ="Wiko Ufeel Lite";
		}elseif($_GET["search"] == "wiko-upulse"){$titel ="Wiko Upulse";
		}elseif($_GET["search"] == "wiko-upulse-lite"){$titel ="Wiko Upulse Lite";
		}elseif($_GET["search"] == "wiko-view"){$titel ="Wiko View";
		}elseif($_GET["search"] == "wiko-view-2"){$titel ="Wiko View 2";
		}elseif($_GET["search"] == "wiko-view-2-go"){$titel ="Wiko View 2 GO";
		}elseif($_GET["search"] == "wiko-view-2-plus"){$titel ="Wiko View 2 Plus";
		}elseif($_GET["search"] == "wiko-view-2-pro"){$titel ="Wiko View 2 PRO";
		}elseif($_GET["search"] == "wiko-view-3"){$titel ="Wiko View 3";
		}elseif($_GET["search"] == "wiko-view-3-pro"){$titel ="Wiko View 3 Pro";
		}elseif($_GET["search"] == "wiko-view-32-gb"){$titel ="Wiko View 32 GB";
		}elseif($_GET["search"] == "wiko-view-go"){$titel ="Wiko View Go";
		}elseif($_GET["search"] == "wiko-view-lite"){$titel ="Wiko View Lite";
		}elseif($_GET["search"] == "wiko-view-max"){$titel ="Wiko View Max";
		}elseif($_GET["search"] == "wiko-view-prime"){$titel ="Wiko View Prime";
		}elseif($_GET["search"] == "wiko-view-xl"){$titel ="Wiko View XL";
		}elseif($_GET["search"] == "wiko-wax"){$titel ="Wiko Wax";
		}elseif($_GET["search"] == "wiko-wim"){$titel ="Wiko WIM";
		}elseif($_GET["search"] == "wiko-wim-lite"){$titel ="Wiko WIM Lite";
		}elseif($_GET["search"] == "wileyfox-pro"){$titel ="Wileyfox Pro";
		}elseif($_GET["search"] == "wileyfox-spark"){$titel ="Wileyfox Spark";
		}elseif($_GET["search"] == "wileyfox-spark-plus"){$titel ="Wileyfox Spark +";
		}elseif($_GET["search"] == "wileyfox-spark-x"){$titel ="Wileyfox Spark X";
		}elseif($_GET["search"] == "wileyfox-storm"){$titel ="Wileyfox Storm";
		}elseif($_GET["search"] == "wileyfox-swift-2"){$titel ="Wileyfox Swift 2";
		}elseif($_GET["search"] == "wileyfox-swift-2-plus"){$titel ="Wileyfox Swift 2 Plus";
		}elseif($_GET["search"] == "wileyfox-swift-2-x"){$titel ="Wileyfox Swift 2 X";
		}elseif($_GET["search"] == "wileyfox-swift-2x"){$titel ="Wileyfox Swift 2X";
		}elseif($_GET["search"] == "xiaomi-black-shark"){$titel ="Xiaomi Black Shark";
		}elseif($_GET["search"] == "xiaomi-black-shark-2"){$titel ="Xiaomi Black Shark 2";
		}elseif($_GET["search"] == "xiaomi-blackshark-helo"){$titel ="Xiaomi Blackshark Helo";
		}elseif($_GET["search"] == "xiaomi-mi-4c"){$titel ="Xiaomi Mi 4c";
		}elseif($_GET["search"] == "xiaomi-mi-5c"){$titel ="Xiaomi Mi 5c";
		}elseif($_GET["search"] == "xiaomi-mi-6"){$titel ="Xiaomi Mi 6";
		}elseif($_GET["search"] == "xiaomi-mi-8"){$titel ="Xiaomi Mi 8";
		}elseif($_GET["search"] == "xiaomi-mi-8-lite"){$titel ="Xiaomi Mi 8 Lite";
		}elseif($_GET["search"] == "xiaomi-mi-8-pro"){$titel ="Xiaomi Mi 8 Pro";
		}elseif($_GET["search"] == "xiaomi-mi-9"){$titel ="Xiaomi Mi 9";
		}elseif($_GET["search"] == "xiaomi-mi-9-se"){$titel ="Xiaomi Mi 9 SE";
		}elseif($_GET["search"] == "xiaomi-mi-a1"){$titel ="Xiaomi Mi A1";
		}elseif($_GET["search"] == "xiaomi-mi-a2"){$titel ="Xiaomi Mi A2";
		}elseif($_GET["search"] == "xiaomi-mi-a2-lite"){$titel ="Xiaomi Mi A2 Lite";
		}elseif($_GET["search"] == "xiaomi-mi-max"){$titel ="Xiaomi Mi Max";
		}elseif($_GET["search"] == "xiaomi-mi-max-2"){$titel ="Xiaomi Mi Max 2";
		}elseif($_GET["search"] == "xiaomi-mi-max-3"){$titel ="Xiaomi Mi Max 3";
		}elseif($_GET["search"] == "xiaomi-mi-max-prime"){$titel ="Xiaomi Mi Max Prime";
		}elseif($_GET["search"] == "xiaomi-mi-mix"){$titel ="Xiaomi Mi Mix";
		}elseif($_GET["search"] == "xiaomi-mi-mix-2"){$titel ="Xiaomi Mi Mix 2";
		}elseif($_GET["search"] == "xiaomi-mi-mix-2s"){$titel ="Xiaomi Mi Mix 2S";
		}elseif($_GET["search"] == "xiaomi-mi-mix-3"){$titel ="Xiaomi Mi Mix 3";
		}elseif($_GET["search"] == "xiaomi-mi-mix-3-5g"){$titel ="Xiaomi Mi Mix 3 5G";
		}elseif($_GET["search"] == "xiaomi-mi-note"){$titel ="Xiaomi Mi Note";
		}elseif($_GET["search"] == "xiaomi-mi-note-2"){$titel ="Xiaomi Mi Note 2";
		}elseif($_GET["search"] == "xiaomi-mi5"){$titel ="Xiaomi Mi5";
		}elseif($_GET["search"] == "xiaomi-mi8-youth"){$titel ="Xiaomi Mi8 Youth";
		}elseif($_GET["search"] == "xiaomi-pocophone-f1"){$titel ="Xiaomi Pocophone F1";
		}elseif($_GET["search"] == "xiaomi-redmi-2"){$titel ="Xiaomi RedMi 2";
		}elseif($_GET["search"] == "xiaomi-redmi-3"){$titel ="Xiaomi Redmi 3";
		}elseif($_GET["search"] == "xiaomi-redmi-4a"){$titel ="Xiaomi Redmi 4A";
		}elseif($_GET["search"] == "xiaomi-redmi-4x"){$titel ="Xiaomi Redmi 4X";
		}elseif($_GET["search"] == "xiaomi-redmi-5-plus"){$titel ="Xiaomi Redmi 5 Plus";
		}elseif($_GET["search"] == "xiaomi-redmi-6"){$titel ="Xiaomi Redmi 6";
		}elseif($_GET["search"] == "xiaomi-redmi-6a"){$titel ="Xiaomi Redmi 6a";
		}elseif($_GET["search"] == "xiaomi-redmi-note-2"){$titel ="Xiaomi Redmi Note 2";
		}elseif($_GET["search"] == "xiaomi-redmi-note-3"){$titel ="Xiaomi Redmi Note 3";
		}elseif($_GET["search"] == "xiaomi-redmi-note-4"){$titel ="Xiaomi Redmi Note 4";
		}elseif($_GET["search"] == "xiaomi-redmi-note-5"){$titel ="Xiaomi Redmi Note 5";
		}elseif($_GET["search"] == "xiaomi-redmi-note-5-pro"){$titel ="Xiaomi Redmi Note 5 Pro";
		}elseif($_GET["search"] == "xiaomi-redmi-note-5a"){$titel ="Xiaomi Redmi Note 5A";
		}elseif($_GET["search"] == "xiaomi-redmi-note-7-global"){$titel ="Xiaomi Redmi Note 7 Global";
		}elseif($_GET["search"] == "xiaomi-redmi-note-7-pro"){$titel ="Xiaomi Redmi Note 7 Pro";
		}elseif($_GET["search"] == "xiaomi-redmi-s2"){$titel ="Xiaomi Redmi S2";
		}elseif($_GET["search"] == "xiaomi-tech-mi-4i"){$titel ="Xiaomi Tech Mi 4i";
		}elseif($_GET["search"] == "xperia-c4"){$titel ="Xperia C4";
		}elseif($_GET["search"] == "xperia-c5-ultra"){$titel ="Xperia C5 Ultra";
		}elseif($_GET["search"] == "xperia-e1"){$titel ="Xperia E1";
		}elseif($_GET["search"] == "xperia-e3"){$titel ="Xperia E3";
		}elseif($_GET["search"] == "xperia-m"){$titel ="Xperia M";
		}elseif($_GET["search"] == "xperia-m2"){$titel ="Xperia M2";
		}elseif($_GET["search"] == "xperia-m4-aqua"){$titel ="Xperia M4 Aqua";
		}elseif($_GET["search"] == "xperia-m5"){$titel ="Xperia M5";
		}elseif($_GET["search"] == "xperia-t2"){$titel ="Xperia T2";
		}elseif($_GET["search"] == "xperia-x"){$titel ="Xperia X";
		}elseif($_GET["search"] == "xperia-xa"){$titel ="Xperia XA";
		}elseif($_GET["search"] == "xperia-xz2-premium"){$titel ="Xperia XZ2 Premium";
		}elseif($_GET["search"] == "xperia-xz3"){$titel ="Xperia XZ3";
		}elseif($_GET["search"] == "xperia-z-ultra"){$titel ="Xperia Z Ultra";
		}elseif($_GET["search"] == "xperia-z1"){$titel ="Xperia Z1";
		}elseif($_GET["search"] == "xperia-z1-compact"){$titel ="Xperia Z1 Compact";
		}elseif($_GET["search"] == "xperia-z2"){$titel ="Xperia Z2";
		}elseif($_GET["search"] == "xperia-z3"){$titel ="Xperia Z3";
		}elseif($_GET["search"] == "xperia-z3-compact"){$titel ="Xperia Z3 Compact";
		}elseif($_GET["search"] == "xperia-z3plus"){$titel ="Xperia Z3+";
		}elseif($_GET["search"] == "xperia-z5"){$titel ="Xperia Z5";
		}elseif($_GET["search"] == "xperia-z5-compact"){$titel ="Xperia Z5 Compact";
		}elseif($_GET["search"] == "xperia-z5-plus"){$titel ="Xperia Z5 Plus";
		}elseif($_GET["search"] == "xperia-z5-premium"){$titel ="Xperia Z5 Premium";
		}elseif($_GET["search"] == "xperia-z6"){$titel ="Xperia Z6";
		}elseif($_GET["search"] == "xplay-vivo-x6"){$titel ="Xplay Vivo X6";
		}elseif($_GET["search"] == "yamada-denki"){$titel ="Yamada Denki";
		}elseif($_GET["search"] == "yezz-4-5el2"){$titel ="Yezz 4.5EL2";
		}elseif($_GET["search"] == "yezz-5el-2-lte"){$titel ="Yezz 5EL 2 LTE";
		}elseif($_GET["search"] == "yezz-andy-4el2"){$titel ="Yezz Andy 4EL2";
		}elseif($_GET["search"] == "yezz-andy-5-5t-lte-vr"){$titel ="Yezz Andy 5.5T LTE VR";
		}elseif($_GET["search"] == "yezz-andy-5m-vr"){$titel ="Yezz Andy 5M VR";
		}elseif($_GET["search"] == "yezz-monaco-4-7"){$titel ="Yezz Monaco 4.7";
		}elseif($_GET["search"] == "yezz-sfera"){$titel ="Yezz Sfera";
		}elseif($_GET["search"] == "yota-yotaphone-2"){$titel ="Yota YotaPhone 2";
		}elseif($_GET["search"] == "yota-yotaphone-3"){$titel ="Yota YotaPhone 3";
		}elseif($_GET["search"] == "z5-pro-gt"){$titel ="Z5 Pro GT";
		}elseif($_GET["search"] == "zaydo-pulse"){$titel ="Zaydo Pulse";
		}elseif($_GET["search"] == "zenpad-10-z301mfl"){$titel ="ZenPad 10 (Z301MFL";
		}elseif($_GET["search"] == "zte-axon"){$titel ="ZTE Axon";
		}elseif($_GET["search"] == "zte-axon-10-pro-5g"){$titel ="ZTE Axon 10 Pro 5G";
		}elseif($_GET["search"] == "zte-axon-7"){$titel ="ZTE Axon 7";
		}elseif($_GET["search"] == "zte-axon-7-mini"){$titel ="ZTE Axon 7 Mini";
		}elseif($_GET["search"] == "zte-axon-elite"){$titel ="ZTE Axon Elite";
		}elseif($_GET["search"] == "zte-axon-mini"){$titel ="ZTE Axon Mini";
		}elseif($_GET["search"] == "zte-axon-mini-premium-edition"){$titel ="ZTE Axon Mini Premium Edition";
		}elseif($_GET["search"] == "zte-blade-a452"){$titel ="ZTE Blade A452";
		}elseif($_GET["search"] == "zte-blade-a512"){$titel ="ZTE Blade A512";
		}elseif($_GET["search"] == "zte-blade-a612"){$titel ="Zte Blade A612";
		}elseif($_GET["search"] == "zte-blade-a910"){$titel ="ZTE Blade A910";
		}elseif($_GET["search"] == "zte-blade-c341"){$titel ="ZTE Blade C341";
		}elseif($_GET["search"] == "zte-blade-l110"){$titel ="ZTE Blade L110";
		}elseif($_GET["search"] == "zte-blade-l3"){$titel ="ZTE Blade L3";
		}elseif($_GET["search"] == "zte-blade-l3-plus"){$titel ="ZTE Blade L3 Plus";
		}elseif($_GET["search"] == "zte-blade-l5"){$titel ="ZTE Blade L5";
		}elseif($_GET["search"] == "zte-blade-l5-plus"){$titel ="ZTE Blade L5 Plus";
		}elseif($_GET["search"] == "zte-blade-l6"){$titel ="ZTE Blade L6";
		}elseif($_GET["search"] == "zte-blade-l7a"){$titel ="ZTE Blade L7A";
		}elseif($_GET["search"] == "zte-blade-s6"){$titel ="ZTE Blade S6";
		}elseif($_GET["search"] == "zte-blade-s6plus"){$titel ="ZTE Blade S6+";
		}elseif($_GET["search"] == "zte-blade-v10"){$titel ="ZTE Blade V10";
		}elseif($_GET["search"] == "zte-blade-v580"){$titel ="ZTE Blade V580";
		}elseif($_GET["search"] == "zte-blade-v6"){$titel ="ZTE Blade V6";
		}elseif($_GET["search"] == "zte-blade-v7"){$titel ="ZTE Blade V7";
		}elseif($_GET["search"] == "zte-blade-v7-lite"){$titel ="ZTE Blade V7 Lite";
		}elseif($_GET["search"] == "zte-blade-v8"){$titel ="Zte Blade V8";
		}elseif($_GET["search"] == "zte-blade-v8-64-gb"){$titel ="ZTE Blade V8 64 GB";
		}elseif($_GET["search"] == "zte-blade-v8-lite"){$titel ="Zte Blade V8 Lite";
		}elseif($_GET["search"] == "zte-blade-v8-mini"){$titel ="Zte Blade V8 Mini";
		}elseif($_GET["search"] == "zte-blade-v9"){$titel ="ZTE Blade V9";
		}elseif($_GET["search"] == "zte-blade-v9-vita"){$titel ="ZTE Blade V9 Vita";
		}elseif($_GET["search"] == "zte-blade-vec-4g"){$titel ="ZTE Blade Vec 4G";
		}elseif($_GET["search"] == "zte-grand-s3"){$titel ="ZTE Grand S3";
		}elseif($_GET["search"] == "zte-nubia-x8"){$titel ="ZTE Nubia X8";
		}elseif($_GET["search"] == "zte-nubia-z9-max"){$titel ="ZTE Nubia Z9 Max";
		}elseif($_GET["search"] == "zte-nubia-z9-mini"){$titel ="ZTE Nubia Z9 Mini";
		}elseif($_GET["search"] == "zte-open-l"){$titel ="ZTE Open L";
		}elseif($_GET["search"] == "zte-star-2"){$titel ="ZTE Star 2";
		}elseif($_GET["search"] == "zte-z986"){$titel ="Zte Z986";
		}elseif($_GET["search"] == "zuk-z1"){$titel ="ZUK Z1";
		}elseif($_GET["search"] == "zuk-z2"){$titel ="ZUK Z2";
		}elseif($_GET["search"] == "zuk-z2-pro"){$titel ="ZUK Z2 Pro";
		}elseif($_GET["search"] == "amazon-fire-phone"){$titel ="Amazon Fire Phone";
		}elseif($_GET["search"] == "apple-ipad-pro"){$titel ="Apple iPad Pro";
		}elseif($_GET["search"] == "blakberry"){$titel ="Blakberry";
		}elseif($_GET["search"] == "c50"){$titel ="C50";
		}elseif($_GET["search"] == "g-flex-2"){$titel ="G Flex 2";
		}elseif($_GET["search"] == "g-play-mini"){$titel ="G Play mini";
		}elseif($_GET["search"] == "g2"){$titel ="G2";
		}elseif($_GET["search"] == "g2-mini"){$titel ="G2 mini";
		}elseif($_GET["search"] == "g3"){$titel ="G3";
		}elseif($_GET["search"] == "g3-s"){$titel ="G3 S";
		}elseif($_GET["search"] == "g4"){$titel ="G4";
		}elseif($_GET["search"] == "galaxy-a3-2016"){$titel ="Galaxy A3 2016";
		}elseif($_GET["search"] == "galaxy-a5-2016"){$titel ="Galaxy A5 2016";
		}elseif($_GET["search"] == "haier-voyage-v4"){$titel ="Haier Voyage V4";
		}elseif($_GET["search"] == "honor-4x"){$titel ="Honor 4X";
		}elseif($_GET["search"] == "htc"){$titel ="HTC";
		}elseif($_GET["search"] == "htc-desire-626"){$titel ="HTC Desire 626";
		}elseif($_GET["search"] == "htc-desire-728g"){$titel ="HTC Desire 728G";
		}elseif($_GET["search"] == "htc-desire-828w"){$titel ="HTC Desire 828w";
		}elseif($_GET["search"] == "huawei"){$titel ="Huawei";
		}elseif($_GET["search"] == "kodak"){$titel ="Kodak";
		}elseif($_GET["search"] == "l-bello"){$titel ="L Bello";
		}elseif($_GET["search"] == "l-fino"){$titel ="L Fino";
		}elseif($_GET["search"] == "l90"){$titel ="L90";
		}elseif($_GET["search"] == "lg-electronics"){$titel ="LG Electronics";
		}elseif($_GET["search"] == "lg-electronics-bello-ii"){$titel ="LG Electronics Bello II";
		}elseif($_GET["search"] == "lg-electronics-stylus-2-dabplus"){$titel ="LG Electronics Stylus 2 DAB+";
		}elseif($_GET["search"] == "medion"){$titel ="Medion";
		}elseif($_GET["search"] == "medion-x5004"){$titel ="Medion X5004";
		}elseif($_GET["search"] == "meizu"){$titel ="Meizu";
		}elseif($_GET["search"] == "microsoft-lumia-435"){$titel ="Microsoft Lumia 435";
		}elseif($_GET["search"] == "microsoft-lumia-532"){$titel ="Microsoft Lumia 532";
		}elseif($_GET["search"] == "microsoft-lumia-535"){$titel ="Microsoft Lumia 535";
		}elseif($_GET["search"] == "microsoft-lumia-550"){$titel ="Microsoft Lumia 550";
		}elseif($_GET["search"] == "microsoft-lumia-640-dual-sim"){$titel ="Microsoft Lumia 640 Dual SIM";
		}elseif($_GET["search"] == "microsoft-lumia-640-lte"){$titel ="Microsoft Lumia 640 LTE";
		}elseif($_GET["search"] == "microsoft-lumia-640-xl-dual-sim"){$titel ="Microsoft Lumia 640 XL Dual SIM";
		}elseif($_GET["search"] == "microsoft-lumia-840"){$titel ="Microsoft Lumia 840";
		}elseif($_GET["search"] == "microsoft-lumia-940"){$titel ="Microsoft Lumia 940";
		}elseif($_GET["search"] == "microsoft-lumia-940-xl"){$titel ="Microsoft Lumia 940 XL";
		}elseif($_GET["search"] == "microsoft-lumia-950"){$titel ="Microsoft Lumia 950";
		}elseif($_GET["search"] == "microsoft-lumia-950-xl"){$titel ="Microsoft Lumia 950 XL";
		}elseif($_GET["search"] == "mobiwire"){$titel ="MobiWire";
		}elseif($_GET["search"] == "motorola"){$titel ="Motorola";
		}elseif($_GET["search"] == "nexus-6"){$titel ="Nexus 6";
		}elseif($_GET["search"] == "nexus-6p"){$titel ="Nexus 6P";
		}elseif($_GET["search"] == "nokia"){$titel ="Nokia";
		}elseif($_GET["search"] == "oneplus"){$titel ="OnePlus";
		}elseif($_GET["search"] == "oppo"){$titel ="Oppo";
		}elseif($_GET["search"] == "optimus-g-pro-lite"){$titel ="Optimus G Pro Lite";
		}elseif($_GET["search"] == "p8"){$titel ="P8";
		}elseif($_GET["search"] == "p8-lite"){$titel ="P8 lite";
		}elseif($_GET["search"] == "p8-max"){$titel ="P8 Max";
		}elseif($_GET["search"] == "phicomm-clue-m-plus"){$titel ="Phicomm Clue M Plus";
		}elseif($_GET["search"] == "philcomm"){$titel ="Philcomm";
		}elseif($_GET["search"] == "samsung-galaxy-a9"){$titel ="Samsung Galaxy A9";
		}elseif($_GET["search"] == "samsung-galaxy-grand-on"){$titel ="Samsung Galaxy Grand On";
		}elseif($_GET["search"] == "samsung-galaxy-j2"){$titel ="Samsung Galaxy J2";
		}elseif($_GET["search"] == "samsung-galaxy-j3"){$titel ="Samsung Galaxy J3";
		}elseif($_GET["search"] == "samsung-galaxy-j3-duos-2016"){$titel ="Samsung Galaxy J3 Duos (2016)";
		}elseif($_GET["search"] == "samsung-galaxy-j5-2016"){$titel ="Samsung Galaxy J5 (2016)";
		}elseif($_GET["search"] == "samsung-galaxy-note7"){$titel ="Samsung Galaxy Note7";
		}elseif($_GET["search"] == "samsung-galaxy-o5"){$titel ="Samsung Galaxy O5";
		}elseif($_GET["search"] == "samsung-galaxy-o7"){$titel ="Samsung Galaxy O7";
		}elseif($_GET["search"] == "samsung-galaxy-on5"){$titel ="Samsung Galaxy On5";
		}elseif($_GET["search"] == "samsung-galaxy-on7"){$titel ="Samsung Galaxy On7";
		}elseif($_GET["search"] == "samsung-galaxy-s5-plus"){$titel ="Samsung Galaxy S5 Plus";
		}elseif($_GET["search"] == "samsung-galaxy-s7-edge"){$titel ="Samsung Galaxy S7 Edge";
		}elseif($_GET["search"] == "samsung-galaxy-s7-edge-plus"){$titel ="Samsung Galaxy S7 Edge (Plus)";
		}elseif($_GET["search"] == "sony-xperia-c4"){$titel ="Sony Xperia C4";
		}elseif($_GET["search"] == "sony-xperia-z5"){$titel ="Sony Xperia Z5";
		}elseif($_GET["search"] == "sony-xperia-z5-plus"){$titel ="Sony Xperia Z5 Plus";
		}elseif($_GET["search"] == "sony-xperia-z5-premium"){$titel ="Sony Xperia Z5 Premium";
		}elseif($_GET["search"] == "sony-xperia-z6"){$titel ="Sony Xperia Z6";
		}elseif($_GET["search"] == "soolpad-porto-s"){$titel ="Soolpad Porto S";
		}elseif($_GET["search"] == "trekstor-surftab-duo-w1"){$titel ="TrekStor SurfTab duo W1";
		}elseif($_GET["search"] == "wiko"){$titel ="Wiko";
		}elseif($_GET["search"] == "wiko-pulp-3g"){$titel ="Wiko Pulp 3G";
		}elseif($_GET["search"] == "wiko-pulp-4g"){$titel ="Wiko Pulp 4G";
		}elseif($_GET["search"] == "wiko-pulp-fab-4g"){$titel ="Wiko Pulp Fab 4G";
		}elseif($_GET["search"] == "xiaomi"){$titel ="Xiaomi";
		}elseif($_GET["search"] == "xiaomi-mi-pad-2"){$titel ="Xiaomi Mi Pad 2";
		}elseif($_GET["search"] == "y3"){$titel ="Y3";
		}elseif($_GET["search"] == "y625"){$titel ="Y625";
		}elseif($_GET["search"] == "y635"){$titel ="Y635";
		}elseif($_GET["search"] == "y70"){$titel ="Y70";
		}elseif($_GET["search"] == "yota"){$titel ="Yota";
		}elseif($_GET["search"] == "zte"){$titel ="ZTE";
		}elseif($_GET["search"] == "zte-blade-a530"){$titel ="ZTE Blade A530";
		}elseif($_GET["search"] == "sony-xperia-5"){$titel ="Sony Xperia 5";
		}elseif($_GET["search"] == "motorola-one-zoom"){$titel ="Motorola One Zoom";
		}elseif($_GET["search"] == "motorola-moto-e6-plus"){$titel ="Motorola Moto E6 Plus";
		}elseif($_GET["search"] == "amplicom-powertel-m4000"){$titel ="amplicom PowerTel M4000";
		}elseif($_GET["search"] == "amplicom-powertel-m4500"){$titel ="amplicom PowerTel M4500";
		}elseif($_GET["search"] == "amplicom-powertel-m5000"){$titel ="amplicom PowerTel M5000";
		}elseif($_GET["search"] == "amplicom-powertel-m5010"){$titel ="amplicom PowerTel M5010";
		}elseif($_GET["search"] == "amplicom-powertel-m6000"){$titel ="amplicom PowerTel M6000";
		}elseif($_GET["search"] == "amplicom-powertel-m7000"){$titel ="amplicom PowerTel M7000";
		}elseif($_GET["search"] == "huawei-y5-2019"){$titel ="Huawei Y5 (2019)";
		}elseif($_GET["search"] == "acer-neotouch-p300"){$titel ="ACER neoTouch P300";
		}elseif($_GET["search"] == "nokia-7-2"){$titel ="Nokia 7.2";
		}elseif($_GET["search"] == "acer-neotouch-p400"){$titel ="ACER neoTouch P400";
		}elseif($_GET["search"] == "motorola-moto-e6-plus"){$titel ="Motorola Moto E6 Plus";
		}elseif($_GET["search"] == "acer-neotouch-s200"){$titel ="ACER neoTouch S200";
		}elseif($_GET["search"] == "lg-g8x-thinq"){$titel ="LG G8X THinQ";
		}elseif($_GET["search"] == "ecom-ex-handy-05"){$titel ="ecom Ex-Handy 05";
		}elseif($_GET["search"] == "motorola-one-zoom"){$titel ="Motorola One Zoom";
		}elseif($_GET["search"] == "ecom-ex-handy-06"){$titel ="ecom Ex-Handy 06";
		}elseif($_GET["search"] == "sony-xperia-5"){$titel ="Sony Xperia 5";
		}elseif($_GET["search"] == "lg-optimus-net"){$titel ="LG Optimus Net";
		}elseif($_GET["search"] == "gigaset-gx290"){$titel ="Gigaset GX290";
		}elseif($_GET["search"] == "medicalmarketingberlin-handy-sana-210"){$titel ="MedicalMarketingBerlin Handy sana 210";
		}elseif($_GET["search"] == "zte-blade-a530"){$titel ="ZTE Blade A530";
		}elseif($_GET["search"] == "nec-e228"){$titel ="NEC e228";
		}elseif($_GET["search"] == "nec-e313"){$titel ="NEC e313";
		}elseif($_GET["search"] == "huawei-y5-2019"){$titel ="Huawei Y5 (2019)";
		}elseif($_GET["search"] == "nec-e338"){$titel ="NEC E338";
		}elseif($_GET["search"] == "gigaset-gx290"){$titel ="Gigaset GX290";
		}elseif($_GET["search"] == "nec-e353"){$titel ="NEC e353";
		}elseif($_GET["search"] == "nec-e525"){$titel ="NEC e525";
		}elseif($_GET["search"] == "nec-e606"){$titel ="NEC e606";
		}elseif($_GET["search"] == "nokia-7-2"){$titel ="Nokia 7.2";
		}elseif($_GET["search"] == "nec-e616"){$titel ="NEC e616";
		}elseif($_GET["search"] == "nec-e616v"){$titel ="NEC e616v";
		}elseif($_GET["search"] == "nec-e808n-e808s"){$titel ="NEC e808n/e808s";
		}elseif($_GET["search"] == "nec-e808y"){$titel ="NEC e808y";
		}elseif($_GET["search"] == "nec-e949"){$titel ="NEC e949";
		}elseif($_GET["search"] == "nec-n21i"){$titel ="NEC n21i";
		}elseif($_GET["search"] == "nec-n223i"){$titel ="NEC n223i";
		}elseif($_GET["search"] == "nec-n22i"){$titel ="NEC n22i";
		}elseif($_GET["search"] == "nec-n31i"){$titel ="NEC N31i";
		}elseif($_GET["search"] == "nec-n400i"){$titel ="NEC N400i";
		}elseif($_GET["search"] == "nec-n410i"){$titel ="NEC n410i";
		}elseif($_GET["search"] == "o2-xda-neo"){$titel ="O2 XDA neo";
		}elseif($_GET["search"] == "oppo-neo-7-lte"){$titel ="Oppo Neo 7 LTE";
		}elseif($_GET["search"] == "playboy-playboy-handy"){$titel ="Playboy Playboy-Handy";
		}elseif($_GET["search"] == "samsung-ativ-s-neo"){$titel ="Samsung Ativ S Neo";
		}elseif($_GET["search"] == "samsung-galaxy-grand-neo"){$titel ="Samsung Galaxy Grand Neo";
		}elseif($_GET["search"] == "samsung-galaxy-note-3-neo-3g"){$titel ="Samsung Galaxy Note 3 Neo 3G";
		}elseif($_GET["search"] == "samsung-galaxy-note-3-neo-lteplus"){$titel ="Samsung Galaxy Note 3 Neo LTE+";
		}elseif($_GET["search"] == "samsung-galaxy-s3-neo"){$titel ="Samsung Galaxy S3 Neo";
		}elseif($_GET["search"] == "samsung-galaxy-s5-schwarz-front"){$titel ="Samsung Galaxy S5 Schwarz Front";
		}elseif($_GET["search"] == "simvalley-mobile-handy-xt-300"){$titel ="simvalley MOBILE Handy XT-300";
		}elseif($_GET["search"] == "sony-ericsson-xperia-neo"){$titel ="Sony Ericsson Xperia neo";
		}elseif($_GET["search"] == "sony-ericsson-xperia-neo-v"){$titel ="Sony Ericsson Xperia neo V";
		}elseif($_GET["search"] == "tcm-tchibo-aktions-handy-405"){$titel ="TCM (Tchibo) Aktions-Handy 405";
		}elseif($_GET["search"] == "tcm-tchibo-foto-handy"){$titel ="TCM (Tchibo) Foto-Handy";
		}elseif($_GET["search"] == "tcm-tchibo-foto-handy-302"){$titel ="TCM (Tchibo) Foto-Handy 302";
		}elseif($_GET["search"] == "tcm-tchibo-foto-handy-303"){$titel ="TCM (Tchibo) Foto-Handy 303";
		}elseif($_GET["search"] == "tcm-tchibo-foto-handy-701"){$titel ="TCM (Tchibo) Foto-Handy 701";
		}elseif($_GET["search"] == "tcm-tchibo-klapp-handy"){$titel ="TCM (Tchibo) Klapp-Handy";
		}elseif($_GET["search"] == "tcm-tchibo-klapp-handy-105"){$titel ="TCM (Tchibo) Klapp-Handy 105";
		}elseif($_GET["search"] == "tcm-tchibo-klapp-handy-2"){$titel ="TCM (Tchibo) Klapp-Handy 2";
		}elseif($_GET["search"] == "tcm-tchibo-klapp-handy-206"){$titel ="TCM (Tchibo) Klapp-Handy 206";
		}elseif($_GET["search"] == "tcm-tchibo-klapp-handy-207"){$titel ="TCM (Tchibo) Klapp-Handy 207";
		}elseif($_GET["search"] == "tcm-tchibo-kompakt-handy"){$titel ="TCM (Tchibo) Kompakt-Handy";
		}elseif($_GET["search"] == "tcm-tchibo-kompakt-handy-103"){$titel ="TCM (Tchibo) Kompakt-Handy 103";
		}elseif($_GET["search"] == "tcm-tchibo-kompakt-handy-104"){$titel ="TCM (Tchibo) Kompakt-Handy 104";
		}elseif($_GET["search"] == "tcm-tchibo-kompakt-handy-106"){$titel ="TCM (Tchibo) Kompakt-Handy 106";
		}elseif($_GET["search"] == "tcm-tchibo-kompakt-handy-107"){$titel ="TCM (Tchibo) Kompakt-Handy 107";
		}elseif($_GET["search"] == "tcm-tchibo-kompakt-handy-108"){$titel ="TCM (Tchibo) Kompakt-Handy 108";
		}elseif($_GET["search"] == "tcm-tchibo-kompakt-handy-112"){$titel ="TCM (Tchibo) Kompakt-Handy 112";
		}elseif($_GET["search"] == "tcm-tchibo-kompakt-handy-2"){$titel ="TCM (Tchibo) Kompakt-Handy 2";
		}elseif($_GET["search"] == "tcm-tchibo-kompakt-handy-204"){$titel ="TCM (Tchibo) Kompakt-Handy 204";
		}elseif($_GET["search"] == "tecmobile-handy-100"){$titel ="tecmobile Handy 100";
		}elseif($_GET["search"] == "tecmobile-handy-150"){$titel ="tecmobile Handy 150";
		}elseif($_GET["search"] == "tevion-multimedia-handy"){$titel ="Tevion Multimedia-Handy";
		}elseif($_GET["search"] == "vertu-new-signature-touch"){$titel ="Vertu New Signature Touch";
		}elseif($_GET["search"] == "apple-iphone-11-pro-max"){$titel ="Apple iPhone 11 Pro Max";
		}elseif($_GET["search"] == "iphone-11-pro-max"){$titel ="iPhone 11 Pro Max";
		}elseif($_GET["search"] == "apple-iphone-11"){$titel ="Apple iPhone 11";
		}elseif($_GET["search"] == "iphone-11"){$titel ="iPhone 11";
		}elseif($_GET["search"] == "apple-iphone-11-pro"){$titel ="Apple iPhone 11 Pro";
		}elseif($_GET["search"] == "iphone-11-pro"){$titel ="iPhone 11 Pro";
		}elseif($_GET["search"] == "allview-soul-x6-xtreme"){$titel ="Allview Soul X6 Xtreme";
		}elseif($_GET["search"] == "allview-soul-x6-mini"){$titel ="Allview Soul X6 Mini";
		}elseif($_GET["search"] == "altek-leo"){$titel ="altek Leo";
		}elseif($_GET["search"] == "amazon-fire-phone"){$titel ="Amazon Fire Phone";
		}elseif($_GET["search"] == "archos-access-45-4g"){$titel ="Archos Access 45 4G";
		}elseif($_GET["search"] == "archos-access-50-4g"){$titel ="Archos Access 50 4G";
		}elseif($_GET["search"] == "archos-50f-helium-lite"){$titel ="Archos 50f Helium Lite";
		}elseif($_GET["search"] == "archos-sense-50x"){$titel ="Archos Sense 50X";
		}elseif($_GET["search"] == "archos-50-neon"){$titel ="Archos 50 Neon";
		}elseif($_GET["search"] == "archos-diamond-omega"){$titel ="Archos Diamond Omega";
		}elseif($_GET["search"] == "asus-zenfone-6-2019"){$titel ="Asus Zenfone 6 (2019)";
		}elseif($_GET["search"] == "asus-rog-phone-2"){$titel ="Asus ROG Phone 2";
		}elseif($_GET["search"] == "asus-padfone-4"){$titel ="Asus Padfone 4";
		}elseif($_GET["search"] == "asus-zenfone-3-ze552kl"){$titel ="Asus ZenFone 3 (ZE552KL)";
		}elseif($_GET["search"] == "asus-zenfone-4-pro"){$titel ="Asus ZenFone 4 Pro";
		}elseif($_GET["search"] == "asus-zenfone-4-max-5-2-zoll"){$titel ="Asus ZenFone 4 Max 5.2 Zoll";
		}elseif($_GET["search"] == "asus-zenfone-2-4gb-ram"){$titel ="Asus ZenFone 2 4GB RAM";
		}elseif($_GET["search"] == "asus-fonepad-7"){$titel ="Asus Fonepad 7";
		}elseif($_GET["search"] == "at-mobile-at-cobra"){$titel ="AT Mobile AT Cobra";
		}elseif($_GET["search"] == "at-mobile-at-cricket"){$titel ="AT Mobile At Cricket";
		}elseif($_GET["search"] == "at-mobile-at-ant"){$titel ="AT Mobile At Ant";
		}elseif($_GET["search"] == "at-mobile-at-bee"){$titel ="AT Mobile At Bee";
		}elseif($_GET["search"] == "at-mobile-at-bear"){$titel ="AT Mobile AT Bear";
		}elseif($_GET["search"] == "at-mobile-at-pelican"){$titel ="AT Mobile AT Pelican";
		}elseif($_GET["search"] == "at-mobile-at-viper"){$titel ="AT Mobile AT Viper";
		}elseif($_GET["search"] == "at-mobile-at-butterfly"){$titel ="AT Mobile At Butterfly";
		}elseif($_GET["search"] == "at-mobile-at-spider"){$titel ="AT Mobile At Spider";
		}elseif($_GET["search"] == "at-mobile-at-eagle"){$titel ="AT Mobile AT Eagle";
		}elseif($_GET["search"] == "at-mobile-at-falcon"){$titel ="AT Mobile AT Falcon";
		}elseif($_GET["search"] == "audioline-mt-1000"){$titel ="Audioline MT 1000";
		}elseif($_GET["search"] == "auro-comfort-1020"){$titel ="AURO Comfort 1020";
		}elseif($_GET["search"] == "auro-compact-6321"){$titel ="AURO Compact 6321";
		}elseif($_GET["search"] == "auro-classic-2010"){$titel ="AURO Classic 2010";
		}elseif($_GET["search"] == "auro-m101"){$titel ="AURO M101";
		}elseif($_GET["search"] == "auro-event"){$titel ="AURO Event";
		}elseif($_GET["search"] == "auro-classic-8510"){$titel ="AURO Classic 8510";
		}elseif($_GET["search"] == "auro-m301"){$titel ="AURO M301";
		}elseif($_GET["search"] == "auro-comfort-1060"){$titel ="AURO Comfort 1060";
		}elseif($_GET["search"] == "auro-comfort-1010"){$titel ="AURO Comfort 1010";
		}elseif($_GET["search"] == "auro-m401"){$titel ="AURO M401";
		}elseif($_GET["search"] == "auro-m451"){$titel ="AURO M451";
		}elseif($_GET["search"] == "auro-s204"){$titel ="AURO S204";
		}elseif($_GET["search"] == "auro-s201"){$titel ="AURO S201";
		}elseif($_GET["search"] == "axia-a308"){$titel ="AXIA A308";
		}elseif($_GET["search"] == "base-lutea"){$titel ="Base Lutea";
		}elseif($_GET["search"] == "base-lutea-2"){$titel ="Base Lutea 2";
		}elseif($_GET["search"] == "bellpepper-twinbell"){$titel ="BellPepper TwinBell";
		}elseif($_GET["search"] == "benefon-twin"){$titel ="Benefon Twin";
		}elseif($_GET["search"] == "benefon-q"){$titel ="Benefon Q";
		}elseif($_GET["search"] == "benefon-p331"){$titel ="Benefon P331";
		}elseif($_GET["search"] == "benefon-twig"){$titel ="Benefon Twig";
		}elseif($_GET["search"] == "benefon-track-pro-1-1nt"){$titel ="Benefon Track Pro 1.1NT";
		}elseif($_GET["search"] == "benefon-track-one-nt"){$titel ="Benefon Track One NT";
		}elseif($_GET["search"] == "benefon-esc"){$titel ="Benefon ESC!";
		}elseif($_GET["search"] == "siemens-a70"){$titel ="Siemens A70";
		}elseif($_GET["search"] == "siemens-a50"){$titel ="Siemens A50";
		}elseif($_GET["search"] == "benq-siemens-c55"){$titel ="BenQ-Siemens C55";
		}elseif($_GET["search"] == "siemens-mc60"){$titel ="Siemens MC60";
		}elseif($_GET["search"] == "benq-siemens-c35"){$titel ="BenQ-Siemens C35";
		}elseif($_GET["search"] == "siemens-me45"){$titel ="Siemens ME45";
		}elseif($_GET["search"] == "benq-siemens-a55"){$titel ="BenQ-Siemens A55";
		}elseif($_GET["search"] == "siemens-cf62"){$titel ="Siemens CF62";
		}elseif($_GET["search"] == "benq-siemens-s68"){$titel ="BenQ-Siemens S68";
		}elseif($_GET["search"] == "benq-siemens-s65"){$titel ="BenQ-Siemens S65";
		}elseif($_GET["search"] == "benq-siemens-s55"){$titel ="BenQ-Siemens S55";
		}elseif($_GET["search"] == "siemens-m65"){$titel ="Siemens M65";
		}elseif($_GET["search"] == "siemens-m55"){$titel ="Siemens M55";
		}elseif($_GET["search"] == "siemens-a57"){$titel ="Siemens A57";
		}elseif($_GET["search"] == "siemens-a60"){$titel ="Siemens A60";
		}elseif($_GET["search"] == "siemens-m50"){$titel ="Siemens M50";
		}elseif($_GET["search"] == "benq-siemens-a31"){$titel ="BenQ-Siemens A31";
		}elseif($_GET["search"] == "siemens-s45i"){$titel ="Siemens S45i";
		}elseif($_GET["search"] == "benq-siemens-sx1"){$titel ="BenQ-Siemens SX1";
		}elseif($_GET["search"] == "blackberry-z10"){$titel ="Blackberry Z10";
		}elseif($_GET["search"] == "blackberry-porsche-design-p9983"){$titel ="Blackberry Porsche Design P9983";
		}elseif($_GET["search"] == "blackview-bv4000-pro"){$titel ="Blackview BV4000 Pro";
		}elseif($_GET["search"] == "samsung-galaxy-a70"){$titel ="Samsung Galaxy A70";
		}elseif($_GET["search"] == "xiaomi-mi-9"){$titel ="Xiaomi Mi 9";
		}elseif($_GET["search"] == "samsung-galaxy-a10"){$titel ="Samsung Galaxy A10";
		}elseif($_GET["search"] == "samsung-galaxy-note-10"){$titel ="Samsung Galaxy Note 10";
		}elseif($_GET["search"] == "samsung-galaxy-s7"){$titel ="Samsung Galaxy S7";
		}elseif($_GET["search"] == "samsung-galaxy-a80"){$titel ="Samsung Galaxy A80";
		}elseif($_GET["search"] == "sony-xperia-5"){$titel ="Sony Xperia 5";
		}elseif($_GET["search"] == "motorola-one-zoom"){$titel ="Motorola One Zoom";
		}elseif($_GET["search"] == "motorola-moto-e6-plus"){$titel ="Motorola Moto E6 Plus";
		}elseif($_GET["search"] == "lg-g8x-thinq"){$titel ="LG G8X THinQ";
		}elseif($_GET["search"] == "huawei-y5-2019"){$titel ="Huawei Y5 (2019)";
		}elseif($_GET["search"] == "gigaset-gx290"){$titel ="Gigaset GX290";
		}elseif($_GET["search"] == "zte-blade-a530"){$titel ="ZTE Blade A530";
		}elseif($_GET["search"] == "lg-k20"){$titel ="LG K20";
		}elseif($_GET["search"] == "wiko-y80"){$titel ="Wiko Y80";
		}elseif($_GET["search"] == "xiaomi-redmi-7a"){$titel ="Xiaomi Redmi 7A";
		}elseif($_GET["search"] == "fairphone-fairphone-3"){$titel ="Fairphone Fairphone 3";
		}elseif($_GET["search"] == "samsung-galaxy-a30s"){$titel ="Samsung Galaxy A30s";
		}elseif($_GET["search"] == "lg-k50s"){$titel ="LG K50S";
		}elseif($_GET["search"] == "lg-k40s"){$titel ="LG K40S";
		}elseif($_GET["search"] == "huawei-mate-30"){$titel ="Huawei Mate 30";
		}elseif($_GET["search"] == "huawei-mate-30-pro"){$titel ="Huawei Mate 30 Pro";
		}elseif($_GET["search"] == "xiaomi-mi-9t-pro"){$titel ="Xiaomi Mi 9T Pro";
		}elseif($_GET["search"] == "htc-desire-19-plus"){$titel ="HTC Desire 19 Plus";
		}elseif($_GET["search"] == "nokia-2-2-2019"){$titel ="Nokia 2.2 (2019)";
		}elseif($_GET["search"] == "motorola-one-action"){$titel ="Motorola one action";
		}elseif($_GET["search"] == "samsung-galaxy-note-10plus-5g"){$titel ="Samsung Galaxy Note 10+ 5G";
		}elseif($_GET["search"] == "xiaomi-mi-a3"){$titel ="Xiaomi Mi A3";
		}elseif($_GET["search"] == "o2-xda"){$titel ="O2 XDA";
		}elseif($_GET["search"] == "motorola-m930"){$titel ="Motorola M930";
		}elseif($_GET["search"] == "sagem-my100x"){$titel ="Sagem my100X";
		}elseif($_GET["search"] == "nokia-6500-classic"){$titel ="Nokia 6500 Classic";
		}elseif($_GET["search"] == "samsung-sgh-g800"){$titel ="Samsung SGH-G800";
		}elseif($_GET["search"] == "general-mobile-dst-11"){$titel ="General Mobile DST 11";
		}elseif($_GET["search"] == "o2-xda-orbit-2"){$titel ="O2 XDA orbit 2";
		}elseif($_GET["search"] == "sony-ericsson-k660i"){$titel ="Sony Ericsson K660i";
		}elseif($_GET["search"] == "sony-ericsson-w380i"){$titel ="Sony Ericsson W380i";
		}elseif($_GET["search"] == "sony-ericsson-w890i"){$titel ="Sony Ericsson W890i";
		}elseif($_GET["search"] == "blackberry-pearl-8120"){$titel ="Blackberry Pearl 8120";
		}elseif($_GET["search"] == "ixi-mobile-ogo-ct-25e"){$titel ="IXI Mobile Ogo CT-25E";
		}elseif($_GET["search"] == "motorola-w218"){$titel ="Motorola W218";
		}elseif($_GET["search"] == "alcatel-mandarina-duck"){$titel ="Alcatel Mandarina Duck";
		}elseif($_GET["search"] == "samsung-sgh-c170"){$titel ="Samsung SGH-C170";
		}elseif($_GET["search"] == "vertu-constellation"){$titel ="Vertu Constellation";
		}elseif($_GET["search"] == "elson-el-590"){$titel ="Elson EL 590";
		}elseif($_GET["search"] == "motorola-razr-v3i"){$titel ="Motorola Razr V3i";
		}elseif($_GET["search"] == "samsung-sgh-d600"){$titel ="Samsung SGH-D600";
		}elseif($_GET["search"] == "nokia-8910i"){$titel ="Nokia 8910i";
		}elseif($_GET["search"] == "nokia-6510"){$titel ="Nokia 6510";
		}elseif($_GET["search"] == "nokia-3510i"){$titel ="Nokia 3510i";
		}elseif($_GET["search"] == "nokia-3330"){$titel ="Nokia 3330";
		}elseif($_GET["search"] == "sony-ericsson-j120i"){$titel ="Sony Ericsson J120i";
		}elseif($_GET["search"] == "google-pixel-4"){$titel ="Google Pixel 4";
		}elseif($_GET["search"] == "xiaomi-redmi-note-8-pro "){$titel ="Xiaomi Redmi Note 8 Pro ";
		}elseif($_GET["search"] == "motorola-moto-g8"){$titel ="Motorola Moto G8";
		}elseif($_GET["search"] == "xiaomi-mi-note-10"){$titel ="Xiaomi Mi Note 10";
		}elseif($_GET["search"] == "huawei-p30-lite-new-edition"){$titel ="Huawei P30 lite New Edition";
		}elseif($_GET["search"] == "samsung-galaxy-fold"){$titel ="Samsung Galaxy Fold";
		}elseif($_GET["search"] == "samsung-galaxy-a71"){$titel ="Samsung Galaxy A71";
		}elseif($_GET["search"] == "xiaomi-redmi-note-8-pro"){$titel ="Xiaomi Redmi Note 8 Pro";
		}elseif($_GET["search"] == "wiko-view4-lite"){$titel ="Wiko View4 Lite";
		}elseif($_GET["search"] == "wiko-view4"){$titel ="Wiko View4";
		}elseif($_GET["search"] == "oppo-reno2-z"){$titel ="Oppo Reno2 Z";
		}elseif($_GET["search"] == "huawei-p40-lite"){$titel ="Huawei P40 Lite";
		}elseif($_GET["search"] == "oppo-reno2"){$titel ="Oppo Reno2";
		}elseif($_GET["search"] == "lg-k41s"){$titel ="LG K41S";
		}elseif($_GET["search"] == "lg-k51s"){$titel ="LG K51S";
		}elseif($_GET["search"] == "lg-k61"){$titel ="LG K61";
		}elseif($_GET["search"] == "sony-xperia-10-ii"){$titel ="Sony Xperia 10 II";
		}elseif($_GET["search"] == "sony-xperia-1-ii"){$titel ="Sony Xperia 1 II";
		}elseif($_GET["search"] == "huawei-honor-9x-pro"){$titel ="Huawei Honor 9X Pro";
		}elseif($_GET["search"] == "lg-v60-thinq-5g"){$titel ="LG V60 ThinQ 5G";
		}elseif($_GET["search"] == "sony-xperia-l4"){$titel ="Sony Xperia L4";
		}elseif($_GET["search"] == "carbon-1-mkii"){$titel ="Carbon 1 MKII";
		}elseif($_GET["search"] == "huawei-mate-xs"){$titel ="Huawei Mate Xs";
		}elseif($_GET["search"] == "samsung-galaxy-z-flip"){$titel ="Samsung Galaxy Z Flip";
		}elseif($_GET["search"] == "motorola-moto-g8-power"){$titel ="Motorola Moto G8 Power";
		}elseif($_GET["search"] == "samsung-galaxy-xcover-pro"){$titel ="Samsung Galaxy XCover Pro";
		}elseif($_GET["search"] == "samsung-galaxy-s20-ultra"){$titel ="Samsung Galaxy S20 Ultra";
		}elseif($_GET["search"] == "samsung-galaxy-s20-plus"){$titel ="Samsung Galaxy S20+";
		}elseif($_GET["search"] == "samsung-galaxy-s20"){$titel ="Samsung Galaxy S20";
		}elseif($_GET["search"] == "huawei-y6s"){$titel ="Huawei Y6s";
		}elseif($_GET["search"] == "huawei-p-smart-pro-daten"){$titel ="Huawei P smart Pro Daten";
		}elseif($_GET["search"] == "oppo-find-x2-pro"){$titel ="Oppo Find X2 Pro";
		}elseif($_GET["search"] == "oppo-find-x2"){$titel ="Oppo Find X2";
		}elseif($_GET["search"] == "samsung-galaxy-a51"){$titel ="Samsung Galaxy A51";
		}elseif($_GET["search"] == "realme-5-pro"){$titel ="realme 5 Pro";
		}elseif($_GET["search"] == "htc-desire-19-plus"){$titel ="HTC Desire 19+";
		}elseif($_GET["search"] == "gigaset-gs290"){$titel ="Gigaset GS290";
		}elseif($_GET["search"] == "xiaomi-mi-note-10-pro"){$titel ="Xiaomi Mi Note 10 Pro";
		}elseif($_GET["search"] == "realme-x2-pro"){$titel ="realme X2 Pro";
		}elseif($_GET["search"] == "doro-8080"){$titel ="Doro 8080";
		}elseif($_GET["search"] == "honor-9x"){$titel ="Honor 9X";
		}elseif($_GET["search"] == "cat-s52"){$titel ="CAT S52";
		}elseif($_GET["search"] == "blackview-bv9100"){$titel ="Blackview BV9100";
		}elseif($_GET["search"] == "tp-link-neffos-x20"){$titel ="TP-Link Neffos X20";
		}elseif($_GET["search"] == "nokia-800-tough"){$titel ="Nokia 800 Tough";
		}elseif($_GET["search"] == "ulefone-power-6"){$titel ="Ulefone Power 6";
		}elseif($_GET["search"] == "motorola-one-macro"){$titel ="Motorola One Macro";
		}elseif($_GET["search"] == "samsung-galaxy-m30s"){$titel ="Samsung Galaxy M30s";
		}elseif($_GET["search"] == "google-pixel-4-xl"){$titel ="Google Pixel 4 XL";
		}elseif($_GET["search"] == "xiaomi-black-shark-2-pro"){$titel ="Xiaomi Black Shark 2 Pro";
		}elseif($_GET["search"] == "oneplus-7t-pro"){$titel ="OnePlus 7T Pro";
		}elseif($_GET["search"] == "galaxy-a90-5g"){$titel ="Galaxy A90 5G";
		}elseif($_GET["search"] == "beafon-m6"){$titel ="Beafon M6";
		}elseif($_GET["search"] == "motorola-one-pro"){$titel ="Motorola One Pro";
		}elseif($_GET["search"] == "motorola-one-vision"){$titel ="Motorola One Vision";
		}elseif($_GET["search"] == "motorola-razr"){$titel ="Motorola RAZR";
		}elseif($_GET["search"] == "motorola-razr-5g"){$titel ="Motorola RAZR 5G";
		}elseif($_GET["search"] == "nokia-2.2"){$titel ="Nokia 2.2";
		}elseif($_GET["search"] == "nokia-5.3"){$titel ="Nokia 5.3";
		}elseif($_GET["search"] == "note-20-serie"){$titel ="Note 20-Serie";
		}elseif($_GET["search"] == "nubia-red-magic-3"){$titel ="Nubia Red Magic 3";
		}elseif($_GET["search"] == "nubia-z20"){$titel ="Nubia Z20";
		}elseif($_GET["search"] == "oneplus-8"){$titel ="OnePlus 8";
		}elseif($_GET["search"] == "oneplus-8-pro"){$titel ="OnePlus 8 Pro";
		}elseif($_GET["search"] == "oneplus-8t-pro"){$titel ="OnePlus 8T Pro";
		}elseif($_GET["search"] == "oppo-a52"){$titel ="OPPO A52";
		}elseif($_GET["search"] == "oppo-a53"){$titel ="Oppo A53";
		}elseif($_GET["search"] == "oppo-a53s"){$titel ="Oppo A53s";
		}elseif($_GET["search"] == "oppo-a72"){$titel ="OPPO A72";
		}elseif($_GET["search"] == "oppo-reno-4-5g"){$titel ="OPPO Reno 4 5G";
		}elseif($_GET["search"] == "oppo-reno-4-pro-5g"){$titel ="OPPO Reno 4 Pro 5G";
		}elseif($_GET["search"] == "oppo-reno-4-z-5g"){$titel ="OPPO Reno 4 Z 5G";
		}elseif($_GET["search"] == "oppo-reno4-5g"){$titel ="OPPO Reno4 5G";
		}elseif($_GET["search"] == "oppo-reno4-pro-5g"){$titel ="Oppo Reno4 Pro 5G";
		}elseif($_GET["search"] == "oppo-reno4-z-5g"){$titel ="OPPO Reno4 Z 5G";
		}elseif($_GET["search"] == "pixel"){$titel ="Pixel";
		}elseif($_GET["search"] == "pixel-2"){$titel ="Pixel 2";
		}elseif($_GET["search"] == "pixel-4"){$titel ="Pixel 4";
		}elseif($_GET["search"] == "pixel-4a"){$titel ="Pixel 4a";
		}elseif($_GET["search"] == "pixel-5"){$titel ="Pixel 5";
		}elseif($_GET["search"] == "poco-x3-nfc"){$titel ="POCO X3 NFC";
		}elseif($_GET["search"] == "pocophone-f2-pro"){$titel ="Pocophone F2 Pro";
		}elseif($_GET["search"] == "pocophone-x2"){$titel ="Pocophone X2";
		}elseif($_GET["search"] == "realme-6"){$titel ="Realme 6";
		}elseif($_GET["search"] == "realme-6-pro"){$titel ="Realme 6 Pro";
		}elseif($_GET["search"] == "realme-x50-pro"){$titel ="Realme X50 Pro";
		}elseif($_GET["search"] == "redmi-7"){$titel ="Redmi 7";
		}elseif($_GET["search"] == "redmi-7a"){$titel ="Redmi 7A";
		}elseif($_GET["search"] == "redmi-8"){$titel ="Redmi 8";
		}elseif($_GET["search"] == "redmi-8a"){$titel ="Redmi 8A";
		}elseif($_GET["search"] == "redmi-9a"){$titel ="Redmi 9A";
		}elseif($_GET["search"] == "redmi-9c"){$titel ="Redmi 9C";
		}elseif($_GET["search"] == "redmi-note-7"){$titel ="Redmi Note 7";
		}elseif($_GET["search"] == "redmi-note-8-pro"){$titel ="Redmi Note 8 Pro";
		}elseif($_GET["search"] == "redmi-note-8t"){$titel ="Redmi Note 8T";
		}elseif($_GET["search"] == "redmi-note-9"){$titel ="Redmi Note 9";
		}elseif($_GET["search"] == "redmi-note-9-pro"){$titel ="Redmi Note 9 Pro";
		}elseif($_GET["search"] == "redmi-note-9s"){$titel ="Redmi Note 9S";
		}elseif($_GET["search"] == "samsung-galaxy-a20s"){$titel ="Samsung Galaxy A20s";
		}elseif($_GET["search"] == "samsung-galaxy-a21s"){$titel ="Samsung Galaxy A21s";
		}elseif($_GET["search"] == "samsung-galaxy-a31"){$titel ="Samsung Galaxy A31";
		}elseif($_GET["search"] == "samsung-galaxy-a41"){$titel ="Samsung Galaxy A41";
		}elseif($_GET["search"] == "samsung-galaxy-a42"){$titel ="Samsung Galaxy A42";
		}elseif($_GET["search"] == "samsung-galaxy-a90-5g"){$titel ="Samsung Galaxy A90 5G";
		}elseif($_GET["search"] == "samsung-galaxy-a91"){$titel ="Samsung Galaxy A91";
		}elseif($_GET["search"] == "samsung-galaxy-fold-lite"){$titel ="Samsung Galaxy Fold Lite";
		}elseif($_GET["search"] == "samsung-galaxy-m11"){$titel ="Samsung Galaxy M11";
		}elseif($_GET["search"] == "samsung-galaxy-m31"){$titel ="Samsung Galaxy M31";
		}elseif($_GET["search"] == "samsung-galaxy-note-10-lite"){$titel ="Samsung Galaxy Note 10 Lite";
		}elseif($_GET["search"] == "samsung-galaxy-note-10-plus"){$titel ="Samsung Galaxy Note 10 Plus";
		}elseif($_GET["search"] == "samsung-galaxy-note-10-plus-star-wars-edition"){$titel ="Samsung Galaxy Note 10 Plus Star Wars Edition";
		}elseif($_GET["search"] == "samsung-galaxy-note-20-5g"){$titel ="Samsung Galaxy Note 20 5G";
		}elseif($_GET["search"] == "samsung-galaxy-note-20-ultra"){$titel ="Samsung Galaxy Note 20 Ultra";
		}elseif($_GET["search"] == "samsung-galaxy-s10-lite"){$titel ="Samsung Galaxy S10 Lite";
		}elseif($_GET["search"] == "samsung-galaxy-s10-plus"){$titel ="Samsung Galaxy S10 Plus";
		}elseif($_GET["search"] == "samsung-galaxy-s20-fan-edition-4g"){$titel ="Samsung Galaxy S20 Fan Edition 4G";
		}elseif($_GET["search"] == "samsung-galaxy-s20-fan-edition-5g"){$titel ="Samsung Galaxy S20 Fan Edition 5G";
		}elseif($_GET["search"] == "samsung-galaxy-s20-fe-fan-edition"){$titel ="Samsung Galaxy S20 FE Fan Edition";
		}elseif($_GET["search"] == "samsung-galaxy-s20-fe-5g-fan-edition"){$titel ="Samsung Galaxy S20 FE 5G Fan Edition";
		}elseif($_GET["search"] == "samsung-galaxy-s20-lite"){$titel ="Samsung Galaxy S20 Lite";
		}elseif($_GET["search"] == "samsung-galaxy-s21"){$titel ="Samsung Galaxy S21";
		}elseif($_GET["search"] == "samsung-galaxy-s21-plus"){$titel ="Samsung Galaxy S21 Plus";
		}elseif($_GET["search"] == "samsung-galaxy-s21-ultra"){$titel ="Samsung Galaxy S21 Ultra";
		}elseif($_GET["search"] == "samsung-galaxy-s30"){$titel ="Samsung Galaxy S30";
		}elseif($_GET["search"] == "samsung-galaxy-xcover-4s"){$titel ="Samsung Galaxy Xcover 4s";
		}elseif($_GET["search"] == "samsung-galaxy-z-flip-5g"){$titel ="Samsung Galaxy Z Flip 5G";
		}elseif($_GET["search"] == "samsung-galaxy-z-fold-2"){$titel ="Samsung Galaxy Z Fold 2";
		}elseif($_GET["search"] == "samsung-galaxy-z-fold-5g"){$titel ="Samsung Galaxy Z Fold 5G";
		}elseif($_GET["search"] == "sharp-aquos-r3"){$titel ="Sharp Aquos R3";
		}elseif($_GET["search"] == "sony-xperia-pro"){$titel ="Sony Xperia Pro";
		}elseif($_GET["search"] == "tcl-plex"){$titel ="TCL Plex";
		}elseif($_GET["search"] == "wiko-view-3-lite"){$titel ="Wiko View 3 Lite";
		}elseif($_GET["search"] == "wiko-view-4"){$titel ="Wiko View 4";
		}elseif($_GET["search"] == "wiko-view-4-lite"){$titel ="Wiko View 4 Lite";
		}elseif($_GET["search"] == "wiko-y60"){$titel ="Wiko Y60";
		}elseif($_GET["search"] == "xiaomi-black-shark-3"){$titel ="Xiaomi Black Shark 3";
		}elseif($_GET["search"] == "xiaomi-mi-10"){$titel ="Xiaomi Mi 10";
		}elseif($_GET["search"] == "xiaomi-mi-10-lite"){$titel ="Xiaomi Mi 10 Lite";
		}elseif($_GET["search"] == "xiaomi-mi-10-pro"){$titel ="Xiaomi Mi 10 Pro";
		}elseif($_GET["search"] == "xiaomi-mi-10t"){$titel ="Xiaomi Mi 10T";
		}elseif($_GET["search"] == "xiaomi-mi-10t-5g"){$titel ="Xiaomi Mi 10T 5G";
		}elseif($_GET["search"] == "xiaomi-mi-10t-lite"){$titel ="Xiaomi Mi 10T Lite";
		}elseif($_GET["search"] == "xiaomi-mi-10t-pro"){$titel ="Xiaomi Mi 10T Pro";
		}elseif($_GET["search"] == "xiaomi-mi-9t"){$titel ="Xiaomi Mi 9T";
		}elseif($_GET["search"] == "xiaomi-mi-cc9"){$titel ="Xiaomi Mi CC9";
		}elseif($_GET["search"] == "xiaomi-mi-note-10-lite"){$titel ="Xiaomi Mi Note 10 Lite";
		}elseif($_GET["search"] == "xiaomi-poco-f2-pro"){$titel ="Xiaomi Poco F2 PRO";
		}elseif($_GET["search"] == "xiaomi-redmi-k30"){$titel ="Xiaomi Redmi K30";
		}elseif($_GET["search"] == "xiaomi-redmi-note-8t"){$titel ="Xiaomi Redmi Note 8T";
		}elseif($_GET["search"] == "xiaomi-redmi-note-9"){$titel ="Xiaomi Redmi Note 9";
		}elseif($_GET["search"] == "xiaomi-redmi-note-9-pro"){$titel ="Xiaomi Redmi Note 9 Pro";
		}elseif($_GET["search"] == "xiaomi-redmi-note-9s"){$titel ="Xiaomi Redmi Note 9S";
		}elseif($_GET["search"] == "xperia-5-ii"){$titel ="Xperia 5 II";
		}elseif($_GET["search"] == "zte-axon-10-pro"){$titel ="ZTE Axon 10 Pro";
		}elseif($_GET["search"] == "zte-axon-11"){$titel ="ZTE Axon 11";
		}elseif($_GET["search"] == "zte-axon-20"){$titel ="ZTE Axon 20";
		}elseif($_GET["search"] == "zte-axon-20-5g"){$titel ="ZTE Axon 20 5G";
		}elseif($_GET["search"] == "zte-blade-v-plusb1"){$titel ="ZTE Blade V-plusB1";
		
	}else{
			$whithoutspace = str_replace("-", " ", $_GET["search"]);
			$titel = ucfirst($whithoutspace);
		} ?>

		<? if($_GET['page'] == 1){?>

		<meta name="description" content="Große Auswahl an Handyhüllen für das <?echo $titel;?>. Günstig oder Preiswert, hier wirst du für dein <?echo $titel;?> die richtige Handytasche finden!">
		<title>Hülle <?echo $titel;?> Leder | Silikon | Plastik - Handyhülle 24 </title>

		<?}elseif($_GET['page'] == 2){?>

		<meta name="description" content="Günstige <?echo $titel;?> Plus Handyhülle online kaufen. Finde eine günstige Handyhülle für dein <?echo $titel;?>, egal ob aus Leder, Silikon oder Plastik.">
		 <title>Handyhülle <?echo $titel;?> Silikon | Leder | Plastik - Handyhülle 24 </title>

		<?}elseif($_GET['page'] == 3){?>

		<meta name="description" content="<?echo $titel;?> Hülle kaufen. Du bist auf der Suche nach einer <? echo $titel;?> Hülle? Wir bieten dir eine große Auswahl an Hüllen, egal ob aus Leder, Silikon oder Plastik.">
		 <title>Handyhüllen <?echo $titel;?> Plastik | Silikon | Leder - Handyhülle 24 </title>


		<?}elseif($_GET['page'] == 4){?>

		<meta name="description" content="<?echo $titel;?> Hülle kaufen. Du bist auf der Suche nach einer <? echo $titel;?> Hülle? Wir bieten dir eine große Auswahl an Hüllen, egal ob aus Leder, Silikon oder Plastik.">
		<title>Handyhülle für <?echo $titel;?> Leder | Silikon | Plastik - Handyhülle 24 </title>


		<?}elseif($_GET['page'] == 5){?>

		<meta name="description" content="<?echo $titel;?> Hülle kaufen. Du bist auf der Suche nach einer <? echo $titel;?> Hülle? Wir bieten dir eine große Auswahl an Hüllen, egal ob aus Leder, Silikon oder Plastik.">
		<title><?echo $titel;?> Hüllen Leder | Plastik | Silikon - Handyhülle 24 </title>

		<?}else{?>

		 <meta name="description" content="<?echo $titel;?> Hülle kaufen. Du bist auf der Suche nach einer <? echo $titel;?> Hülle? Wir bieten dir eine große Auswahl an Hüllen, egal ob aus Leder, Silikon oder Plastik.">
		 <title> <?echo $titel;?> Hülle Leder | Silikon | Plastik - Handyhülle 24 </title>

		<?}?>

		<meta name="keywords" content="Handyhülle, Handyhüllen, Handyschale, Handytasche, Smartphone, Tasche, Hülle, Schale, Schutz, Schutzhülle">


	<?}?>

	<? /*
    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="/css/font-awesome-corp.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

	<!-- Loadbar -->
    <link href="/css/pace.min.css" rel="stylesheet">
	*/ ?>

	<!-- Scroll to top Button -->
	<!--<a class="scrollicon" title="zum Seitenanfang" href="#" style="display: inline;"><div>&Lambda;</div></a>-->
	<a class="scrollicon" title="zum Seitenanfang" href="#" style="display: inline;"><div><i class="fa fa-arrow-circle-up"></i></div></a>

	<? /*
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    */ ?>

	<!-- Favicon -->
	<link rel="/shortcut icon" type="image/x-icon" href="img/favicon/favicon.ico" />
	<link rel="/icon" type="image/x-icon" href="favicon.ico" />

</head>