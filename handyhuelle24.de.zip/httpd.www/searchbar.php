<a name="about"></a>
<div class="intro-header">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <br>
                <h1 class="hidden-xs pull-right">Handyhülle 24 - Finde hier <br> die passende Handyhülle </h1>
                <div class="intro-message">
                    <form action="result.php" method="GET" class="form-group" role="search">
                        <div class="input-group col-xs-10 col-sm-8 col-md-8 col-lg-8 col-xs-offset-1 col-sm-offset-2 col-md-offset-2 searchbar">
                            <input type="text" class="form-control input-lg" placeholder="Handyname eingeben" name="search">
                            <div class="input-group-btn">
                                <button class="btn btn-success btn-lg" type="submit"> <i class="glyphicon glyphicon-search"></i> </button>
                            </div>
                        </div>
                    </form>
                    <div class="hidden-xs col-xs-8 col-lg-8 col-xs-offset-2 col-md-offset-2" style="background-color:rgba(0, 0, 0, 0.7);">
                        <h4 class="startseite-linkfenster"> 
					<a class="startseite" href="huawei-p30-pro" title="Huawei P30 PRO Hülle">Huawei P30 PRO</a> | 
					<a class="startseite" href="samsung-galaxy-s10plus" title="Samsung Galaxy S10+ Hülle">Galaxy S10+</a> | 
                    <a class="startseite" href="iphone-11-pro" title="Apple iPhone 11 Pro Hülle">iPhone 11 Pro</a> | 
					<a class="startseite" href="google-pixel-3" title="Google Pixel 3 Hülle">Google Pixel 3</a> | 
					<a class="startseite" href="iphone-11-pro-max" title="Apple iPhone 11 Pro Max Hülle">iPhone 11 Pro Max</a>
						</h4> </div>
                </div>
            </div>
        </div>
    </div>
</div>