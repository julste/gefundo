<!DOCTYPE html>
<html lang=de><? $page="template"; ?><? include( "head.php"); ?>
<style>.bs-callout{padding:20px;margin:20px 0;border:1px solid #eee;border-left-width:5px;border-radius:3px}.bs-callout h4{margin-top:0;margin-bottom:5px}.bs-callout p:last-child{margin-bottom:0}.bs-callout code{border-radius:3px}.bs-callout+.bs-callout{margin-top:-5px}.bs-callout-default{border-left-color:#777}.bs-callout-default h4{color:#777}.bs-callout-primary{border-left-color:#428bca}.bs-callout-primary h4{color:#428bca}.bs-callout-success{border-left-color:#5cb85c}.bs-callout-success h4{color:#5cb85c}.bs-callout-success h3{color:#5cb85c}.bs-callout-danger{border-left-color:#d9534f}.bs-callout-danger h4{color:#d9534f}.bs-callout-warning{border-left-color:#f0ad4e}.bs-callout-warning h4{color:#f0ad4e}.bs-callout-info{border-left-color:#5bc0de}.bs-callout-info h4{color:#5bc0de}.videowrapper{float:none;clear:both;width:100%;position:relative;padding-bottom:56.25%;padding-top:25px;height:0}.videowrapper iframe{position:absolute;top:0;left:0;width:100%;height:100%}.img-border{margin-left: 20px;margin-bottom:20px;}
</style>

<body><? include( "nav.php"); ?>

<div style=padding-top:80px;padding-bottom:50px>

<div class=container>

<div class=row>

<div class="col-sm-12 col-lg-12 col-md-12">

<h1>Handyhülle häkeln</h1>

<img src="img/handyhuelle-haekeln.jpg" class="img-responsive img-rounded pull-right img-border" alt="Responsives Bild">

<p>
<strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=search-alias=aps&amp;field-keywords=handyhuelle+h%C3%A4kel+set&amp;rh=i:aps,k:handyhuelle+h%C3%A4kel+set&amp;linkCode=ll2&amp;tag=handyhuellen24-21&amp;linkId=f85b3c341e103287cb6bf8bd75eed79e" rel="nofollow" target="_blank" title="Hier geht es zu Amazon.">Hier</a></strong>&nbsp;<strong>findest du ein Einsteigerset zu Handyh&uuml;lle selber h&auml;keln.</strong>
</p>

<p style="text-align: justify;">
H&auml;keln wird oft mit etwas Altmodischem verbunden, mit einer Oma, die abends mit einer Tasse Tee vorm Kaminfeuer sitzt und Topflappen h&auml;kelt, die die armen Enkel dann wie jedes Jahr zu Weihnachten unter dem Baum vorfinden und Freude vort&auml;uschen m&uuml;ssen. Doch mit dem Trend zum Selbermachen &ndash; Do It Yourself, oder kurz: DIY &ndash;, der in den letzten Jahren aufgekommen ist, hat auch das H&auml;keln eine regelrechte Renaissance erlebt. &Uuml;berall wird geh&auml;kelt, und das nicht nur von alten grauhaarigen Frauen, nein, Studenten in der Vorlesung, Freunde im Caf&eacute;, alles h&auml;kelt.
</p>

<h2>
H&auml;keln - was ist&nbsp;das?
</h2>

<p style="text-align: justify;">
Beim H&auml;keln werden mit einem Faden und mithilfe einer H&auml;kelnadel, die im Gegensatz zu einer normalen Stricknadel einen Haken an ihrer Spitze hat, Maschen erzeugt und miteinander verkn&uuml;pft, sodass ein fest verbundenes Maschengebilde entsteht, das in allen m&ouml;glichen Formen erscheinen kann &ndash; vom klassischen und recht einfachen Topflappen &uuml;ber kleine Kuscheltiere und M&uuml;tzen bis hin zu Handyh&uuml;llen. Das H&auml;keln einer Handytasche ist der letzte Schrei und gro&szlig; in Mode. Kein Wunder, denn eigentlich bedarf jedes Smartphone des Schutzes, da es schnell aus der Hand gleiten und auf dem Boden landen kann, was nicht selten zu einem Totalschaden f&uuml;hrt. Wer keine klassische Handyh&uuml;lle haben m&ouml;chte und mehr Individualit&auml;t bevorzugt, f&uuml;r den liegt es auf der Hand, sich seine eigene Handytasche einfach selber zu machen &ndash; und das H&auml;keln ist hierf&uuml;r eine sehr gute M&ouml;glichkeit.
</p>

<h3>
Nicht nur was f&uuml;r Omas
</h3>

<p style="text-align: justify;">
Wer noch nie geh&auml;kelt hat und sich vor dem Angang f&uuml;rchtet, der sei beruhigt: H&auml;keln ist relativ einfach zu erlernen und es lassen sich schnell erste Erfolge verzeichnen, was der Motivation nat&uuml;rlich guttut. Auch das H&auml;keln einer Handytasche ist gar nicht so schwierig, wie es auf den ersten Blick vielleicht klingen mag. Auf Internetportalen wie YouTube finden sich Schritt-f&uuml;r-Schritt-Anleitungen, die einen an die Hand nehmen und genau erkl&auml;ren, wie man sich eine h&uuml;bsche Handytasche h&auml;keln kann, wie gro&szlig; die Tasche sein soll, wie sie zus&auml;tzlich verziert werden kann, wie eng die Maschen zu h&auml;keln sind und vieles mehr. Ein hilfreiches Video ist beispielsweise dieses hier:
</p>

<div class="visible-lg visible-md visible-sm">
<iframe width="560" height="315" src="https://www.youtube.com/embed/jidQmHG2VG8" frameborder="0" allowfullscreen></iframe>
</div>

<p style="text-align: justify;">
Von der ersten Masche bis zur fertigen Handytasche wird der Zuschauer an die Hand genommen und kann lernen, wie einfach es ist, sich eine H&uuml;lle f&uuml;rs eigene Smartphone selbst zu h&auml;keln. Sch&ouml;n daran ist vor allem, dass jeder seiner Kreativit&auml;t freien Lauf lassen kann, sich die Farbe des Garns ganz individuell aussuchen und zus&auml;tzliche Stickereien wie Perlen oder Glitzer hinzuf&uuml;gen kann. Wer im H&auml;keln schon ein bisschen erfahrener ist, der kann sich auch s&uuml;&szlig;e Handyh&uuml;llen, die wie Hasen oder B&auml;ren aussehen, selbst h&auml;keln, wie dieses Video erkl&auml;rt:
</p>

<div class="visible-lg visible-md visible-sm">
<iframe width="560" height="315" src="https://www.youtube.com/embed/SdmzsB4zh-0" frameborder="0" allowfullscreen></iframe>
</div>

<p style="text-align: justify;">
Diese und auch alle anderen selbstgeh&auml;kelten Smartphonetaschen eignen sich hervorragend als Geschenk und zaubern garantiert ein L&auml;cheln auf das Gesicht des Beschenkten.
</p>

<p style="text-align: justify;">
Das H&auml;keln einer Handyh&uuml;lle verbindet nicht zuletzt zwei Dinge, die eigentlich gegens&auml;tzlicher nicht sein k&ouml;nnen &ndash; und es ist diese Verbindung, die den besonderen Reiz ausmacht: H&auml;keln sorgt f&uuml;r heimeliges Retro-Flair und l&auml;sst an alte Zeiten und gemeinsame Kaminabende zur&uuml;ckdenken, es ist regelrecht meditativ, ja nostalgisch. Durch das H&auml;keln einer Handyh&uuml;lle wird diese handwerkliche Nostalgie mit einem der modernsten Ger&auml;te unserer heutigen Zeit, mit scharfen Kanten, klaren Linien und empfindlichster Technik verbunden. Gerade diese scheinbare Ambivalenz ist es, die den Reiz einer selbstgeh&auml;kelten Handyh&uuml;lle ausmacht.
</p>

<p style="text-align: justify;">
Du m&ouml;chtest gleich mit dem H&auml;keln loslegen? Dann klicke einfach <strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=search-alias=aps&amp;field-keywords=handyhuelle+h%C3%A4kel+set&amp;rh=i:aps,k:handyhuelle+h%C3%A4kel+set&amp;linkCode=ll2&amp;tag=handyhuellen24-21&amp;linkId=f85b3c341e103287cb6bf8bd75eed79e" rel="nofollow" target="_blank" title="Hier geht es zu Amazon.">hier</a>&nbsp;</strong>und hole dir dein Handyh&uuml;llen H&auml;kel Starterset!&nbsp;
</p>

</div>
</div>
</div>
</div><? include( "footer.php"); ?>