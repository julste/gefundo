<!DOCTYPE html>
<html lang=de><? $page="template"; ?><? include( "head.php"); ?>
<style>.bs-callout{padding:20px;margin:20px 0;border:1px solid #eee;border-left-width:5px;border-radius:3px}.bs-callout h4{margin-top:0;margin-bottom:5px}.bs-callout p:last-child{margin-bottom:0}.bs-callout code{border-radius:3px}.bs-callout+.bs-callout{margin-top:-5px}.bs-callout-default{border-left-color:#777}.bs-callout-default h4{color:#777}.bs-callout-primary{border-left-color:#428bca}.bs-callout-primary h4{color:#428bca}.bs-callout-success{border-left-color:#5cb85c}.bs-callout-success h4{color:#5cb85c}.bs-callout-success h3{color:#5cb85c}.bs-callout-danger{border-left-color:#d9534f}.bs-callout-danger h4{color:#d9534f}.bs-callout-warning{border-left-color:#f0ad4e}.bs-callout-warning h4{color:#f0ad4e}.bs-callout-info{border-left-color:#5bc0de}.bs-callout-info h4{color:#5bc0de}.videowrapper{float:none;clear:both;width:100%;position:relative;padding-bottom:56.25%;padding-top:25px;height:0}.videowrapper iframe{position:absolute;top:0;left:0;width:100%;height:100%}.img-border{margin-left: 20px;margin-bottom:20px;}
</style>

<body><? include( "nav.php"); ?>

<div style=padding-top:80px;padding-bottom:50px>

<div class=container>

<div class=row>

<div class="col-sm-12 col-lg-12 col-md-12">

<h1>Handyhülle nähen</h1>

<img src="img/handyhuelle-naehen.jpg" class="img-responsive img-rounded pull-right img-border" alt="Responsives Bild">

<p>
<strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=search-alias=aps&amp;field-keywords=n%C3%A4hset+handytasche&amp;rh=i:aps,k:n%C3%A4hset+handytasche&amp;linkCode=ll2&amp;tag=handyhuellen24-21&amp;linkId=e173f04a46b254c5557a95cf3a731e8d" rel="nofollow" target="_blank" title="Hier geht es zu Amazon.">Hier</a>&nbsp;findest du ein Einsteigerset zum Handyh&uuml;lle selber n&auml;hen.</strong>
</p>

<p style="text-align: justify;">
In den letzten Jahren hat der sogenannte Do-It-Yourself-Trend (kurz: DIY) die M&auml;rkte regelrecht im Sturm erobert. DIY-Zeitschriften und -Onlinemagazine, Bastell&auml;den und Workshops &ndash; &uuml;berall findet sich der Trend wieder und gerade junge Menschen entdecken hier neue Hobbies. Ob selbstgebastelte Partydeko, selbstgekochte Marmelade oder die ersten selbstgestrickten Socken &ndash; jeder kann etwas finden, woran er Spa&szlig; hat und was ihn begeistert. Dabei ist Selbermachen oft gar nicht so schwer, wie es sich manche vorstellen, und dank Schnittmustern und Bastelanleitungen bedarf es nicht einmal einer enorm hohen Kreativit&auml;t, um sich einige praktische und sch&ouml;ne Dinge selbst zu gestalten.
</p>

<h2>
DIY-Handytasche
</h2>

<p style="text-align: justify;">
Auch vor dem Handyzubeh&ouml;r macht der DIY-Trend keinen Halt &ndash; und das ist auch gut so. Da beinahe jedes Handy sinnvollerweise durch eine H&uuml;lle oder Tasche gesch&uuml;tzt werden muss &ndash; zu gro&szlig; sind die t&auml;glichen Gefahren, denen das empfindliche technische Ger&auml;t ausgesetzt ist &ndash; w&auml;chst der Wunsch nach individuellen M&ouml;glichkeiten des Schutzes. Und was w&auml;re individueller und gleichzeitig sch&ouml;ner als eine selbstgen&auml;hte Handytasche? Diese kann das Handy einwandfrei sch&uuml;tzen und ist gleichzeitig ein echter Hingucker. Darum eignet sich eine selbstgen&auml;hte Handytasche nicht zuletzt wunderbar als pers&ouml;nliches Geschenk f&uuml;r Freunde und Familie.
</p>

<p style="text-align: justify;">
Wer einfach keine Handytasche findet, die ihm wirklich gut gef&auml;llt und die dem eigenen Style entspricht, der sollte vielleicht dar&uuml;ber nachdenken, sie sich einfach selbst zu n&auml;hen &ndash; so kann man Stoffe und Muster sowie die Passform selbst bestimmen und sich seine ganz pers&ouml;nliche perfekte Schutzh&uuml;lle anfertigen. Eine Handytasche selbst zu n&auml;hen klingt im ersten Moment anstrengend und schwierig &ndash; doch selbst unerfahrene N&auml;her k&ouml;nnen hier schnelle Erfolge verzeichnen. Wer sich das N&auml;hen erleichtern m&ouml;chte, der sollte sich vielleicht eine N&auml;hmaschine borgen, aber auch mit der Hand ist das N&auml;hen einer Handytasche m&ouml;glich. Dazu ben&ouml;tigt man zuallererst Stoff, der &ndash; vorzugsweise mit einer Stoffschere &ndash; in der passenden Gr&ouml;&szlig;e ausgeschnitten werden muss, sowie farblich passenden Garn, Stecknadeln und eine Nadel.
</p>

<p style="text-align: justify;">
F&uuml;r eine ganz einfache Handyh&uuml;lle ben&ouml;tigt der kreative Bastler nicht einmal ein Schnittmuster. Stattdessen kann er sein Handy auf den Stoff legen und ein St&uuml;ck ausschneiden, das etwas mehr als doppelt so lang wie das Smartphone sowie ca. 2 cm breiter als dieses ist. Wer seine H&uuml;lle mit einem weichen Innenstoff f&uuml;ttern m&ouml;chte, schneidet aus diesem ein ebenso gro&szlig;es St&uuml;ck aus und n&auml;ht es auf den Au&szlig;enstoff. Nun muss die Tasche lediglich in den Seiten und unten zusammengen&auml;ht werden, sodass oben eine &Ouml;ffnung f&uuml;r das Smartphone bleibt &ndash; fertig ist die erste simple Handyh&uuml;lle.
</p>

<h3>
Zahlreiche Varianten
</h3>

<p style="text-align: justify;">
Es gibt zahlreiche Varianten, die selbstgen&auml;hte Handytasche zu verzieren oder beispielsweise durch einen Knopf oder ein Gummiband die Sicherheit zu erh&ouml;hen. Auch das Einbauen einer Lasche oder das Einn&auml;hen zus&auml;tzlicher Verstauf&auml;cher ist eine M&ouml;glichkeit, die sich relativ leicht selbst umsetzen l&auml;sst. Glitzersteine, Perlen oder Filz lassen die selbstgen&auml;hte Handytasche zu einem wirklichen Hingucker werden. Wer eine etwas anspruchsvollere Handytasche n&auml;hen m&ouml;chte, der findet im Internet zahlreiche N&auml;hvorlagen, Anleitungen oder auch Videos, die dabei helfen k&ouml;nnen. Ein hilfreiches Video f&uuml;r das N&auml;hen einer Handytasche mit Rausziehhilfe findet sich etwa hier:
</p>


<div class="visible-lg visible-md visible-sm">
		<iframe width="560" height="315" src="https://www.youtube.com/embed/mJaonCtmIIA" frameborder="0" allowfullscreen></iframe>
	</div>

<p style="text-align: justify;">
Dar&uuml;ber hinaus k&ouml;nnen N&auml;hsets mit allen notwendigen Materialien inklusive N&auml;hanleitung gekauft werden. Eine Auswahl gibt es <strong><a href="https://www.amazon.de/s/ref=as_li_ss_tl?__mk_de_DE=%C3%85M%C3%85%C5%BD%C3%95%C3%91&amp;url=search-alias=aps&amp;field-keywords=n%C3%A4hset+handytasche&amp;rh=i:aps,k:n%C3%A4hset+handytasche&amp;linkCode=ll2&amp;tag=handyhuellen24-21&amp;linkId=e173f04a46b254c5557a95cf3a731e8d" rel="nofollow" target="_blank" title="Hier geht es zu Amazon.">hier</a></strong>.&nbsp;
</p>

<p style="text-align: justify;">
Das Sch&ouml;ne am Selbstn&auml;hen: Welchen Stoff bzw. welches Material in welcher Farbe man sich f&uuml;r die eigene Handyh&uuml;lle aussuchen m&ouml;chte, ist einem komplett selbst &uuml;berlassen. Der Kreativit&auml;t und Fantasie sind keine Grenzen gesetzt und am Ende kommt eine garantiert individuelle H&uuml;lle dabei heraus! &nbsp;&nbsp;
</p>



</div>
</div>
</div>
</div><? include( "footer.php"); ?>