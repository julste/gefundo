<?
include("class.ProductService.Affilinet.php");

 $ps= new ProductServices();
  
 //SANDBOX-AUFRUF
 //$ps->Affilinet("DEVELOPER_ID","DEVELOPER_PORTAL_PASSWORD",'Product',true);
 //LIVE-AUFRUF
 $ps->Affilinet("729574","4xdjz1KBrVRhyD3h0H6s",'Product');

 print_r ($ps->GetCategoryList(72));
  
?>