
<?if (!isset($_GET['page'])){?>

<? if ($_GET["search"] == "iphone-6"){?>
<h3>
	Apple iPhone 6 Hülle
</h3>
<br>
<p>
Du bist auf der Suche nach einer Apple <b>iPhone 6 Hülle</b>? Wir bieten die eine große Auswahl an Hüllen, 
egal ob aus Leder, Silikon oder Plastik. Eine Hülle für dein iPhone 6 bietet nicht nur optimalen
Schutz vor Kratzern, sondern auch die Möglichkeit den Look deines Handys neu zu gestalten. Dabei kannst du
zwischen verschiendenen Arten und Farben von Hüllen wählen. Es gibt Hüllen, welche auch bei 
der Verwendung des iPhones nicht abgenommen werden. Dies sind oft sogennante Cases aus Hartplastik oder Silikon.
Es gibt Handytaschen, bei denen das Handy rundum geschützt wird und nur bei der Verwendung aus der Hülle genommen wird. 
Und es gibt Handyhüllen, die sich bei der Verwendung 
aufklappen lassen und das entweder zur Seite oder nach Unten und somit eine optimale Handhabung bieten.
Eine <b>iPhone 6 Hülle</b> 
kann aber auch mehr bieten als nur das Smartphone zu schützen und das Erscheinungsbild zu ändern.
Es gibt Zusatzfunktionen wie beispielsweise die Aufbewahrung von Kreditkarten oder einen integrierten Ersatzakku, 
welcher die Laufzeit des Handys verdoppeln kann.
Egal, ob Schutzfunktion oder neuer Look, nutze unsere Suchmaschine und unseren Filter, um die passende Hülle für dein iPhone 6 von Apple zu finden!

</p>
<hr>
<?}elseif($_GET["search"] == "iphone-6-plus"){ ?>
<h3>
	Apple iPhone 6 Plus Hülle
</h3>
<br>
<p>
Das iPhone 6 Plus bietet mehr Leistung als das iPhone 6. Es ist aber auch größer und benötigt dementsprechend auch eine größere Hülle. 
Dennoch gibt es für diese Größe eine Vielzahl von Hüllen. Diese können aus <b>Leder</b>, <b>Silikon</b> oder <b>Plastik</b> sein und bieten den optimalen Schutz
für dein <u>iPhone 6 Plus</u>. So entstehen auf dem Apple Smartphone nicht so schnell Kratzer. Und falls dein iPhone mal runterfällt entstehen
auch geringere Schäden. Eine Hülle für dein Handy bietet aber mehr als nur Schutz. So kannst du dein Handy auch aufpeppen und es unterscheidet
sich von anderen Handys. Dabei gibt es viele verschiedene Farben mit oder ohne Motiv. Zu guter letzt gibt es auch Hüllen die Zusatzfunktionen besitzen.
Manche Handyhüllen haben Fächer zur Aufbewahrung von Scheck- und Kreditkarten. Andere bieten einen integrierten Akku zur Verlängerung der Laufzeit.
Eine Hülle für dein <b>iPhone 6 Plus</b> bietet in jedem Fall einen Mehrwert. Das wichtigste ist jedoch, dass die Hülle dir gefällt, denn du hälst
diese öfters am Tag in der Hand!
</p>
<hr>
<?}elseif($_GET["search"] == "iphone-5"){ ?>

<h3>
	Apple iPhone 5 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "iphone-5c"){ ?>

<h3>
	Apple iPhone 5c Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "iphone-4"){ ?>

<h3>
	Apple iPhone 4 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "iphone-4s"){ ?>

<h3>
	Apple iPhone 4s Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "iphone-se"){ ?>

<h1>
	Apple iPhone SE Hülle
</h1>
<br>
<p class="text-justify">
Groß, größer, iPhone, hat mit dem neuen <strong>iPhone SE</strong> ein Ende. Nach den immer größer werdenden Modellen von Apple, hat das Unternehmen erstmals wieder eine kleinere Variante auf den Markt gebracht, 
das iPhone SE. Der Multikonzern setzt dabei auf Altbewährtes, nämlich auf einen 4 Zoll großen Bildschirm. Das iPhone ist bereits im Handel erhältlich und kann mit einer passenden iPhone SE Handyhülle 
erworben werden. 
</p>
<h2>Das iPhone SE</h2>
<p class="text-justify">
Der Hersteller Apple überrascht beim iPhone SE nicht nur mit der Größe des Displays, sondern auch mit dem Preis. Die günstigste Variante des neuen Smartphones, mit dem kleinsten Speichervolumen 
von 16 Gigabyte (Gb), gibt es schon für <strong>489 Euro</strong>. 
</p>
<p class="text-justify">
Optisch orientiert sich das SE an der einstigen 5er-Modell-Reihe, nicht zuletzt wegen des eckigen Auftretens, der gleichen Größe wie das iPhone 5S (123,8 x 58,6 x 7,6 mm) und dem altbewährten Design. 
Auch beim Gewicht gibt es keine großen Veränderungen mit 113 Gramm. Allerdings hat Apple auf die überholte Technik verzichtet und das iPhone SE mit den technischen Attributen des 6S versehen. 
</p>
<p class="text-justify">
Aufgrund der kaum veränderten Optik lässt sich das neue Modell fast gar nicht vom iPhone 5S unterscheiden und ist zudem auch in dem zarten Roségold erhältlich. Des Weiteren sind auch die Front- und die 
Hauptkamera mit je 1,2 und 12 Megapixeln ausgestattet wie der größere Vorgänger. Mit dem SE können so daher Videos bis hin zur hochmodernen <strong>4K-Auflösung</strong>aufgenommen werden. 
</p>
<p class="text-justify">
Ein A9-64-Bit-Prozessor mit einem M9-Bewegungs-Co-Prozessor sorgt dafür, dass das <strong>iPhone SE</strong> über ein hervorragendes Tempo verfügt. Weitergehend verfügt die Neuveröffentlichung über 
Bluetooth 4.2, NFC und WLAN-ac. Aus diesem Grund hat das SE auch Apple Pay, die hauseigene Methode zum Bezahlen. Jedoch ist in Deutschland Apple Pay immer noch nicht verfügbar. Über die 
Schnittstellen an dem neuen iPhone kann kein Datenaustausch vorgenommen werden. 
</p>
<h3>Reibungsloser Ablauf</h3>
<p class="text-justify">
Dank des A9-Prozessors arbeiten sämtliche Anwendungen beim SE reibungslos und auch rechenintensive Games können ohne Probleme gezockt werden. Bei Leistungsmessungen wurde festgestellt, 
dass das neue Apple in der gleichen Klasse rechnet wie auch das 6S. Während beim iPhone 6S die leistungsstarke 12-Megapixel-Kamera aus dem Gehäuse herausragt, ist die des <strong>iPhone SE</strong> 
unterschiedlich aufgebaut, jedoch basiert sie auf denselben Komponenten, laut Apple. Bewährte Eigenschaften wie Live-Fotos, HDR und Zeitlupen- und Zeitrafferfilme sind auch beim SE möglich. 
</p>
<p class="text-justify">
Testaufnahmen haben gezeigt, dass die Endprodukte in der Qualität nicht von der des 6S abweichen. Im Fazit zählt also die Kamera im neuen Apple zu einer der besten Kameras, die aktuell bei 
Smartphones zu finden ist. 
</p>
<p>
Mit der 1,2-Megapixel-Frontkamera können Selfie-Liebhaber weiterhin eigene Aufnahmen in gewohnter Apple-Qualität aufgenommen werden. Nur während des Vergrößerns ist aufgefallen, dass die nötige 
Detailschärfe fehlt. Während der dauerhaften Wiedergabe eines HD-Videos hielt der <strong>Akku vom SE etwa neun Stunden</strong>. Auch hier liefert es die gleichen Werte wie das 6S und bedeutet im Umkehrschluss, 
dass es bei reger Nutzung täglich geladen werden muss. 
</p>
<h3>Unterschiedlich - Ja oder Nein?</h3>
<p class="text-justify">
Man muss das iPhone SE schon genauer unter die Lupe nehmen, um Unterschiede zu seinen großen Vorgängern zu finden. Zum einen wurde im SE ein gewöhnliches Retina-Display verbaut 
(1136 x 640 Pixel) und so kommt es auf dieselben Endwerte wie das 5S und 6S. Somit kommt es zu keiner Verbesserung aber auch zu keiner Verschlechterung. Jedoch ist die 3D-Touch-Funktion beim 
SE nicht zum Einsatz gekommen und bedeutet ein Verzicht. Ein weiteres Manko des SE ist, dass es das Modell nicht in den Versionen 32- und 128-Gigabyte gibt. Warum, dass weiß nur Apple selbst. 
Der Hersteller hat zudem auch auf das typische Fach für eine Speicherkarte verzichtet (micro-SD-Karte). 
</p>
<h3>Das SE im iPhone SE</h3>
<p class="text-justify">
Vor Veröffentlichung gab es zahllose Spekulationen über den Namen des neuen iPhones. So war die Rede vom iPhone 7C, 5SE oder 6C. Das Rennen machte SE und steht in seiner Abkürzung schlicht und 
ergreifend für <strong>"Special Edition"</strong>. Auch hat sich die Frage nach dem Warum geklärt, warum Apple ein altes Modell wieder auferstehen lässt. Es hat sich herausgestellt, dass das 5S von Apple Rang 2 der 
beliebtesten iPhones überhaupt ist und bis zur Erscheinung des SE auch das Günstigste. Nach einer aktuellen Umfrage sind Verwender von iPhones aktuell dazu bereit, etwa 446 Euro für ein neues Gerät 
zu zahlen und das liegt weiter unter dem Preis des iPhone 6S jedoch nah an dem Preis des SE. Eine iPhone SE Hülle sorgt übrigens für lange Freude am neuen Smartphone. 
</p>
<p class="text-justify">
Apple setzt mit dem SE auf seine Bestandskunden, die sich ein neues Gerät wünschen mit neuester Hardware, <strong>4-Zoll-Display</strong> und einem Betrag unter 500 Euro. Der Hersteller möchte mit dem iPhone SE 
aber auch Neukunden, sprich Android-User ansprechen. Das altbewährte 4-Zoll-Display ist ohne Probleme mit einer Hand zu bedienen wohingegen, das 4,7-Zoll-Display vom 6S nur mit zwei Händen 
nutzbar ist. Dies wiederum ist auf Unmut bei den Kunden gestoßen. So ist auch der Knopf zum Stand-by wieder zurück zur Oberseite verlegt worden und kann ohne Schwierigkeiten mit einer Hand betätigt 
werden. Apple hat den Anschluss für gängige Kopfhörer beibehalten und trotzt den Gerüchten um einen Wegfall des beliebten Anschlusses bei neuen Modellen. 
</p>
<h3>Im Handel und der Preis</h3>
<p class="text-justify">
In den USA zahlen Käufer für die 16 Gigabyte-Version nur etwa 355 Euro (399 US-Dollar). In Deutschland müssen die Kunden hingegen etwas tiefer in die Tasche greifen und bezahlen für die gleiche 
Version 489 Euro. Wem das jetzt sauer aufstößt, sollte bedenken, dass in den Staaten die altbekannte Steuer noch drauf gerechnet wird und diese variiert von Bundesstaat zu Bundesstaat. In insgesamt 
110 Ländern, einschließlich Deutschland, startet der Verkauf am 31.03.2016 und somit ist das iPhone SE das bisher günstigste Modell aus dem Hause Apple. Wer mit der 16-Gigabyte-Version nicht 
zurechtkommt, kann auf die vervierfachte Variante zurückgreifen. Das SE mit dem 64-Gigabyte-Speicher hat in Deutschland einen Preis von 589 Euro und ist in Amerika für 444 Euro (499 US-Dollar) 
erhältlich. 
</p>
<p class="text-justify">
Im Bereich der Farben hat Apple keine Experimente gemacht und setzt auf Gold, Spacegrau, Silber und Roségold. Aufgefallen ist, dass das 5s im Apple-Shop nicht mehr aufzufinden ist und das lässt 
wiederum darauf schließen, dass das SE das 5S direkt abgelöst und in den Ruhestand geschickt hat. 
</p>
<h2>Auf den richtigen Schutz kommt es an </h2>
<p class="text-justify">
Neben der Neuerscheinung des iPhone SE gibt es weitere Neuerscheinungen, die <strong>iPhone SE Handyhülle</strong>. Wie auch die Vorgänger hat Apple das SE auch nicht aus dem unzerstörbaren Titan angefertigt, 
und wie es das tägliche Missgeschick immer so will, ist das geliebte Smartphone schneller ruiniert als gewünscht. Eine iPhone SE Hülle sorgt dafür, dass Dein neues Gerät entsprechend geschützt ist. 
Niemand möchte gerne auf seinem neuen Smartphone unansehnliche Dellen oder gar unschöne Kratzer auf den hochwertigen Oberflächen. Mit der richtigen Handyhülle kannst Du solche Beschädigungen 
verhindern und dein Smartphone schützt zudem parallel das hochempfindliche Display. Nichts ist so schnell zu Bruch gegangen wie der Bildschirm eines Smartphones und mit der Einführung des neuen SE, 
gibt es auch eine passende iPhone SE Hülle. 
</p>
<p class="text-justify">
Eine iPhone SE Handyhülle stellt hier einen adäquaten Schutz für das SE an sich und das Display dar. Ist es erst einmal zu einem Glasbruch gekommen, bleibt Dir in den meisten Fällen nichts anderes 
übrig, als den Touchscreen zu wechseln. Mit einer iPhone SE Hülle, kannst Du diese <strong>unnötigen Kosten umgehen</strong>. Rüste Dein neues Apple Smartphone mit einer Schutzhülle. 
</p>
<p class="text-justify">
Neben den Gefahren etwaiger Beschädigungen schützt Du Dein Smartphone mit einer iPhone SE Hülle auch vor Dreck, Staub und anderen Unreinheiten. Staubablagerungen sind dafür bekannt, 
dass sie sich vor die Ports des Telefons setzen. Mit einer iPhone SE Handyhülle verhinderst Du das und auch Dreck, der sich in die Oberflächen beißt, hat mit einer iPhone SE Handyhülle keine Chance. 
</p>
<p class="text-justify">
Wie Du sicherlich unschwer erkennst, ist es sehr Sinnvoll mit einer iPhone SE Hülle dein Smartphone zu schützen. Hier empfehlen sich die speziell für das iPhone SE angefertigten <strong>Handyhüllen</strong>, in 
unterschiedlichen Materialien und Farben. 
</p>
<h3>Dein Style in der iPhone SE Hülle</h3>
<p class="text-justify">
Apple hat mit seinem neuen SE keinesfalls einen einzigen Typ bzw. Charakter angesprochen. Aus diesem Grund gibt es zahllose Varianten einer iPhone SE Handyhülle. Wenn Du eher der Anzugträger 
bist und auf ein elegantes Auftreten setzt, dann wirst Du wahrscheinlich zu einer iPhone SE Hülle aus <strong>Leder</strong> tendieren. Hierbei kannst Du noch wählen, ob deine iPhone SE Handyhülle aus echtem Leder 
oder doch eher einem strapazierfähigem <strong>Kunstleder</strong> bestehen soll. Mittels eines arbeitsintensivem Gerbungsprozess, wird das handgefertigt produziert und Deine iPhone SE Hülle spiegelt ein hochwertiges 
Erscheinen wieder. Eine iPhone SE Handyhülle aus echtem Leder ist selbstverständlich etwas kostspieliger. Wenn Deine Handyhülle nicht ganz so kostspielig sein soll, kannst 
Du auch auf Kunstleder zurückgreifen. Inzwischen ist das widerstandsfähige künstliche Leder keinesfalls mehr als solches zu erkennen und sorgt für ein elegantes Auftreten. 
</p>
<p class="text-justify">
Geschäftsleute wissen um den Alltag mit zahlreichen Visitenkarten und anderen Dokumenten. Aus diesem Grund kannst Du Dir auch eine <strong>iPhone SE Hülle</strong> mit ausreichend integrierten Kartenfächern 
zulegen. So eine Schutzhülle bietet Dir entsprechend viel Platz für Deine Bankkarte, Kreditkarten, Ausweise oder Visitenkarten. Oft finden sich solche Fächer in so genannten Flip-Cases. 
</p>
<p class="text-justify">
Wenn Du öfter mal auf längeren Reisen unterwegs bist, dann empfiehlt sich für Dich eine iPhone SE Handyhülle mit <strong>Standfunktion</strong>. Durch diese Standfunktion sorgt Deine iPhone SE Hülle für einen sicheren 
Halt, wenn Du beispielsweise einen Film auf deinem SE schaust. Mit genannter Aufstellfunktion der Schutzhülle, kannst Du zudem auch ergonomisch an Deinem Apple arbeiten. Surfen oder beim Schreiben 
von längeren Emails, werden mit so einer iPhone SE Handyhülle zum Kinderspiel. 
</p>
<p class="text-justify">
Wie Du siehst, kannst Du Dir nicht nur das Mitführen Deines dicken Portmonees sparen durch solch ein Gadget, sondern auch etwas für Deinen Rücken tun. 
</p>
<h3>Das Material einer iPhone SE Hülle</h3>
<p class="text-justify">
Wie oben bereits erwähnt, gibt es die iPhone SE Handyhüllen in echtem Leder und auch in Kunstleder. Neben diesen beiden Materialien kannst Du aber auch noch aus weiteren Werkstoffen für Deine 
Handyhülle wählen. Vor der Auswahl solltest Du Dir jedoch Gedanken darüber machen, über welche Eigenschaften Deine iPhone SE Hülle verfügen sollte. Viele wünschen sich eine robuste iPhone SE 
Handyhülle und greifen daher auf einen Schutz aus Hartplastik zurück, das sogenannte Hardcase. Gerne wird dafür der Hartkunststoff Polycarbonat bei der Herstellung der Schutzhüllen verwendet. 
Mit dieser Art von <strong>iPhone SE Handyhülle</strong>, ist Dein Apple sehr effektiv geschützt, nicht nur vor Kratzern sondern auch Dellen und Beulen haben so keine Chance. 
</p>
<p class="text-justify">
Wenn Dir eine iPhone SE Hülle aus Hartplastik zu steif ist, kannst Du Dir auch eine Handyhülle aus Silikon oder TPU kaufen. Hierdurch hast Du entsprechende <strong>Flexibilität</strong> und deine iPhone SE Hülle liegt 
angenehm in der Hand. Zudem sorgt so eine Hülle für optimale Stoßabwehr. Beim Aufprall auf einen harten Untergrund entwickelt sich Energie und die iPhone SE Hülle aus diesen Materialien leitet diese 
Energie nach außen ab und Deinem SE wird nichts passieren. 
</p>
<p class="text-justify">
Soll es für Dich auch ein bisschen kühler und edler sein, dann wähle doch eine iPhone SE Handyhülle aus reinem Aluminium. Die iPhone SE Hülle besticht so durch seine glatten Oberflächen und sorgen für 
strahlende Effekte. Das Metall Aluminium steht für Robustheit und spielend leichte Pflege. Verschmutzungen oder Flecken kannst Du ganz leicht mit einem fusselfreien Tuch wegwischen. 
</p>
<p class="text-justify">
Bist Du naturverbunden, dann wird Dir eine <strong>Schutzhülle aus Holz</strong> mit Sicherheit zusagen. Die iPhone SE Handyhülle aus Holz verbindet Natur, Eleganz und Massivität und sieht zudem sehr schön aus.
</p>
<h3>iPhone SE Handyhüllen und die Farben</h3>
<p class="text-justify">
Ebenso wie auch auf dem Laufsteg unterliegt auch die Farbpalette einer iPhone SE Hülle den aktuellsten Trends. Aus diesem Grund, kannst Du Dir Deine iPhone SE Hülle aus den unterschiedlichsten 
Farben heraussuchen. Eine begehrte Variante ist allerdings die iPhone SE Hülle in Transparent. Viele Nutzer möchten gerne das originale Design von Apple unverdeckt lassen.
</p>
<hr>
<?}elseif($_GET["search"] == "galaxy-s6"){ ?>

<h3>
	Samsung Galaxy S6 Hülle
</h3>
<br>
<p>
Du willst dir das neue Samsung Galaxy S6 bestellen? Oder es ist schon in deinem Besitz und du suchst nur noche eine Handyhülle um es zu schützen?
Das Samsung Galaxy S6 hat einen sehr guten hochauflösenden Bildschim und eine sehr schnelle Netzwerkanbindung. Das Galxy S6 verfügt über einen
schnellen Prozessor und ist gut verarbeitet. Im Gegensatz zu den anderen Modellen aus der Galaxy Reihe ist die äußere Schale des S6 aus Kunstleder
und dadurch rutscht es nicht so schnell. Eine <b>Samsung Galaxy S6 Hülle Leder</b> wertet das Erscheinungsbild des Handys auf und kann zusätzlich den
Bildschirm vor Kratzern schützen. Das Galaxy S6 ist Wasser- und staubdicht und hat als zusätzliches Highlight einen Pulsmesser. Dieser Pulsmesser ist 
auf der Rückseite des Smartphones angebracht. Falls man seinen Puls regelmäßig messen möchte, sollte man beim Kauf einer Samsung Galaxy S6 Handyhülle
darauf achten, dass der Pulsmesser trotz Hülle zugänglich ist. Ein negativer Punkt des Galasy S6 ist der schwache Akku. Diesen negativen Punkt kann man
jedoch auch durch eine Handyhülle lösen, indem man eine Handyhülle mit integrierten Akku kauft und somit die Laufzeit des Smartphones verlängert.
</p>
<hr>
<?}elseif($_GET["search"] == "galaxy-s5"){ ?>

<h3>
	Samsung Galaxy S5 Hülle
</h3>
<br>
<p>
Du hast dir das neue <b>Samsung Galaxy S5</b> zugelegt und suchst nun nach einem passenden Schutz? 
Wir empfehlen dir von vornherein bei solch einer hochpreisigen Investition den Gedanken an eine passende Schutzhülle nicht zu kurz kommen zu lassen.
Auch für einen etwaigen Wiederverkauf lässt sich so der Wert deines Smartphones beibehalten.
Ein schon sehr kleiner unbeabsichtigte Moment kann dafür Sorge tragen das du dein Smartphone ausversehen vom Tisch stoßt und es dabei zu Boden fällt.
Die nun bleibenden Schäden sehen nicht nur unschön aus, nein sie können zum Teil auch die Funktionalität deines Handys beeinträchtigen. 
Bei uns findest du eine große Auswahl an Handyhüllen die dein Smartphone schützen werden. Doch gewiss erwartet dich kein klobiges Ungetüm womit 
du dich in der Öffentlichkeit schämen müsst, wenn du dein Telefon in der Hand beziehungsweise am Ort hältst. 
Vom dezent edlen Design bis hin zu extravaganten Handyhüllen mit verschiedensten Mustern ist alles für dich nur ein paar Mausklicks entfernt.
 Handyhüllen bieten übrigens nicht nur Schutz, sondern sie sind auch ein Teil des Ausdrucks deiner Persönlichkeit. Tipp: Möchtest du andere wissen 
 lassen welcher Nationalität du angehörst? Dann trage einfach in unserer Suchleiste dein entsprechendes Smartphone plus das Land aus dem du stammst ein. 
 Es werden dir nun Ergebnisse angezeigt mit Handyhüllen samt dem Aufdruck deiner Nationalität. Viel Spass!
</p>
<hr>
<?}elseif($_GET["search"] == "galaxy-s4"){ ?>

<h3>
	Samsung Galaxy S4 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "galaxy-s5-mini"){ ?>

<h3>
	Samsung Galaxy S5 Mini Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "galaxy-s4-mini"){ ?>

<h3>
	Samsung Galaxy S4 Mini Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "galaxy-s4"){ ?>

<h3>
	Samsung Galaxy S4 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "galaxy-note-4"){ ?>

<h3>
	Samsung Galaxy Note 4 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "galaxy-note-3"){ ?>

<h3>
	Samsung Galaxy Note 3 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "galaxy-s7"){ ?>
<h3>
	Samsung Galaxy S7 Hülle
</h3>
<br>
<p>
Bei den Android-Smartphones stellt das Samsung Galaxy S7 neue Geschwindigkeitsrekorde auf und dies mit dem hauseigenen Exynos 8890 und dem neuen Snapdragon 820-Prozessor. 
Das Premium-Handy stammt aus Südkorea und stellt mit dem microSD-Slot, USB C und Android 6.0 die passende Antwort auf das iPhone 6S von Apple dar. Damit ein absolut sicherer Schutz garantiert ist, 
gibt es auch eine passgenaue <strong>Galaxy S7 Hülle</strong>. 
</p>
<p>
Das High-End-Smartphone wurde von Samsung bereits im Februar(2016) vorgestellt und es gibt alle technischen Möglichkeiten von den modernen Mobiltelefonen. Für die höchstmögliche Leistung sorgen 
zwei unterschiedliche Prozessoren und mit zwölf Megapixeln ist die Auflösung von der Kamera beziffert. Die Britecell-Technologie ist für die Aufnahmen in der atemberaubenden Qualität verantwortlich und 
serienreif wurde diese erst Ende des Jahres 2015. Bei der Kameratechnik von den Smartphones stellt diese Technologie aktuell die Speerspitze dar. Samsung bietet bei dem Galaxy S7 Android 6.0.1 und 
es wurden Änderungen vorgenommen, damit auch die notwendige Leistung vorhanden ist. Im Inneren bei dem dünnen Aluminiumgehäuse gibt es vier Gigabyte Arbeitsspeicher und dieses Gehäuse wird mit 
kaum etwas besser geschützt, wie mit einer passenden <strong>Handyhülle</strong>. Eine Galaxy S7 Hülle ist dabei passgenau angefertigt und stabil. 
</p>
<p>
 Durch das richtige Zubehör und dem Samsung Galaxy S7 können sich beim Umgang mit dem Smartphone völlig neue Erlebnisse ergeben. Für das Galaxy S7 gibt es Hüllen für Freizeit, 
 Alltag und für den Beruf. Wird das herausragende Smartphone genutzt, dann können sich durch die Galaxy S7 Hülle komplett neue Anwendungswege eröffnen. In nur einem Produkt gibt es bei der 
 Handyhülle Design, Schutz und Funktionalität vereint. Teilweise kann bei dem Smartphone sogar die Bedienung damit vereinfacht werden. Die Handyhülle bietet sich übrigens auch für den großen 
 Bruder an, der <a href="samsung-galaxy-s7-edge" title="Samsung Galaxy S7 Edge Hülle" alt="Link zu Samsung Galaxy S7 Edge Handyhüllen" >Samsung Galaxy S7 edge</a> genannt wird. Die große Version und auch die Standard-Variante sind dann optimal geschützt und die Geräte halten dann auch eine robustere Behandlung ohne 
 Probleme aus. Die Handys können dann auch rasch in Rucksäcken, Handtaschen oder Beuteln verschwinden. Nicht selten fällt das Gerät auch bei dem sehr  geschäftigen Tag einmal aus der Hand und auch 
 dies stellt mit der entsprechenden Galaxy S7 Hülle kein Problem dar. Durch die  Handyhülle kann der <strong>Aufprall gedämpft</strong> werden und auch in extremeren Situationen können die Smartphones daher geschützt 
 werden. 
</p>
<p>
Das Samsung Galaxy S7 bietet sehr viele zusätzliche Ausstattungsmerkmale und so für die zuverlässige Aufladung den Micro-USB 2.0 Stecker. Der microSD-Pport fasst bis zu 200 Gigabyte, damit die 
Daten auf dem externen Speichermedium einfacher abgelegt werden können. Für das gestochen scharfe Bild sorgt die Quad-HD Auflösung und im Vergleich zu der 720p HD Auflösung ist dies vier Mal so 
hoch. Gerade auch die Implementierung von den microSD-Karten zeigt, dass Samsung auf die Kritik bei dem Vorgänger eingegangen ist. Für die Galaxy S7 Hülle sind alle neuen Schnittstellen übrigens kein 
Problem. Die Handyhülle wurde immer passgenau gefertigt und so gibt es für Ladekabel und PowerBanks einen unkomplizierten Zugang zu dem Gerät und dies auch in geschlossenem Zustand. 
Mit der richtigen Hülle gibt es Eleganz und Performance in jeder Situation. Fakt ist auch, dass eine Galaxy S7 Hülle nie nur eine Schutzfunktion bietet. Wird die Galaxy S7 Hülle beispielsweise seitlich 
aufgeklappt, dann gibt es vor neugierigen Blicken auch einen guten Sichtschutz. Die Hüllen können meist mit einem kurzen Handgriff geöffnet und geschlossen werden. Im Alltag kann eine  Handyhülle 
damit überzeugen, dass sei kein Belastung darstellt und sogar eine <strong>Erleichterung</strong> ist. Bezüglich des Gewichts sind die Hüllen so leicht, dass diese kaum bemerkbar sind.
</p>
<hr>
<?}elseif($_GET["search"] == "desire-816"){ ?>

<h3>
	HTC Desire 816 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "desire-510"){ ?>

<h3>
	HTC Desire 510 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "one-mini-2"){ ?>

<h3>
	HTC One Mini 2 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "one-e8"){ ?>

<h3>
	HTC One E8 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "one-m8"){ ?>

<h3>
	HTC One M8 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "one-m9"){ ?>

<h3>
	HTC One M9 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "l90"){ ?>

<h3>
	LG L90 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "l-bello"){ ?>

<h3>
	LG L Bello Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "g2-mini"){ ?>

<h3>
	LG G2 Mini Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "g2"){ ?>

<h3>
	LG G2 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "g3-s"){ ?>

<h3>
	LG G3s Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "g3"){ ?>

<h3>
	LG G3 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "lumia-625"){ ?>

<h3>
	Nokia Lumia 625 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "lumia-530"){ ?>

<h3>
	Nokia Lumia 530 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "lumia-630"){ ?>

<h3>
	Nokia Lumia 630 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "lumia-730"){ ?>

<h3>
	Nokia Lumia 730 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "lumia-830"){ ?>

<h3>
	Nokia Lumia 830 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "lumia-930"){ ?>

<h3>
	Nokia Lumia 930 Hülle
</h3>
<br>
<p>
Eine Handyhülle für das Nokia Lumia 930 ist eine sinnvolle Investition, um das Smartphone zu schützen.
Das Nokia Lumia930 läuft mit dem Windows Phone 8.1 System und hat die gewohnte Microsoft Optik. 
Das Smartphone bringt ein Design auf dem neusten Stand mit. Es ist schön, robust und farbenfroh.
Um dieses Design auch dauerhaft zu erhalten, empfehlen wir eine <b>Nokia Lumia 930 Hülle</b>. Diese kann 
aus unterschiedlichen Materialien wie beispielsweise Leder, Silikon oder Plastik sein. Außerdem kann man
nicht nur zwischen unterschiedlichen Materialien wählen, sondern sich auch seine Lieblingsfarbe aussuchen.
Mit einer neuen <u>Handyhülle</u> kannst du auch das 5-Zoll-Full-HD-Display schützen, wenn es sich zum Beispiel
in der Tasche befindet oder mit dem Display auf dem Tisch liegt. Auch das Aluminiumgehäuse lässt sich dadurch 
vor möglichen Kratzern schützen. Mit einer Lumia 930 Hülle wird dein Smartphone geschützt und bleibt auf Dauer 
ein echter Hingucker. 
</p>
<hr>
<?}elseif($_GET["search"] == "xperia-e1"){ ?>

<h3>
	Sony Xperia E1 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "xperia-m2"){ ?>

<h3>
	Sony Xperia M2 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "xperia-m"){ ?>

<h3>
	Sony Xperia M Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "xperia-z1"){ ?>

<h3>
	Sony Xperia Z1 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "xperia-z2"){ ?>

<h3>
	Sony Xperia Z2 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "huawei-p8"){ ?>

<h3>
	Huawei P8 Hülle
</h3>
<br>
<p>

<hr>
<?}elseif($_GET["search"] == "xperia-z3"){ ?>

<h3>
	Sony Xperia Z3 Hülle
</h3>
<br>
<p>

</p>
<hr>
<?}elseif($_GET["search"] == "huawei-p9-lite"){ ?>

<h3>
	Huawei P9 Lite Hülle
</h3>
<br>
<p>
Das Huawei P9 löst das <a href="huawei-p8"  title="Huawei P8 Hülle" alt="Link zu Huawei P8 Handyhüllen">Huawei P8</a> ab und Huawei soll hier mehrere Varianten von dem Gerät anbieten. 
Genau wie bereits bei dem P8 wird es wieder das Max, das Lite und die reguläre Version geben. 
Die Lite-Version ist die abgespeckte und günstige Version. Ein Premium soll noch als vierte Variante geplant sein, wo sich die Funktionen und die Ausstattung von dem regulären Modell leicht unterscheiden. 
<strong>Huawei P9 Lite</strong> ist die günstigste Variante von dem P9-Sortiment. Die Käufer erhalten hierfür das Smartphone mit dem 5-Zoll-Display, welches mit Full HD auflöst. 
Huawei nutzt im Inneren den Qualcomm-650-Prozessor und nicht einen Prozessor aus eigener Entwicklung. Bei dem Mittelklasse-Prozessor stehen 16 GByte interner Speicher und 2 GByte 
Arbeitsspeicher zur Verfügung. Bei der Frontkamera sind Selfies mit maximal 5 Megapixeln möglich und der Akku wird mit 2.500 mAh angegeben. Wie auch bei weiteren Modell wird auch bei dem 
P9 die Dual-Hauptkamera das Highlight sein. Die Kamera ist mit doppeltem Sensor und mit doppelter Optik ausgestattet und so werden mit maximal 12 Megapixeln Fotos gemacht. Es gibt einige extra 
Funktionen und die Videoauflösung der Kamera ist gut. Die Kamera soll bei dem P9 Lite über den Laser-Autofokus und über den optischen Bildstabilisator verfügen. 
</p>
<p>
Huawei aus China ist ein sehr guter Tipp, wenn eine starke <strong>Alternative zu Samsung, Apple und Co</strong>. gesucht wird. Huawei bringt starke Smartphones hervor, welche zu den etablierten Marken eine preiswerte 
Alternative darstellen. Es handelt sich für etablierte Marken um richtige Herausforderer und dies durch ansprechende Größen und auch durch ein elegantes Design. Eine Huawei P9 Lite Hülle ist aus diesem 
Grund sehr sinnvoll, denn schließlich soll so ein Smartphone lange Zeit gut aussehen und erhalten bleiben. Eine schützende Huawei P9 Lite Hülle ist genau richtig, denn das Smartphone kann damit zu 
einem richtigen Hingucker werden und es wird rundum Sicherheit geboten. Ein geliebtes Smartphone wird durch eine Hülle immer bestens geschützt, denn schließlich haben es diese Geräte im 
Alltag nicht wirklich leicht. Überall lauern für ein Smartphone schließlich Gefahren, egal ob es ein Schlüsselbund ist, der über das Gehäuse oder über das Display kratzt oder aber die Gefahr, dass ein 
Smartphone auf den Boden fällt. Am besten wird mit der Huawei P9 Lite Hülle auf einen umfassenden Schutz gesetzt und das Smartphone wird mit einer Hülle geschützt. Kleinere Stöße und Stürze 
werden so nicht zu einer Tragödie und es gibt längere Freude an dem Huawei. Die passgenaue <strong>Huawei P9 Lite Hülle</strong> kann Risse, Kratzer und unliebsame Beulen einfach fernhalten. Jedes Huawei 
Smartphone kann sich dann lange Zeit von der besten Seite präsentieren. 
</p>
<p>
Das Smartphone kann sich mit den Hüllen auch immer zu einem persönlichen Schmuckstück entwickeln. Es gibt als Hüllen natürlich abwechslungsreiche Designs und zudem gibt es auch Ledertaschen oder 
Motivhüllen. Bei der eigenen Persönlichkeit wird das Smartphone dann zu einem individuellen <strong>Aushängeschild</strong>. Die richtige Hülle kann jedem zeigen, wie man tickt. Einige der Hüllen machen Smartphones zu 
einem absoluten Blickfang, womit sich die Geräte wunderbar von der breiten Masse abheben können. Modisch und sicher werden Smartphones damit vor Stößen und auch vor Schmutz geschützt. 
Dies ist besonders in der Hektik des Alltags sehr notwendig. Schnell landet ein Smartphone schließlich auf dem Boden oder fällt aus der Tasche. Nachdem die Hüllen sehr leicht und schlank sind, passen 
die Geräte nach wie vor in die Jacken- und Hosentaschen.
</p>
<hr>
<?}elseif($_GET["search"] == "huawei-p9"){ ?>

<h3>
	Huawei P9 Hülle
</h3>
<br>
<p>
Das Huawei P8 ist noch nicht sehr lange Zeit auf dem Markt und schon geht es um den Nachfolger Huawei P9. Bei dem P9 wird vermutlich nicht einfach an Papier-Kennzahlen wie der Pixelzahl oder Größe 
gedreht. Bei dem P9 soll es sich eher um ein moderates Upgrade handeln, wo eher im Detail die Verbesserungen gefunden werden. Im Vergleich zu dem Vorgänger soll das Display nicht besonders 
wachsen. Auch bei dem P9 wird es sich vermutlich um die Bilddiagonale von 5,2 Zoll handeln und gesetzt wird auf die <strong>Full-HD-Auflösung</strong> mit 1920 mal 1.080 Pixeln. Für scharfe Bilder ist die Größe dabei 
absolut ausreichend. Vorstellbar bei dem P9 ist auch der Fingerabdrucksensor und ein neuer Chipsatz. Es gibt die reguläre Variante von dem P9 und im Vergleich zu der Lite-Variante gibt es dort den 
5,2 Zoll-Full-HD-Display. Bei den Kameras wird es im Vergleich zu der Lite-Variante keine Änderungen geben. 
</p>
<p>
Insgesamt gibt es bei dem Huawei P9 eine bessere interne Hardware und ein größeres Display. Huawei nutzt bei der normalen P9-Version den hauseigenen HiSilicon-Kirin-950-Prozessor und verwendet 
wird dieser schon bei dem Huawei Mate 8. Wie im Mate 8 wird der Hauptprozessor auf 32 GByte internen Speicher und auf 3 GByte RAM zurückgreifen. Im Vergleich zu dem 
<a href="huawei-p9-lite"  title="Huawei P9 Lite Hülle" alt="Link zu Huawei P9 Lite Handyhüllen">P9 Lite</a> wird auch der Akku mit 
3.000 mAh leistungsfähiger sein. Das P9 Max ist die größte Variante und hier gibt es ein 6,2-Zoll-Display. Bei dem 
<a href="huawei-p9-max"  title="Huawei P9 Max Hülle" alt="Link zu Huawei P9 Max Handyhüllen">P9 Max</a> soll es eine Full-HD-Auflösung geben und auch das Mate 8 Nutzt bei dem 6 Zoll 
Display die Full-HD-Auflösung. Egal, welche Variante von dem Huawei P9 überlegt wird, immer gibt es eine passende <strong>Huawei P9 Hülle</strong>. Modisch und sicher ist es damit möglich, dass die Smartphones vor 
Schmutz und auch vor Stößen geschützt werden. Notwendig ist dies besonders durch die Hektik des heutigen Alltags. Nicht selten fällt ein Handy aus der Hosentasche und dann landet dieses unsanft auf 
dem Boden. Eine Huawei P9 Hülle kann Abhilfe schaffen und durch das Äußere der Hüllen handelt es sich um richtige Hingucker. Für das Handy gibt es Hüllen aus Silikon und aus schickem Leder. 
</p>
<p>
Sehr wichtig bei der Huawei P9 Hülle ist, dass diese nicht nur gut aussieht und das Gerät schützt, sondern dass auch alle Anschlüsse frei sind. Die Hüllen fallen durch das geringe Gewicht nicht auf und sie 
sind deshalb so schlank, damit sie in alle Jackentaschen, Hosentaschen oder Handtaschen passen. Schade wäre, wenn die Hüllen versteckt werden, denn es gibt schließlich 
<strong>trendige Muster</strong> und auch 
knallige Farben. Bei dem chinesischen Technikkonzern Namens Huawei überzeugen die Smartphones dann mit einem erstklassigen technischen Innenleben und mit günstigen Preisen. Es handelt sich 
um sehr preisbewusste Einsteigermodelle und auch um eine tolle Mittelklasse. Die High-End-Modell werden von der Fachpresse gelobt und es gibt durch die Angebotspalette für jeden ein passendes 
Handy von Huawei. Eine gute Huawei P9 Hülle kann sich wie eine zweite Haut um das Smartphone schmiegen. Keiner muss sich daher sorgen machen, dass das Smartphone aus der Hülle rutscht. 
Auch bei der angelegten Hülle wird das Desgin nicht beeinträchtigt und es handelt sich sogar teilweise um richtige Hingucker. Durch die genaue Passgenauigkeit gibt es eine stilechte Optik und besten Sitz. 
Aussparungen gibt es natürlich immer für den Ladekabel-Anschluss, für den Kopfhörer-Anschluss, für den An/Aus-Schalter, für den Lautstärke-Regler, für den Blitz und auch für die Kamera. 
Die Aussparungen befinden sich immer an der richtigen Stelle.
</p>
<hr>
<?}?>
<?}?>