		<div class="col-sm-6">			

				<div class="btn-group">
					
 					<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true">
    					Farbe 
    					<span class="caret"></span>
  					</button>
					
  					<ul class="dropdown-menu scrollable-menu" role="menu" aria-labelledby="dropdownMenu1">
						
   						<li><a><label>
							<? $pos = strpos($_GET['farbe'], 'blau'); ?>
							<input type="checkbox" name="farbe[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<?  if ($pos === false) { echo $_GET['farbe'].'+blau';}else{echo str_replace("blau","" , $_GET['farbe']);}?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>'">
							Blau
						</label></a></li>

   						<li><a><label>
							<? $pos = strpos($_GET['farbe'], 'braun'); ?>
							<input type="checkbox" name="farbe[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<?  if ($pos === false) { echo $_GET['farbe'].'+braun';}else{echo str_replace("braun","" , $_GET['farbe']);}?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>'">
							Braun
						</label></a></li>

   						<li><a><label>
							<? $pos = strpos($_GET['farbe'], 'gelb'); ?>
							<input type="checkbox" name="farbe[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<?  if ($pos === false) { echo $_GET['farbe'].'+gelb';}else{echo str_replace("gelb","" , $_GET['farbe']);}?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>'">
							Gelb
						</label></a></li>						

   						<li><a><label>
							<? $pos = strpos($_GET['farbe'], 'gruen'); ?>
							<input type="checkbox" name="farbe[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<?  if ($pos === false) { echo $_GET['farbe'].'+gruen';}else{echo str_replace("gruen","" , $_GET['farbe']);}?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>'">
							Grün
						</label></a></li>						

   						<li><a><label>
							<? $pos = strpos($_GET['farbe'], 'orange'); ?>
							<input type="checkbox" name="farbe[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<?  if ($pos === false) { echo $_GET['farbe'].'+orange';}else{echo str_replace("orange","" , $_GET['farbe']);}?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>'">
							Orange
						</label></a></li>

   						<li><a><label>
							<? $pos = strpos($_GET['farbe'], 'pink'); ?>
							<input type="checkbox" name="farbe[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<?  if ($pos === false) { echo $_GET['farbe'].'+pink';}else{echo str_replace("pink","" , $_GET['farbe']);}?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>'">
							Pink
						</label></a></li>

   						<li><a><label>
							<? $pos = strpos($_GET['farbe'], 'rot'); ?>
							<input type="checkbox" name="farbe[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<?  if ($pos === false) { echo $_GET['farbe'].'+rot';}else{echo str_replace("rot","" , $_GET['farbe']);}?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>'">
							Rot
						</label></a></li>					

   						<li><a><label>
							<? $pos = strpos($_GET['farbe'], 'schwarz'); ?>
							<input type="checkbox" name="farbe[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<?  if ($pos === false) { echo $_GET['farbe'].'+schwarz';}else{echo str_replace("schwarz","" , $_GET['farbe']);}?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>'">
							Schwarz
						</label></a></li>
						
						 <li><a><label>
							<? $pos = strpos($_GET['farbe'], 'weiss'); ?>
							<input type="checkbox" name="farbe[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<?  if ($pos === false) { echo $_GET['farbe'].'+weiss';}else{echo str_replace("weiss","" , $_GET['farbe']);}?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>'">
							Weiss
						</label></a></li>
	  
					</ul>
					
				</div>
				
				<div class="btn-group">
				<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-expanded="true">
    					Material 
    					<span class="caret"></span>
  					</button>
				
				<ul class="dropdown-menu " role="menu" aria-labelledby="dropdownMenu2">
						
   						<li><a><label>
							<? $pos = strpos($_GET['material'], 'silikon'); ?>
							<input type="checkbox" name="material[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<? echo $_GET['farbe'];?>&material=<?  if ($pos === false) { echo $_GET['material'].'+silikon';}else{echo str_replace("silikon","" , $_GET['material']);}?>&preis=<? echo $_GET['preis'];?>'">
							Silikon
						</label></a></li>
						
						 <li><a><label>
							<? $pos = strpos($_GET['material'], 'leder'); ?>
							<input type="checkbox" name="material[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<? echo $_GET['farbe'];?>&material=<?  if ($pos === false) { echo $_GET['material'].'+leder';}else{echo str_replace("leder","" , $_GET['material']);}?>&preis=<? echo $_GET['preis'];?>'">
							Leder
						</label></a></li>

						 <li><a><label>
							<? $pos = strpos($_GET['material'], 'plastik'); ?>
							<input type="checkbox" name="material[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<? echo $_GET['farbe'];?>&material=<?  if ($pos === false) { echo $_GET['material'].'+plastik';}else{echo str_replace("plastik","" , $_GET['material']);}?>&preis=<? echo $_GET['preis'];?>'">
							Plastik
						</label></a></li>
	  					
					
					</ul>
			</div>
			<div class="btn-group">
				<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-expanded="true">
    					Preis 
    					<span class="caret"></span>
  					</button>
				
				<ul class="dropdown-menu " role="menu" aria-labelledby="dropdownMenu2">
						
   						<li><a><label>
							<? $pos = strpos($_GET['preis'], 'spanne1'); ?>
							<input type="checkbox" name="preis[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<?  if ($pos === false) { echo $_GET['preis'].'+spanne1';}else{echo str_replace("spanne1","" , $_GET['preis']);}?>'">
							5 - 10 Euro
						</label></a></li>
						
   						<li><a><label>
							<? $pos = strpos($_GET['preis'], 'spanne2'); ?>
							<input type="checkbox" name="preis[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<?  if ($pos === false) { echo $_GET['preis'].'+spanne2';}else{echo str_replace("spanne2","" , $_GET['preis']);}?>'">
							10 - 20 Euro
						</label></a></li>
					
					   	<li><a><label>
							<? $pos = strpos($_GET['preis'], 'spanne3'); ?>
							<input type="checkbox" name="preis[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<?  if ($pos === false) { echo $_GET['preis'].'+spanne3';}else{echo str_replace("spanne3","" , $_GET['preis']);}?>'">
							20 - 30 Euro
						</label></a></li>
					
						<li><a><label>
							<? $pos = strpos($_GET['preis'], 'spanne4'); ?>
							<input type="checkbox" name="preis[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<?  if ($pos === false) { echo $_GET['preis'].'+spanne4';}else{echo str_replace("spanne4","" , $_GET['preis']);}?>'">
							30 - 40 Euro
						</label></a></li>
					
						<li><a><label>
							<? $pos = strpos($_GET['preis'], 'spanne5'); ?>
							<input type="checkbox" name="preis[]" <?php if ($pos === false) { }else{echo 'checked';}?> onchange="javascript:location.href='/result.php?search=<? echo $_GET["search"]; ?>&farbe=<? echo $_GET['farbe'];?>&preis=<?  if ($pos === false) { echo $_GET['preis'].'+spanne5';}else{echo str_replace("spanne5","" , $_GET['preis']);}?>'">
							40 - 50 Euro
						</label></a></li>
					
				</ul>
			</div>
		</div>
			