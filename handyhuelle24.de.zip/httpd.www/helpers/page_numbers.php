<nav style="text-align:right;">
  
  <ul class="pagination">
     <li>
      <? if (isset($_GET['page']) and $_GET['page']!=1 ){  ?><a  href="result.php?page=<? echo $_GET['page']-1; ?>&search=<? echo $_GET['search']; ?>&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>" aria-label="Previous"><?}?>

        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>

    <li class="<? if($_GET['page']==1 or !isset($_GET['page'])){echo "active";} ?>"><a href="http://handyhuelle24.de/result.php?search=<? echo $_GET['search']; ?>&page=1&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>">1</a></li>
    <li class="<? if($_GET['page']==2){echo "active";} ?>"><a href="/result.php?search=<? echo $_GET['search']; ?>&page=2&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>">2</a></li>
    <li class="<? if($_GET['page']==3){echo "active";} ?>"><a href="/result.php?search=<? echo $_GET['search']; ?>&page=3&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>">3</a></li>
    <li class="<? if($_GET['page']==4){echo "active";} ?>"><a href="/result.php?search=<? echo $_GET['search']; ?>&page=4&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>">4</a></li>
    <li class="<? if($_GET['page']==5){echo "active";} ?>"><a  href="/result.php?search=<? echo $_GET['search']; ?>&page=5&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>">5</a></li>


    <li>
    <? if ( $_GET['page']!=5 ){  ?><a href="/result.php?page=<? if (isset($_GET['page'])){ echo $_GET['page']+1; }else{ echo 2;} ?>&search=<? echo $_GET['search']; ?>&farbe=<? echo $_GET['farbe'];?>&material=<? echo $_GET['material'];?>&preis=<? echo $_GET['preis'];?>" aria-label="Next"><?}?>
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>

