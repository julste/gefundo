<!DOCTYPE html>
<html lang="de">
<? $page="sitemap" ; ?>
    <? include( "head.php"); ?>

        <body>
            <? include( "nav.php"); ?>
                <div style="padding-top: 50px; padding-bottom: 50px;">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 col-lg-12 col-md-12">
                                <h3><strong>Sitemap</strong></h3>
								<br>
								<h4>Bettwaesche123.de</h4>
                               <ul>
							   <li><a href="/" title="Startseite">Startseite</a> </li>
							   <li><a href="/datenschutzerklaerung" title="Datenschutzerklärung">Datenschutzerklärung</a> </li>
							   <li><a href="/impressum" title="Impressum">Impressum</a> </li>
							   <li><a href="/sitemap" title="Sitemap">Sitemap</a> </li>
							     
							   </ul>
							   	<br>
								<h4>Farben</h4>
                               <ul>
							   <?
							    try {
									$user = "bettwaesche123_de";
									$pass = "23Max3pR";
									$dbh = new PDO('mysql:host=bettwaesche123.de.mysql;dbname=bettwaesche123_de', $user, $pass);
									$dbh->query("SET CHARACTER SET utf8");
									$sql = 'SELECT * from bettwaesche123_page where category = "Farbe"';
									foreach($dbh->query($sql) as $row){
									 echo "<li><a href='/".$row['slug']."' title='".$row['searchname']."'>".$row['searchname']."</a> </li>";
									}
							 
									$dbh = null;
								} catch (PDOException $e) {
								   //print "Error!: " . $e->getMessage() . "<br/>";
								   die();
								}
							   ?>
							   </ul>
							   
							    <br>
								<h4>Muster</h4>
                               <ul>
							   <?
							    try {
									$user = "bettwaesche123_de";
									$pass = "23Max3pR";
									$dbh = new PDO('mysql:host=bettwaesche123.de.mysql;dbname=bettwaesche123_de', $user, $pass);
									$dbh->query("SET CHARACTER SET utf8");
									$sql = 'SELECT * from bettwaesche123_page where category = "Muster"';
									foreach($dbh->query($sql) as $row){
									 echo "<li><a href='/".$row['slug']."' title='".$row['searchname']."'>".$row['searchname']."</a> </li>";
									}
							
									$dbh = null;
								} catch (PDOException $e) {
								   //print "Error!: " . $e->getMessage() . "<br/>";
								   die();
								}
							   ?>
							   </ul>
							   
							    <br>
								<h4>Motive</h4>
                               <ul>
							   <?
							    try {
									$user = "bettwaesche123_de";
									$pass = "23Max3pR";
									$dbh = new PDO('mysql:host=bettwaesche123.de.mysql;dbname=bettwaesche123_de', $user, $pass);
									$dbh->query("SET CHARACTER SET utf8");
									$sql = 'SELECT * from bettwaesche123_page where category = "Motiv"';
									foreach($dbh->query($sql) as $row){
									 echo "<li><a href='/".$row['slug']."' title='".$row['searchname']."'>".$row['searchname']."</a> </li>";
									}
							
									$dbh = null;
								} catch (PDOException $e) {
								   //print "Error!: " . $e->getMessage() . "<br/>";
								   die();
								}
							   ?>
							   </ul>
							   
												   
							   	<br>
								<h4>Merkmale</h4>
                               <ul>
							   <?
							    try {
									$user = "bettwaesche123_de";
									$pass = "23Max3pR";
									$dbh = new PDO('mysql:host=bettwaesche123.de.mysql;dbname=bettwaesche123_de', $user, $pass);
									$dbh->query("SET CHARACTER SET utf8");
									$sql = 'SELECT * from bettwaesche123_page where category = "Merkmal"';
									foreach($dbh->query($sql) as $row){
									 echo "<li><a href='/".$row['slug']."' title='".$row['searchname']."'>".$row['searchname']."</a> </li>";
									}
							
									$dbh = null;
								} catch (PDOException $e) {
								   //print "Error!: " . $e->getMessage() . "<br/>";
								   die();
								}
							   ?>
							   </ul>
							   
							   	<br>
								<h4>Marken</h4>
                               <ul>
							   <?
							    try {
									$user = "bettwaesche123_de";
									$pass = "23Max3pR";
									$dbh = new PDO('mysql:host=bettwaesche123.de.mysql;dbname=bettwaesche123_de', $user, $pass);
									$dbh->query("SET CHARACTER SET utf8");
									$sql = 'SELECT * from bettwaesche123_page where category = "Marke"';
									foreach($dbh->query($sql) as $row){
									 echo "<li><a href='/".$row['slug']."' title='".$row['searchname']."'>".$row['searchname']."</a> </li>";
									}
							
									$dbh = null;
								} catch (PDOException $e) {
								   //print "Error!: " . $e->getMessage() . "<br/>";
								   die();
								}
							   ?>
							   </ul>
							   
							   
							   	<br>
								<h4>Material</h4>
                               <ul>
							   <?
							    try {
									$user = "bettwaesche123_de";
									$pass = "23Max3pR";
									$dbh = new PDO('mysql:host=bettwaesche123.de.mysql;dbname=bettwaesche123_de', $user, $pass);
									$dbh->query("SET CHARACTER SET utf8");
									$sql = 'SELECT * from bettwaesche123_page where category = "Material"';
									foreach($dbh->query($sql) as $row){
									 echo "<li><a href='/".$row['slug']."' title='".$row['searchname']."'>".$row['searchname']."</a> </li>";
									}
							
									$dbh = null;
								} catch (PDOException $e) {
								   //print "Error!: " . $e->getMessage() . "<br/>";
								   die();
								}
							   ?>
							   </ul>
							   
							   
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <? include( "footer.php"); ?>
        </body>

</html>