<? session_start();?>
<!DOCTYPE html>
<html lang="de">
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<? $page = "kontakt"; ?>
<? include("head.php");?>


<body>

<? include("nav.php"); ?>
<div style="padding-top: 60px; padding-bottom: 10px;">
    <div class="container">
		<div class="row">
       		<div class="col-sm-12 col-lg-12 col-md-12">
	
<?		
	$captcha = FALSE;
	
	if( isset($_SESSION["captcha"])) {

		if( isset($_POST["sum"]) && $_POST['sum'] == $_SESSION["captcha"]){
			$captcha = TRUE;
		}
	}
?>		
	
<?
if ( isset ($_POST['submit'])) {  // Check for each form value when the form is submitted:
	$problem = FALSE; // no problems!

if ( empty ($_POST['name'])) {    
	$problem = TRUE;
	$error_name = "<div class='alert alert-danger' role='alert'><p>Bitte gib deinen <b>Namen</b> an.</p></div>";	
	}
	
$email =$_POST["email"];
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
	$problem = TRUE;
	$error_email = "<div class='alert alert-danger' role='alert'><p>Bitte gib eine g&uuml;ltige <b>E-Mail Addresse</b> an.</p></div>";
	}

if (empty ($_POST['subject']))	{
	$problem = TRUE;
	$error_subject = "<div class='alert alert-danger' role='alert'><p>Bitte gib einen <b>Betreff</b> an.</p></div>";
	}

if ( empty ($_POST['message']))  {    
	$problem = TRUE;
	$error_message = "<div class='alert alert-danger' role='alert'><p>Bitte gib deine <b>Mitteilung</b> an.</p></div>";
	}
	
if ($captcha == FALSE){
	$problem = TRUE;
	$error_captcha = "<div class='alert alert-danger' role='alert'><p>Die eingegebene <b>Sicherheitsabfrage</b> ist falsch! Bitte wiederholen.</p></div>";
	}

if (!$problem) { 
	$send = TRUE;	
	print ("<br><div class='alert alert-success' role='alert'><p>Vielen Dank für Ihre Nachricht, <b>{$_POST['name']}</b>!</p>\n</div>"); 
	echo "<br><br>";
	echo "<a href='/'>Zur Hauptseite</a>";
	
	$nachricht = utf8_decode ($_POST['message']);
	$betreff = utf8_decode ($_POST['subject']);
	$name = utf8_decode ($_POST['name']);
	
	$header = 'From: '.$_POST['email'].'' . "\r\n" .
    'Reply-To: '.$_POST['email'].'' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
	
	
	
	$mailMesage =  ("{$name} {$_POST['email']} schrieb von bettwaesche123.de: \n\n{$nachricht}"); 
	$mailSubject = "{$betreff}"; 
	//$mailSubject = ("Kontaktanfrage von: {$_POST['name']}");
	mail ('mail@bettwaesche123.de', $mailSubject , $mailMesage, $header);

	unset($_SESSION['captcha']);
	unset($POST['name']);
	unset($POST['email']);	
	unset($POST['subject']);	
	unset($POST['message']);		
	}

}
?>
	
<?
if($send != TRUE){
?>
				
<? //<form role="form" name="kontaktFormular" method="POST" action="index.php?page=kontakt"> ?>
<form role="form" name="kontaktFormular" method="POST" action="/kontakt.php"> 
 
<h2>Kontakt</h2>
<p>
	Bitte benutze dieses Kontaktformular um uns zu schreiben. Die kleine Rechenaufgabe schützt uns vor unerwünschten Nachrichten.
</p>
	
<br>	
	
<div class="col-sm-6 col-lg-6 col-md-6">
	<div class="form-group">	
		<?echo $error_name;?>
		<label for="name">Name:</label>
		<input name="name" type="name" class="form-control" id="name" size="50" value="<?echo$_POST['name'];?>" placeholder="">		
	</div> <? // <!-- Ende form-group  --> ?>
	
	<div class="form-group">
		<?echo $error_email;?>
		<label for="name">E-Mail:</label>
		<input name="email" type="text" class="form-control" id="email" size="50" value="<?echo$_POST['email'];?>" placeholder="">	
	</div> <? // <!-- Ende form-group  --> ?>

	<div class="form-group">
		<?echo $error_subject;?>
		<label for="name">Betreff:</label>
		<input name="subject" type="text" class="form-control" id="subject" size="50" value="<?echo$_POST['subject'];?>" placeholder="">
	</div> <? // <!-- Ende form-group  --> ?>

	<div class="form-group">
		<?echo $error_message;?>
		<label for="name">Nachricht:</label>
		<textarea name="message" class="form-control" cols="60" rows="5"><?echo$_POST[ 'message'];?></textarea>		
	</div> <? // <!-- Ende form-group  --> ?>
	
	<div class="form-group">
		<?echo $error_captcha;?>
		<label for="sum">Sicherheitsabfrage:</label>
			<?
				$first = rand(0,20);
				$second = rand(0,20);
				$final = $first + $second;
				echo $first." + ".$second." = ";				 				
				$_SESSION["captcha"] = $final;
			?>
		<input name="sum" type="text" class="form-control" size="5" placeholder="">		
	</div> <? // <!-- Ende form-group  --> ?>

	<div class="form-group">
		<button type="submit" name="submit" value="Absenden" class="btn btn-default">Absenden</button>
	</div> <? // <!-- Ende form-group  --> ?>	
</form>
	
<?} ?>
    			
				</div> <? // <!-- Ende Col-6  --> ?>
			</div> <? // <!-- Ende Col-12  --> ?>
		</div> <? // <!-- Ende Row  --> ?>
	</div> <? // <!-- Ende Container  --> ?>
</div>
	
<? include("footer.php");?>

</body>
</html>