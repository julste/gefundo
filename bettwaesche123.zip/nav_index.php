<nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
    <div class="container topnav">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            <div style="padding-top:5px; padding-bottom: 5px;">
                <a href="/" title="stoff123.de"> 
				<img src="/img/bettwaesche123-logo.png" title="Deine Bettwäsche online finden!" alt="Bettwäsche123 online - Finde deinen Bettwäsche" class="img-responsive" />
				</a>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="padding-top:8px;">
            <ul class="nav navbar-nav navbar-right">
                <li> <a href="/#unser-taeglicher-begleiter" title="Bettwäsche – unser täglicher Begleiter">Unser täglicher Begleiter</a> </li>
                <li> <a href="/#material" title="Material">Material</a> </li>
                <li> <a href="/#stil-und-trends" title="Stil und Trends">Stil und Trends</a> </li>
            </ul>
        </div>
    </div> 
</nav>