<a name="about"></a>
<div class="intro-header">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <br>
                <h1 class="hidden-xs pull-right">Bettwäsche<br> online finden!</h1>
                <div class="intro-message">
                    <form action="/result.php" method="GET" class="form-group" name="Formular" role="search" onsubmit="return chkFormular();">
                        <div class="input-group col-xs-10 col-sm-8 col-md-8 col-lg-8 col-xs-offset-1 col-sm-offset-2 col-md-offset-2 searchbar">
                            <input type="text" class="form-control input-lg" placeholder="Suche nach Muster, Motiv, Farbe und mehr..." name="q">
                            <div class="input-group-btn">
                                <button class="btn btn-success btn-lg" type="submit"> <i class="glyphicon glyphicon-search"></i> </button>
                            </div>
                        </div>
                    </form>
                    <div class="hidden-xs col-xs-8 col-lg-8 col-xs-offset-2 col-md-offset-2" style="background-color:rgba(0, 0, 0, 0.7);">
                        <h4 class="startseite-linkfenster"> <a class="startseite" href="flauschig"title="Bettwäsche Flauschig">Flauschig</a> | <a class="startseite" href="kinder" title="Bettwäsche Kinder">Kinderbettwäsche</a> | <a class="startseite" href="weinrot" title="Bettwäsche weinrot">Weinrot</a> | <a class="startseite" href="blau" title="Bettwäsche blau">Blau</a> | <a class="startseite" href="punkte" title="Bettwäsche Punkte">Punkte</a> | <a class="startseite" href="gestreift" title="Bettwäsche gestreift">Gestreift</a> | <a class="startseite" href="star-wars" title="Bettwäsche Star Wars">Star Wars</a> | <a class="startseite" href="pokemon" title="Bettwäsche Pokemon">Pokemon</a></h4> </div>
                </div>
            </div>
        </div>
    </div>
</div>