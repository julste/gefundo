<head>
<style>
<?
if($page == "result"){
	include("abovethefoldResult.php");
}else{
	include("abovethefold.php");
}
?>
</style>
	<? if($page =="index"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Bettwäsche in vielen verschiedenen Farben, Mustern und mehr! Jetzt auf Bettwaesche123.de online deine Bettwäsche finden und gemütlich schlafen!">
	<meta name="keywords" content="Bettäsche, Kissen, Bettzeug, Bettbezug, online, gemütlich, günstig">
    <meta name="author" content="Bettwaesche123.de">
    <title>Bettwäsche online finden - Ganz einfach auf Bettwaesche123.de!</title>
	<?}?>
	<? if($page =="impressum"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Bettwaesche123.de">
	<meta name="robots" content="noindex, nofollow">
    <title>Bettwäsche 123  - Impressum</title>
	<?}?>
	<? if($page =="kontakt"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Bettwaesche123.de">
    <title>Bettwäsche 123  - Kontakt</title>
	<?}?>
	<? if($page =="datenschutzerklaerung"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Bettwaesche123.de">
	<meta name="robots" content="noindex, nofollow">
    <title>Bettwäsche 123  - Datenschutzerklärung</title>
	<?}?>
	<? if($page =="sitemap"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Bettwaesche123.de">
    <title>Bettwäsche 123 - Sitemap</title>
	<?}?>
	<?
	 try {
	$user = "bettwaesche123_de";
	$pass = "23Max3pR";
	$dbh = new PDO('mysql:host=bettwaesche123.de.mysql;dbname=bettwaesche123_de', $user, $pass);
	$sql = 'SELECT * from bettwaesche123_page where slug = "'.$_GET["q"].'"';
	$dbh->query("SET CHARACTER SET utf8");
	$row = $dbh->query($sql)->fetch();
	$slug = $row['slug'];
	$searchname = $row['searchname'];
	$googlename = $row['googlename'];
	$category = $row['category'];
    $dbh = null;
} catch (PDOException $e) {
   //print "Error!: " . $e->getMessage() . "<br/>";
   die();
}
	?>
	<? if($page =="result"){?>
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
    	<meta name="author" content="Bettwaesche123.de">
	<? if($row['category'] == "Farbe"){
		if($_GET['page'] == 1){?>
		<meta name="description" content="Bestelle schöne Bettwäsche in <? echo $row['googlename']; ?> ganz einfach zu dir nach Hause. Hier findest du Bettwäsche in <? echo $row['googlename']; ?> und vielen anderen Farben besonders preiswert.">
		<title>Tolle Bettwäsche in <? echo $row['googlename']; ?> - online finden auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, online, kaufen, Farbe, <? echo $row['googlename']; ?>">
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content="So weit das Auge reicht: Bettwäsche in <? echo $row['googlename']; ?>! Auf bettwaesche123.de findest du hochwertige Bettwäsche in <? echo $row['googlename']; ?> und vielen anderen schönen Farben.">
		<title>Preiswerte Bettwäsche in <? echo $row['googlename']; ?> - online auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, online, kaufen, Farbe, <? echo $row['googlename']; ?>">
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content="Schöne Bettwäsche in <? echo $row['googlename']; ?> gesucht? Auf bettwaesche123.de findest du eine große Auswahl an Bettwäsche in <? echo $row['googlename']; ?> und schönen anderen Farben.">
		<title><? echo $row['googlename']; ?>, <? echo $row['googlename']; ?>, <? echo $row['googlename']; ?> - günstige Angebote auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, online, kaufen, Farbe, <? echo $row['googlename']; ?>">
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content="Du suchst Bettwäsche in <? echo $row['googlename']; ?>? Günstige Preise, riesige Auswahl, tolle Farben - das alles findest du auf bettwaesche123.de">
		<title>Bettwäsche in <? echo $row['googlename']; ?> - bettwaesche123.de hat die besten Angebote!</title>
		<meta name="keywords" content="Bettwäsche, online, kaufen, Farbe, <? echo $row['googlename']; ?>">
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content="Tolle Bettwäsche in <? echo $row['googlename']; ?> zu super Preisen und in bester Qualität findest du online auf bettwaesche123.de! Deine neue Bettwäsche wartet auf dich!">
		<title><? echo $row['googlename']; ?> und andere Farben - deine Bettwaesche auf bettwaesche123.de</title>
		<meta name="keywords" content="Bettwäsche, online, kaufen, Farbe, <? echo $row['googlename']; ?>">
		<?}else{?>
		<meta name="description" content="Bettwäsche in <? echo $row['googlename']; ?> online finden auf bettwaesche123.de - riesige Auswahl an Bettwäsche in <? echo $row['googlename']; ?> und vielen anderen schönen Farben - komm vorbei!">
		<title>Deine neue Bettwäsche in <? echo $row['googlename']; ?> - jetzt auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, online, kaufen, Farbe, <? echo $row['googlename']; ?>">
		<? }?>
	<?}elseif($row['category'] == "Muster"){?>
		<?if($_GET['page'] == 1){?>
		<meta name="description" content='Schöne Bettwäsche in der Variante <? echo $row['googlename']; ?> gibt es online auf bettwaesche123.de. <? echo $row['googlename']; ?> und andere tolle Muster für Bettwäsche warten auf dich!'>
		<title><? echo $row['googlename']; ?> - finde deine Bettwäsche auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, Muster, <? echo $row['googlename']; ?>, gemustert, online, kaufen">
		
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content='Du suchst Bettwäsche in der Variante <? echo $row['googlename']; ?>? Bettwaesche123.de hat eine große Auswahl an Bettwäsche im Muster <? echo $row['googlename']; ?> und weiteren Dessins.'>
		<title>Bettwäsche mit dem Muster <? echo $row['googlename']; ?> - klick auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, Muster, <? echo $row['googlename']; ?>, gemustert, online, kaufen">
		
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content='Bettwäsche in der Variante <? echo $row['googlename']; ?> und andere Bettwäsche findest du auf bettwaesche123.de. <? echo $row['googlename']; ?> - günstige Preise und riesige Auswahl!'>
		<title><? echo $row['googlename']; ?> - ein top Muster für Bettwäsche - auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, Muster, <? echo $row['googlename']; ?>, gemustert, online, kaufen">
		
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content='Schöne Bettwäsche mit dem Muster <? echo $row['googlename']; ?> gibt es auf bettwaesche123.de. Die Variante <? echo $row['googlename']; ?> und mehr Bettwäschen zu günstigen Preisen!'>
		<title>Finde Musterbettwäsche online - zum Beispiel im Design <? echo $row['googlename']; ?>!</title>
		<meta name="keywords" content="Bettwäsche, Muster, <? echo $row['googlename']; ?>, gemustert, online, kaufen">
		
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content='Bettwaesche123.de hat <? echo $row['googlename']; ?> und andere Muster für schöne Bettwäsche. Deine neue Bettwäsche im Muster <? echo $row['googlename']; ?> ist nur einen Klick entfernt!'>
		<title>Bettwäsche im Muster <? echo $row['googlename']; ?> gesucht? Wir helfen dir!</title>
		<meta name="keywords" content="Bettwäsche, Muster, <? echo $row['googlename']; ?>, gemustert, online, kaufen">
		
		<?}else{?>
		<meta name="description" content='<? echo $row['googlename']; ?> - ein tolles Muster für Bettwäsche. Auf bettwaesche123.de findest du <? echo $row['googlename']; ?> und Bettwäsche mit anderen Mustern zu günstigen Preisen! '>
		<title>Schöne Bettwäsche mit dem Muster <? echo $row['googlename']; ?> - auf bettwaesche123.de</title>
		<meta name="keywords" content="Bettwäsche, Muster, <? echo $row['googlename']; ?>, gemustert, online, kaufen">
		
		<?}?>
	<? }elseif($row['category'] == "Motiv"){?>
		<?if($_GET['page'] == 1){?>
		<meta name="description" content='Finde deine neue Bettwäsche mit dem Motiv <? echo $row['googlename']; ?>! <? echo $row['googlename']; ?> und andere Motive - bettwaesche123.de hat deine neue Bettwäsche!'>
		<title><? echo $row['googlename']; ?> - toll für Bettwäsche - auf bettwaesche123.de</title>
		<meta name="keywords" content="Bettwäsche, Motiv, <? echo $row['googlename']; ?>, Kinder, bedruckt, Trend">
		
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content='Du suchst nach Bettwäsche mit dem Motiv <? echo $row['googlename']; ?>? Auf bettwaesche123.de gibt es tolle Angebote und viele schöne Motive - auch <? echo $row['googlename']; ?>!'>
		<title>Schöne Bettwäsche mit dem Motiv <? echo $row['googlename']; ?> einfach online finden!</title>
		<meta name="keywords" content="Bettwäsche, Motiv, <? echo $row['googlename']; ?>, Kinder, bedruckt, Trend">
		
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content='Bettwäsche mit dem Motiv <? echo $row['googlename']; ?> gesucht? Komm vorbei auf bettwaesche123.de und finde deine neue Bettwäsche mit dem Motiv <? echo $row['googlename']; ?> und mehr!'>
		<title>Bettwäsche mit Motiven online - <? echo $row['googlename']; ?> und vieles mehr!</title>
		<meta name="keywords" content="Bettwäsche, Motiv, <? echo $row['googlename']; ?>, Kinder, bedruckt, Trend">
		
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content='Du suchst Bettwäsche mit dem Motiv <? echo $row['googlename']; ?>? Tolle Angebote und schöne Motive, zum Beispiel <? echo $row['googlename']; ?> findest du hier! '>
		<title><? echo $row['googlename']; ?> - Bettwäsche mit Motiv online auf bettwaesche123.de</title>
		<meta name="keywords" content="Bettwäsche, Motiv, <? echo $row['googlename']; ?>, Kinder, bedruckt, Trend">
		
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content='<? echo $row['googlename']; ?> und andere schöne Motive findest du auf bettwaesche123.de! Bettwäsche ohne Ende in vielen Motive - zum Beispiel <? echo $row['googlename']; ?>. Schau vorbei!'>
		<title>Bettwäsche mit dem Motiv <? echo $row['googlename']; ?> - wir helfen dir suchen!</title>
		<meta name="keywords" content="Bettwäsche, Motiv, <? echo $row['googlename']; ?>, Kinder, bedruckt, Trend">
		
		<?}else{?>
		<meta name="description" content='Auf bettwaesche123.de findest du schöne Bettwäsche mit dem Motiv <? echo $row['googlename']; ?>. Deine neue Bettwäsche mit dem Motiv <? echo $row['googlename']; ?> ist ganz nah!'>
		<title><? echo $row['googlename']; ?> und andere Motive - günstige Bettwäsche online!</title>
		<meta name="keywords" content="Bettwäsche, Motiv, <? echo $row['googlename']; ?>, Kinder, bedruckt, Trend">
		
		<?}?>
	<? }elseif($row['category'] == "Material"){?>	
		<?if($_GET['page'] == 1){?>
		
		<meta name="description" content='Du suchst nach Bettwäsche aus <? echo $row['googlename']; ?>? Bei uns findest du schöne Bettwäsche in tollen Farben zu günstigen Preisen - aus <? echo $row['googlename']; ?> und mehr!'>
		<title>Bettwäsche aus <? echo $row['googlename']; ?> - online auf bettwaesche123.de</title>
		<meta name="keywords" content="Bettwäsche, Stoff, Material, <? echo $row['googlename']; ?>">
		<?}elseif($_GET['page'] == 2){?>
		
		<meta name="description" content='Auf Bettwaesche123.de findest du schöne Bettwäsche aus <? echo $row['googlename']; ?> und vielen anderen Materialien. Deine neue Bettwäsche aus <? echo $row['googlename']; ?> wartet auf dich! '>
		<title><? echo $row['googlename']; ?> - ein toller Stoff für Bettwäsche!</title>
		<meta name="keywords" content="Bettwäsche, Stoff, Material, <? echo $row['googlename']; ?>">
		<?}elseif($_GET['page'] == 3){?>
		
		<meta name="description" content='Bettwaesche123.de zeigt dir schöne Bettwäsche aus <? echo $row['googlename']; ?> zu günstigen Preisen! Tolle Angebote für Bettwäsche aus <? echo $row['googlename']; ?> - schau doch mal vorbei!'>
		<title>Bettwäsche online finden - zum Beispiel aus <? echo $row['googlename']; ?>!</title>
		<meta name="keywords" content="Bettwäsche, Stoff, Material, <? echo $row['googlename']; ?>">
		<?}elseif($_GET['page'] == 4){?>
		
		<meta name="description" content='Du suchst Bettwäsche aus <? echo $row['googlename']; ?>? Auf bettwaesche123.de wirst du fündig! Schöne Bettwäsche aus <? echo $row['googlename']; ?> und anderen Stoffen findest du bei uns!'>
		<title>Bettwäsche aus <? echo $row['googlename']; ?> - günstige Preise, riesige Auswahl!</title>
		<meta name="keywords" content="Bettwäsche, Stoff, Material, <? echo $row['googlename']; ?>">
		<?}elseif($_GET['page'] == 5){?>
		
		<meta name="description" content='Schöne Bettwäsche aus <? echo $row['googlename']; ?> und vielen anderen Materialien - online auf bettwaesche123.de! Finde deine neue Bettwäsche aus <? echo $row['googlename']; ?>!'>
		<title>Auf der Suche nach Bettwäsche aus <? echo $row['googlename']; ?>? </title>
		<meta name="keywords" content="Bettwäsche, Stoff, Material, <? echo $row['googlename']; ?>">
		<?}else{?>
		
		<meta name="description" content='Bettwaesche123.de hat eine große Auswahl an Bettwäsche aus <? echo $row['googlename']; ?> zu günstigen Preisen. Schöne Bettwäsche aus <? echo $row['googlename']; ?> und viel mehr - komm vorbei!'>
		<title>Finde deine Bettwäsche aus <? echo $row['googlename']; ?> - ganz einfach online!</title>
		<meta name="keywords" content="Bettwäsche, Stoff, Material, <? echo $row['googlename']; ?>">
		<?}?>		
		
	<? }elseif($row['category'] == "Merkmal"){?>	
		<?if($_GET['page'] == 1){?>
		<meta name="description" content='<? echo $row['googlename']; ?> - Bettwäsche mit diesem und vielen anderen Merkmalen bieten wir dir auf bettwaesche123.de. Klick rein und finde deine neue Bettwäsche.'>
		<title>Bettwäsche mit dem Merkmal <? echo $row['googlename']; ?> online finden!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Merkmal, schön, gemütlich">
		
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content='<? echo $row['googlename']; ?> - du suchst Bettwäsche mit diesem Merkmal? Hier findest du eine große Auswahl an schöner Bettwäsche mit dem Merkmal <? echo $row['googlename']; ?>!'>
		<title>Günstig auf bettwaesche123.de - Bettwäsche <? echo $row['googlename']; ?>!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Merkmal, schön, gemütlich">
		
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content='Auf bettwaesche123.de wartet schöne Bettwäsche mit dem Attribut <? echo $row['googlename']; ?> auf dich. Finde deine neue Bettwäsche mit dem Merkmal <? echo $row['googlename']; ?>!'>
		<title>Bettwäsche mit dem Merkmal <? echo $row['googlename']; ?> gesucht? </title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Merkmal, schön, gemütlich">
		
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content='Günstige Preise, riesige Auswahl  - Bettwäsche mit dem Merkmal <? echo $row['googlename']; ?> auf bettwaesche123.de. <? echo $row['googlename']; ?> - dies und mehr online hier!'>
		<title>Schöne Bettwäsche mit dem Attribut <? echo $row['googlename']; ?> findest du hier!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Merkmal, schön, gemütlich">
		
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content='Auf bettwaesche123.de findest du Bettwäsche mit der Eigenschaft <? echo $row['googlename']; ?>. Deine Bettwäsche mit dem Merkmal <? echo $row['googlename']; ?> wartet auf dich!'>
		<title><? echo $row['googlename']; ?> - Bettwäsche mit diesem Merkmal online aussuchen!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Merkmal, schön, gemütlich">
		
		<?}else{?>
		<meta name="description" content='Schöne Bettwäsche mit dem Merkmal <? echo $row['googlename']; ?> auf bettwaesche123.de! Komm vorbei und lass dich von top Angeboten und günstigen Preisen überraschen!'>
		<title>Finde deine Bettwäsche mit dem Attribut <? echo $row['googlename']; ?> hier!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Merkmal, schön, gemütlich">
		
		<?}?>		
	<? }elseif($row['category'] == "Marke"){?>		
		<?if($_GET['page'] == 1){?>
		
		<meta name="description" content='Suchst du nach Bettwäsche von <? echo $row['googlename']; ?>? Dann bist du auf bettwaesche123.de genau richtig! Bettwäsche von <? echo $row['googlename']; ?> und viel mehr findest du bei uns!'>
		<title>Deine neue Bettwäsche von <? echo $row['googlename']; ?> online finden!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Marken, Designer, Trend, online">
		<?}elseif($_GET['page'] == 2){?>
		
		<meta name="description" content='Du bist verrückt nach Bettwäsche der Marke <? echo $row['googlename']; ?>? Dann schau vorbei und finde schöne Bettwäsche von <? echo $row['googlename']; ?> und vielen anderen Marken!'>
		<title>Schöne Bettwäsche von <? echo $row['googlename']; ?> - online auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Marken, Designer, Trend, online">
		<?}elseif($_GET['page'] == 3){?>
		
		<meta name="description" content='Auf bettwaesche123.de gibt es Bettwäsche von <? echo $row['googlename']; ?> zu günstigen Preisen. Deine neue Bettwäsche von <? echo $row['googlename']; ?> wartet auf dich!'>
		<title><? echo $row['googlename']; ?> und viele andere Marken - finde deine neue Bettwäsche!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Marken, Designer, Trend, online">
		<?}elseif($_GET['page'] == 4){?>
		
		<meta name="description" content='Deine Suche nach Bettwäsche von <? echo $row['googlename']; ?> hat jetzt ein Ende - wir haben eine riesige Auswahl an schöner Markenbettwäsche für dich! Komm vorbei!'>
		<title>Bettwäsche von <? echo $row['googlename']; ?> online finden - auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Marken, Designer, Trend, online">
		<?}elseif($_GET['page'] == 5){?>
		
		<meta name="description" content='Deine neue Bettwäsche von <? echo $row['googlename']; ?> ist nur noch einen Klick entfernt! Wir haben tolle Angebote für Bettwäsche - <? echo $row['googlename']; ?> und mehr!'>
		<title>Preiswerte Bettwäsche von <? echo $row['googlename']; ?> auf bettwaesche123.de!</title>
		<meta name="keywords" content="Bettwäsche, <? echo $row['googlename']; ?>, Marken, Designer, Trend, online">
		<?}else{?>
		
		<meta name="description" content='Deine neue Bettwäsche von <? echo $row['googlename']; ?> ist nur noch einen Schritt entfernt! Wir haben tolle Bettwäsche zum Wohlfühlen - <? echo $row['googlename']; ?> und mehr!'>
		<title>Günstige Bettwäsche von <? echo $row['googlename']; ?> auf bettwaesche123.de!</title>
		<meta name="keywords" content="SBettwäsche, <? echo $row['googlename']; ?>, Marken, Designer, Trend, online">
		<?}?>	
	<?} // Ende ElseIF?>	
	<?} // Ende Pageresult?>
	<? /*
    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="/css/landing-page.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="/css/font-awesome-corp.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
	<!-- Loadbar -->
    <link href="/css/pace.min.css" rel="stylesheet">
	*/ ?>
	<!-- Scroll to top Button -->
	<!--<a class="scrollicon" title="zum Seitenanfang" href="#" style="display: inline;"><div>&Lambda;</div></a>-->
	<a class="scrollicon" title="zum Seitenanfang" href="#" style="display: inline;"><div><i class="fa fa-arrow-circle-up"></i></div></a>
	<? /*
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    */ ?>
	<!-- Favicon -->
	<link rel="/shortcut icon" type="image/x-icon" href="favicon.ico" />
	<link rel="/icon" type="image/x-icon" href="favicon.ico" />
</head>