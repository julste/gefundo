﻿<!-- Footer -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="list-inline footer-mittig">
					<? /*
					<li>
						<a href="/kontakt"  class="footer-link" title="Konktakt zu <?echo $websiteUrl;?>" >Kontakt</a>
					</li>

					<li class="footer-menu-divider">&sdot;</li>

					*/?>
					<li>
						<a href="/privacy-policy" class="footer-link"><? echo $languageArray["datenschutz"];?></a>
					</li>	
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/imprint" class="footer-link"><? echo $languageArray["Impressum"];?></a>
					</li>
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/sitemap" class="footer-link">Sitemap</a>
					</li>
				</ul>
				<p class="copyright text-muted small footer-mittig">Copyright &copy; <?echo $websiteUrl;?> <?php echo date("Y"); ?></p>
			</div>
		</div>
	</div>
		<a class="scrollicon" title="zum Seitenanfang" href="#" style="display: inline;">
		<div>
			<i class="fa fa-arrow-circle-up">
			</i>
		</div>
	</a>
</footer>

<!-- Bootstrap Core CSS -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom CSS --> 
<link href="/css/landing-page.css" rel="stylesheet" type="text/css">
<link href="/css/productView2.css" rel="stylesheet" type="text/css">
<link href="/css/tableView.css" rel="stylesheet" type="text/css">
<!-- <link href="/css/color.css" rel="stylesheet" type="text/css"> -->
<!-- Custom Fonts -->
<link href="/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- cookies -->
<link rel="stylesheet" href="/css/divascookies_style_dark_bottom.css" />
<link rel="stylesheet" type="text/css" media="screen" href="/css/prism.css"/>

<!-- Loadbar -->
<link href="/css/pace.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<? 
/*
<!-- Loadbar -->
<script src="/js/priceSlider.js" type="text/javascript"></script>
<script src="/js/default.js" type="text/javascript"></script>
<script src="/js/pace.min.js" type="text/javascript"></script>
<!-- Scroll to top Button -->
<script src="/js/scrolltotop.js" type="text/javascript"></script>
*/ ?> 


<script>
 $(function() {
   $('.redir-link[data-submit]').click(function (e) {
     e.preventDefault(); 
     var $this = $(this),
       $redirectForm = $('#redirform'),
       $redirectValue = $('#redirdata'),
       value = $this.data('submit');

     $redirectValue.val(value);
    $redirectForm.submit();
   });
 });
</script>



<script>
$('a.modalButton').on('click', function(e) {
	console.log("test");
    var src = $(this).attr('data-src');
    var height = $(this).attr('data-height') || 400;
    var width = $(this).attr('data-width') || 500;
    $("#myModal iframe").attr({'src':src});
});
function chkFormular() {
  if (document.Formular.q.value == "") {
	      document.Formular.q.focus();
    return false;
  }else{
	return true;  
  }
}
</script>



<script src="js/jquery.divascookies-0.6.min.js"></script>

<?
$bannerText = $languageArray["cookie_text"];
$moreInformation = $languageArray["mehr_informationen"];
?>

<script>
	var bannerTextAnzeige = "<?php echo $bannerText; ?>";
	var moreInformation = "<?php echo $moreInformation; ?>";
	
	$(document).ready(function() {
		$.DivasCookies({
			bannerText				: bannerTextAnzeige,		// text for the Divas Cookies banner
			cookiePolicyLink		: "privacy-policy",	// link to the extended cookie policy
			cookiePolicyLinkText	: moreInformation,			// text for the link to the extended cookie policy
			acceptButtonText		: "OK",						// text for the close button
			acceptButtonSrc			: "",						// source for the close button image
			openEffect				: "slideUp",				// opening effect for Divas Cookies banner ["fade", "slideUp", "slideDown", "slideLeft", "slideRight"]
			openEffectDuration		: 600,						// duration of the opening effect (msec)
			openEffectEasing		: "swing",					// easing for the opening effect
			closeEffect				: "slideDown",				// closing effect for Divas Cookies banner ["fade", "slideUp", "slideDown", "slideLeft", "slideRight"]
			closeEffectDuration		: 600,						// duration of the closing effect (msec)
			closeEffectEasing		: "swing",					// easing for the closing effect
			debugMode				: false,					// if true, the options are checked and warnings are shown
			saveUserPreferences		: true,						// if true, sets a cookie after the Divas Cookies is closed the first time and never shows it again
			cookieDuration			: 30,						// number of days after which the Divas Cookie technical cookie will expire (default 365 days)
			blockScripts			: false,					// set this to true if you blocked scripts by wrapping them with if($.DivasCookies.optedIn()){**script to be blocked**} (default false)
			pageReload				: false,					// if true reloads the actual page after opt-in to show the previuosly blocked scripts (default false)
			acceptOnScroll			: false,					// if true sets the Divas Cookie technical cookie on page scroll for cookies agreement (default false)
			acceptOnClick			: false,					// if true sets the Divas Cookie technical cookie on click on any <a> in the page except that on Divas Cookies banner for cookies agreement (default false)
			excludePolicyPage		: true						// if true excludes the cookie policy page from acceptOnScroll and acceptOnClick (default false)
		});
	});
</script>
<script src="js/prism.js"></script>
<script src="/js/scrolltotop.js"></script>
<!-- Piwik -->
<? echo $piwikScript; ?>
<!-- End Piwik Code -->