<?php
include("databasecredentials.php");
$url = substr($_SERVER[HTTP_HOST], 4);
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from website where websiteUrl = "'.$url.'"';
	$dbh->query("SET CHARACTER SET utf8");
	$rowWebsite = $dbh->query($sql)->fetch();
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}
// Website Credentials
$websiteId = $rowWebsite["id"];
$websiteUrl = $url;
$websiteName = $rowWebsite["websiteName"];
$keyWordSingular = $rowWebsite["keyWordSingular"];
$keyWordPlural = $rowWebsite["keyWordPlural"];
$metaKeywordsStartpage = $rowWebsite["metaKeywordsStartpage"];
$mailaddress = $rowWebsite["mailaddress"];
$searchField = $rowWebsite["searchField"];
$title = $rowWebsite["title"];
$position = $rowWebsite["position"];

// Piwik Credentials
$piwikScript = $rowWebsite["piwikScript"];
$piwikAnalyticsLink = $rowWebsite["piwikLink"];

// Amazon Credentials
$keyId = $rowWebsite["keyId"];
$secretKey = $rowWebsite["secretKey"];
$associateId = $rowWebsite["associateId"];
$productCategory = $rowWebsite["productCategory"];
$browseNode = $rowWebsite["browseNode"];
$amazonHost = $rowWebsite["amazonHost"];
$amazonRegion = $rowWebsite["amazonRegion"];

// Verification
$googleVerification = $rowWebsite["googleVerification"];
$bingVerification = $rowWebsite["bingVerification"];

// Country & Language
$language = $rowWebsite["language"];
$country = $rowWebsite["country"];

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from language';
	$dbh->query("SET CHARACTER SET utf8");
	$rowLanguage = $dbh->query($sql)->fetchAll();
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}

foreach($rowLanguage as $row){
	$languageArray[$row["keyword"]] = trim($row[$language]);
}	
?>