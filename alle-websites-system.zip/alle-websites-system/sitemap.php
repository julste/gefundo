<!DOCTYPE html>
<html lang="de">
<? include ("credentials.php");?>
<? $page="sitemap" ; ?>
<? include( "head.php"); ?>
        <body>
            <? include( "nav.php"); ?>
                <div style="padding-top: 50px; padding-bottom: 50px;">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 col-lg-12 col-md-12">
                                <h3>Sitemap</h3>
								<br>
								<h4><? echo $websiteName; ?></h4>
                               <ul>
							   <li><a href="/" ><? echo $languageArray['startseite'];?></a> </li> <br/> 
							   <li><a href="/privacy-policy" title="<? echo $languageArray['datenschutz'];?>"><? echo $languageArray["datenschutz"];?></a> </li>  <br/>
							   <li><a href="/imprint" title="<? echo $languageArray['Impressum'];?>"><? echo $languageArray["Impressum"];?></a> </li> <br/>
							   <li><a href="/sitemap" title="Sitemap">Sitemap</a> </li> <br/>
							      <?
								  $url = substr($_SERVER[HTTP_HOST], 4);

							    try {
									$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
									$dbh->query("SET CHARACTER SET utf8");
									$sql = 'SELECT * from page p, website w where p.status = 1 and p.websiteId = w.id and w.websiteUrl = "'.$url.'"';
									foreach($dbh->query($sql) as $rowPage){
									 echo "<li><a href='/".$rowPage['slug']."' title='".$rowPage['googlename']."'>".$rowPage['googlename']."</a> </li> <br/>";
									}
							
									$dbh = null;
								} catch (PDOException $e) {
								   print "Error!: " . $e->getMessage() . "<br/>";
								   die();
								}
							   ?>
							   </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <? include( "footer.php"); ?>
        </body>

</html>