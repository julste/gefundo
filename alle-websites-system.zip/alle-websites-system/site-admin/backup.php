<?
include ("../databasecredentials.php");

$dbhost = $hostName;
$dbuser = $dbUserName;
$dbpassword = $dbPassword;
$dbname = $dbName;
$dumpfile = $dbname . '_' . date("Y-m-d_H-i-s") . '.sql.gz';
 
echo "Start dump\n";
// aktuelles Verzeichnis
echo getcwd() . "\n";

chdir('backup');

// aktuelles Verzeichnis
echo getcwd() . "\n";
#mysqldump --user=k6234_gefundo --password=Emxx75*6 --host=10.35.249.143 k62346_database | gzip -c  > $dumpfile

$command = "mysqldump -u $dbuser -p $dbpwd $dbname > $filename";

$status = shell_exec($command);


echo "-- Dump completed -- ";
echo $status;

?>