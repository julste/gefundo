<?
if($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (isset($_POST['add-keyword'])) {
		try {
			$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
			$stmt = $dbh->prepare("INSERT INTO language (keyword) VALUES (:keyword)");
			$stmt->bindParam(':keyword', utf8_decode(trim($_POST["keyword"])));
			$stmt->execute();
			$dbh = null;
			} catch (PDOException $e) {
				print "Error: " . $e->getMessage() . "<br/>";
				die();
			}
	}
	
	if (isset($_POST['save'])) {
		
		try {
		$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
		
		
		foreach($_POST as $key => $value){
			$stringPost = explode("-!",$key);
			$keyword = trim($stringPost[0]);
			$row = trim($stringPost[1]);
			$sql = 'UPDATE language SET
					'.$row.' = :value
					WHERE keyword = "'.$keyword.'"';
					
			$statement = $dbh->prepare($sql);
			$statement->bindParam(':value', utf8_decode($value), PDO::PARAM_STR);
			$statement->execute();
			
		}
		$dbh = null;
		} catch (PDOException $e) {
			print "Error: " . $e->getMessage() . "<br/>";
			die();
		}

	}



?>
<script>
	alert("Informationen wurden erfolgreich gepeichert!");
</script>
<?
	}
?>