<?
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from language';
	$dbh->query("SET CHARACTER SET utf8");
	$rowLanguage = $dbh->query($sql)->fetchAll();
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}
?>