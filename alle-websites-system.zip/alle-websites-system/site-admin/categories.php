<?php require "login/loginheader.php"; ?>
<? include ("../databasecredentials.php");?>
<? include("helper/slug.php"); ?>

<? include("content/saveValues.php"); ?>
<? include("content/getValues.php"); ?>

<? $page = "categories"; ?>
<!DOCTYPE html>
<html lang="en">
 <? include("viewparts/head.php"); ?> 
  <body>
   <div class="container">
   <? include("viewparts/header.php"); ?>
	<div class="row">
		<div class="col-md-12">
			<!-- Nav tabs -->
			<div class="card">

			<? include("viewparts/nav-tab.php"); ?>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="colors">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<p class="lead ueberschrift">Categories</p>
							<div class="form-group">
								<div class="col-sm-12">
									<script>
$.ajaxSetup({
    scriptCharset: "utf-8", //or "ISO-8859-1"
    contentType: "application/json; charset=utf-8"
});

$.getJSON('https://whateverorigin.org/get?url=' + 
    encodeURIComponent('https://google.com') + '&callback=?',
    function (data) {
        console.log("> ", data);

        //If the expected response is text/plain
        $("#viewer").html(data.contents);

        //If the expected response is JSON

});
    </script>								

									Coming soon :)	
								</div>
							</div>	
						</form>
																		
					</div>
				</div>
			</div>
        </div>
	</div>
   </div><!-- /container -->
  </body>
</html>
