<ul class="nav nav-tabs">
	<li class="<?if($page =="index"){ echo "active";}?>"><a href="index.php">Allgemein</a></li>
	<li class="<?if($page =="images"){ echo "active";}?>"><a href="images.php">Bilder</a></li>
	<li class="<?if($page =="content"){ echo "active";}?>"><a href="content.php">Content</a></li>
	<li class="<?if($page =="links"){ echo "active";}?>"><a href="links.php">Links</a></li>
	<li class="<?if($page =="synonyms"){ echo "active";}?>"><a href="synonyms.php">Synonyme</a></li>
	<li class="<?if($page =="categories"){ echo "active";}?>"><a href="categories.php">Categories</a></li>
	<li class="<?if($page =="colors"){ echo "active";}?>"><a href="colors.php">Farben</a></li>
	<li class="<?if($page =="websites"){ echo "active";}?>"><a href="websites.php">Websites</a></li>
	<li class="<?if($page =="language"){ echo "active";}?>"><a href="language.php">Language</a></li>
</ul>