<div class="row header-bottom">
	<div class="col-md-9">
		<a href="https://www.<? echo substr($_SERVER[HTTP_HOST], 4);?>" target="_blank"><? echo substr($_SERVER[HTTP_HOST], 4);?></a>
	</div>
	<div class="col-md-3 text-right">
		<a href="login/logout.php">Logout</a>
	</div>
</div>