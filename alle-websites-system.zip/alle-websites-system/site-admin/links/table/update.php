<?php
include ("../../../databasecredentials.php");
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	if(isset($_POST["id"]))
	{
	$sql = "UPDATE page SET ".$_POST["column_name"]."='".utf8_decode ($_POST["value"])."' WHERE id = '".$_POST["id"]."'";
	$result = $dbh->prepare($sql); 
	$result->execute(); 
	}

	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}



?>