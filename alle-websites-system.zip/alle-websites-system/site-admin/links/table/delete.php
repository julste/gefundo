<?php
include ("../../../databasecredentials.php");

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$dbh->query("SET CHARACTER SET utf8");
	
	

		if(isset($_POST["id"]))
		{
		
		$sql = 'DELETE From page where id = '.$_POST["id"].'';
		$result = $dbh->prepare($sql); 
		$result->execute(); 
		}
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}
?>