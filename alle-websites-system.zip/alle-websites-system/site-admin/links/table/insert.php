<?php
include ("../../../databasecredentials.php");
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$url = substr($_SERVER[HTTP_HOST], 4);
	$sql = 'SELECT * from website where websiteUrl = "'.$url.'"';
	$dbh->query("SET CHARACTER SET utf8");
	$rowWebsite = $dbh->query($sql)->fetch();
	
	if(isset($_POST["amazonName"], $_POST["googleName"], $_POST["slug"],  $_POST["startpage"]))
	{

	
	$stmt = $dbh->prepare("INSERT INTO page (amazonName, googleName, slug, status, startpage, websiteId) VALUES (:amazonName, :googleName, :slug, :status, :startpage, :websiteId)");
	$stmt->bindParam(':amazonName', $_POST["amazonName"]);
	$stmt->bindParam(':googleName', $_POST["googleName"]);
	$stmt->bindParam(':slug', $_POST["slug"]);
	$stmt->bindParam(':status', $_POST["status"]);
	$stmt->bindParam(':startpage', $_POST["startpage"]);
	$stmt->bindParam(':websiteId', $rowWebsite["id"]);
	$stmt->execute();
	}
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}



?>