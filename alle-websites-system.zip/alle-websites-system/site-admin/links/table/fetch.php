<?php
include ("../../../databasecredentials.php");
$url = substr($_SERVER[HTTP_HOST], 4);
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$dbh->query("SET CHARACTER SET utf8");
	$sql = 'SELECT p.id, p.amazonname, p.googlename, p.slug, p.status, p.startpage from page p, website w where p.websiteId = w.id and w.websiteUrl = "'.$url.'"';	
	
	
	if(isset($_POST["search"]["value"]))
	{
	 $sql .= '
	 and (p.amazonname LIKE "%'.$_POST["search"]["value"].'%" 
	 OR p.googlename LIKE "%'.$_POST["search"]["value"].'%"
	 OR p.status LIKE "%'.$_POST["search"]["value"].'%"
	 OR p.slug LIKE "%'.$_POST["search"]["value"].'%" 
	 OR p.startpage LIKE "%'.$_POST["search"]["value"].'%")';
	}
	
	/*
	if(isset($_POST["order"]))
	{
	 $sql .= 'ORDER BY '.$columns[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].'';
	}
	else
	{
	 $sql .= 'ORDER BY id DESC ';
	}
	*/
	$data = array();
	
	if($_POST["length"] != -1)
	{
		$sql .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
	}
	
	$rowText = $dbh->query($sql)->fetchall();
	
	foreach($rowText as $rowPage){	
		$sub_array = array();
		$sub_array[] = '<div contenteditable class="update" data-id="'.$rowPage["id"].'" data-column="amazonname">' . $rowPage["amazonname"] . '</div>';
		$sub_array[] = '<div contenteditable class="update" data-id="'.$rowPage["id"].'" data-column="googlename">' . $rowPage["googlename"] . '</div>';
		$sub_array[] = '<div contenteditable class="update" data-id="'.$rowPage["id"].'" data-column="slug">' . $rowPage["slug"] . '</div>';
		$sub_array[] = '<div contenteditable class="update" data-id="'.$rowPage["id"].'" data-column="status">' . $rowPage["status"] . '</div>';
		$sub_array[] = '<div contenteditable class="update" data-id="'.$rowPage["id"].'" data-column="startpage">' . $rowPage["startpage"] . '</div>';
		$sub_array[] = '<button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'.$rowPage["id"].'">Delete</button>';
		$data[] = $sub_array;	
	}
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}

$sql = 'SELECT count(*) from page p, website w where p.websiteId = w.id and w.websiteUrl = "'.$url.'"
		and (amazonname LIKE "%'.$_POST["search"]["value"].'%" 
		OR googlename LIKE "%'.$_POST["search"]["value"].'%" 
		OR slug LIKE "%'.$_POST["search"]["value"].'%" 
		OR status LIKE "%'.$_POST["search"]["value"].'%"
		OR startpage LIKE "%'.$_POST["search"]["value"].'%")';
		
$result = $dbh->prepare($sql); 
$result->execute(); 
$number_of_filtered_rows = $result->fetchColumn(); 

$sql = 'SELECT count(*) from page p, website w where p.websiteId = w.id and w.websiteUrl = "'.$url.'"';	
$result = $dbh->prepare($sql); 
$result->execute(); 
$number_of_rows = $result->fetchColumn(); 

$sub_array = array();
$output = array(
 "draw"    => intval($_POST["draw"]),
 "recordsTotal"  =>  $number_of_rows,
 "recordsFiltered" => $number_of_filtered_rows,
 "data"    => $data
);
echo json_encode($output);



?>
