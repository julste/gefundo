<?
$url = substr($_SERVER[HTTP_HOST], 4);

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT p.amazonname as amazonname, p.id as id from page p, website w where p.websiteId = w.id and p.status = 0 and w.websiteUrl = "'.$url.'"  LIMIT 1';
	$dbh->query("SET CHARACTER SET utf8");
  $stmt = $dbh->prepare($sql);
  $stmt->execute();
  $checkRow = $stmt->fetch();
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}

?>
