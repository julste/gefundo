<?
require "../login/loginheader.php";
include ("../../databasecredentials.php");
include ("../../credentials.php");

$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	
if (isset($_POST['id']) and isset($_POST['status'])){
  $sql = "UPDATE page SET status ='".$_POST["status"]."' WHERE id = '".$_POST["id"]."'";
	$result = $dbh->prepare($sql); 
	$result->execute(); 
}


?>