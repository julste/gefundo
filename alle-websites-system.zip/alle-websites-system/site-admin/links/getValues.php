<?
$url = substr($_SERVER[HTTP_HOST], 4);

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from page p, website w where p.websiteId = w.id and w.websiteUrl = "'.$url.'"';
	$dbh->query("SET CHARACTER SET utf8");
	$rowText = $dbh->query($sql)->fetchall();
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}
?>
