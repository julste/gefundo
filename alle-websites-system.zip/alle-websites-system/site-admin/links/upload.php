<?php
$url = substr($_SERVER[HTTP_HOST], 4);

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
	
try {
	$tmpName = $_FILES['file']['tmp_name'];
	$csvAsArray = array_map('str_getcsv', file($tmpName));
	



	//print_r($csvAsArray);
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	
	$sql = 'SELECT * from website where websiteUrl = "'.$url.'"';
	$dbh->query("SET CHARACTER SET utf8");
	$rowWebsite = $dbh->query($sql)->fetch();

	
	$stmt = $dbh->prepare("INSERT INTO page (googlename, amazonname, slug, startpage, websiteId) VALUES (?, ?, ?, ?, ?)");
	
	$stmt->bindParam(1, $googlename);
	$stmt->bindParam(2, $amazonname);
	$stmt->bindParam(3, $slug);
	$stmt->bindParam(4, $startpage);
	$stmt->bindParam(5, $websiteId);

	foreach($csvAsArray as $item){
		$slug = sanitizeStringForUrl(trim($item[1]));
		$amazonname = utf8_encode(ucwords(trim($item[0])));
		//echo $amazonname. "<br>";
		$googlename = utf8_encode(ucwords(trim($item[1])));
		$websiteId = $rowWebsite["id"];
		$startpage = 0;
		$test = $stmt->execute();

	}
	
	// Doppelte Einträge löschen
	$dbh->query('delete T1
		     from page T1, page T2
		     where T1.googlename = T2.googlename
		     and T1.websiteId = "'.$rowWebsite["id"].'"
	             and T2.websiteId = "'.$rowWebsite["id"].'"
		     and T1.id > T2.id');								

} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}


}



?>