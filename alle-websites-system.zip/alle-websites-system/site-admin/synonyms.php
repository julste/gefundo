<?php require "login/loginheader.php"; ?>
<? include ("../databasecredentials.php");?>
<? include("helper/slug.php"); ?>
<? include("index/getValues.php"); ?>

<? $page = "synonyms"; ?>
<!DOCTYPE html>
<html lang="en">
 <? include("viewparts/head.php"); ?> 
  <body>
   <div class="container">
   <? include("viewparts/header.php"); ?>
	<div class="row">
		<div class="col-md-12">
			<!-- Nav tabs -->
			<div class="card">
			<? include("viewparts/nav-tab.php"); ?>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="synonyms">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<p class="lead ueberschrift">Synonyms (<? echo $rowWebsite["language"];?>)</p>
							<div class="form-group">
								<div class="col-sm-8">
									<input type="text" class="form-control" id="filter" name="filter" placeholder="Filter" value="">
								</div>	
								<div class="col-sm-2 pull-right">
									<button type="button" name="deleteSynonym" id="deleteSynonym" class="btn btn-primary btn-xl pull-right">delete synonym</button>
								</div>	
								<div class="col-sm-2 pull-right">
									<button type="button" name="addSynonym" id="addSynonym" class="btn btn-primary btn-xl pull-right">add new synonym</button>
								</div>				
							</div>
							<div class="form-group">
								<div class="col-sm-12">							
								<div id="example-table"></div>
								</div>
							</div>	
						</form>						
					</div>
				</div>
			</div>
        </div>
	</div>
	</div><!-- /container -->
</body>

<script> 

//Trigger setFilter function with correct parameters
function updateFilter(){
	table.setFilter([[
    {field:"synonym", type:"like", value:$("#filter").val()},
    {field:"word", type:"like", value:$("#filter").val()}, 
	]]);
}

//Update filters on value change
$("#filter").change(updateFilter);
$("#filter").keyup(updateFilter);

// wordEditor
var wordEditor = function(cell, onRendered, success, cancel){
	
	var cellValue = cell.getValue();
	var input = document.createElement("input");
	input.setAttribute("type", "text");
	input.style.padding = "0px";
    input.style.width = "100%";
	input.style.height = "100%";
	input.value = cellValue;

	onRendered(function(){
        input.focus();
    });
	
	function onChange(){	
		if(input.value != cellValue){
			row = cell.getRow();
			id = row.getData()["id"];
			success(input.value);
			    $.ajax({
				 cache:false,
				 url:"/site-admin/synonyms/updateWord.php",
				 method:"POST",
				 data:{"word":input.value,"id":id}
				})
        }else{
            cancel();
        }
    }
	
	//submit new value on blur or change
	input.addEventListener("change", onChange);
	
	//submit new value on enter
	input.addEventListener("keydown", function(e){
		if(e.keyCode == 13){
			onChange();
		}

		if(e.keyCode == 27){
			cancel();
		 }
	})
	return input;
}


// synonymEditor
var synonymEditor = function(cell, onRendered, success, cancel){

	var cellValue = cell.getValue();
	var input = document.createElement("input");
	input.setAttribute("type", "text");
	input.style.padding = "0px";
    input.style.width = "100%";
	input.style.height = "100%";
	input.value = cellValue;

	onRendered(function(){
        input.focus();
    });
	
	function onChange(){	
		if(input.value != cellValue){
			row = cell.getRow();
			id = row.getData()["id"];
			success(input.value);
			    $.ajax({
					cache:false,
				 url:"/site-admin/synonyms/updateSynonym.php",
				 method:"POST",
				 data:{"synonym":input.value,"id":id}
				});			
        }else{
            cancel();
        }
    }
	
	//submit new value on blur or change
	input.addEventListener("change", onChange);
	
	//submit new value on enter
	input.addEventListener("keydown", function(e){
		if(e.keyCode == 13){
			onChange();
		}
		if(e.keyCode == 27){
				cancel();
		 }
	})
	return input;
}


//Build Tabulator
var table = new Tabulator("#example-table", {
	selectable:1,
    height:"500px",	
    layout:"fitColumns",
    columns:[
	    {title:"Id", field:"id", sorter:"string", width:20},
        {title:"Word", field:"word", sorter:"string", width:300, editor:wordEditor},
        {title:"Synonym", field:"synonym", sorter:"string", editor:synonymEditor},
    ],
});

// get Data
table.setData("/site-admin/synonyms/getData.php");

//Add row on "Add Row" button click
$("#addSynonym").click(function(){
	var results = table.getCalcResults();
	$.ajax({
		cache:false,
		url:"/site-admin/synonyms/insertData.php",
		success:function(data){
			table.addRow({id:data, word:"", synonym:""},true);
		}	
	});
});

//Delete row on "delete Row" button click
$("#deleteSynonym").click(function(){
	var selectedData = table.getSelectedData();
	if (confirm('Are you sure?')) {			
		var results = table.getCalcResults();
		$.ajax({
			cache:false,
			method:"POST",
			data:{"id":selectedData[0].id},
			url:"/site-admin/synonyms/deleteData.php",
			success:function(data){
				table.deleteRow(selectedData[0].id);	
			}	
		});
	} 
});	


</script>
</html>
