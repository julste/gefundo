<?php require "login/loginheader.php"; ?>
<? include ("../databasecredentials.php");?>

<? include("websites/saveValues.php"); ?>
<? include("websites/getValues.php"); ?>

<? $page = "websites"; ?>
<!DOCTYPE html>
<html lang="en">
 <? include("viewparts/head.php"); ?> 
  <body>
   <div class="container">
   <? include("viewparts/header.php"); ?>
	<div class="row">
		<div class="col-md-12">
			<!-- Nav tabs -->
			<div class="card">

			<? include("viewparts/nav-tab.php"); ?>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="websites">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<p class="lead ueberschrift">Websites</p>
							<div class="form-group">
							
								<div class="col-sm-12 text-right">
									<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal">New Website</button>
								</div>
								<div class="col-sm-12">							
									<table class="table">
									  <thead>
										<tr>
										  <th scope="col">Nr.</th>
										  <th scope="col">Website</th>
										  <th scope="col">Backend</th>
										  <th scope="col">GoogleMail</th>
										  <th scope="col">Google</th>
										  <th scope="col">Bing</th>
										  <th scope="col">Category</th>
										  <th scope="col">Links</th>
										  <th scope="col">Language</th>
										  <th scope="col">Start Links</th>
										  <th scope="col">Status</th>
										</tr>
									  </thead>
									  <tbody>
									  <? 
											$nr = 0;
											foreach($rowWebsite as $website){ 
											$nr++;
											?>
										<tr>
										
										  <td><? echo $nr; ?></td>
										  <td><a href="https://www.<? echo $website["websiteUrl"]; ?>" target="_blank"><? echo $website["websiteUrl"]; ?></a></td>
										  <td><a href="https://www.<? echo $website["websiteUrl"]. "/site-admin"; ?>" target="_blank">Admin</a></td>
										  <td><? echo $website["googlemail"]; ?></td>
										  <td><? if($website["googleVerification"] == "") {echo "no";} else{echo "yes";} ?></td>
										  <td><? if($website["bingVerification"] == "") {echo "no";} else{echo "yes";} ?></td>
										  <td><? echo $website["productCategory"]; ?></td>
											<?
											try {
												$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
												$sql = 'SELECT count(*) from page where status = 1 and websiteId='.$website["id"];
												$dbh->query("SET CHARACTER SET utf8");
												$allLinks = $dbh->query($sql)->fetch();
												$dbh = null;
												} catch (PDOException $e) {
													print "Error: " . $e->getMessage() . "<br/>";
													die();
												}
											?>									  
										  <td><? echo $allLinks[0]; ?></td>
										  <td><? echo $website["language"]; ?></td>
										  											<?
											try {
												$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
												$sql = 'SELECT c.text from content c where websiteId='.$website["id"];
												$dbh->query("SET CHARACTER SET utf8");
												$allContent = $dbh->query($sql)->fetchAll();
												$dbh = null;
												} catch (PDOException $e) {
													print "Error: " . $e->getMessage() . "<br/>";
													die();
												}
												
											$linksInContent = 0;											
											foreach($allContent as $content){ 
													$c = substr_count($content[0], "href");
													$linksInContent = $linksInContent + $c;
											}							
											?>	
										  <td><? echo $linksInContent; ?></td>
										  <td>
											<? if ($website["googleVerification"] == ""
											   or $website["bingVerification"] == ""
										       or $allLinks[0] < 500
											   or $linksInContent < 3){
											?>
												<button type="button"class="btn btn-danger btn-sm" disabled></button>
											 <?}else{?>
											 	<button type="button"class="btn btn-success btn-sm" disabled></button>
											 <?}?>
										  </td>
										  
										</tr>
									  <?}?>
									  </tbody>
									</table>		
								</div>
							</div>	
						</form>
						<!-- Modal -->
						<div id="myModal" class="modal fade" role="dialog">
						  <div class="modal-dialog">

							<!-- Modal content-->
							<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Add new Website</h4>
							  </div>
							  <div class="modal-body">
								<div class="container-fluid" style="padding:10px;">	
									<form action="" method="POST">
								  <div class="form-group">
									<label for="websiteUrl">Website Url Short</label>
									<input type="input" class="form-control" id="websiteUrl" name="websiteUrl">
								  </div>
								  <div class="form-group">
									<label for="googlemail">Google E-Mail Address</label>
									<input type="input" class="form-control" id="googlemail" name="googlemail">
								  </div>
								  <button type="submit" class="btn btn-primary pull-right" id="add-website">Add</button>
								</form>
															</div>
							  </div>
							
							</div>

						  </div>
						</div>												
					</div>
				</div>
			</div>
        </div>
	</div>
   </div><!-- /container -->
  </body>
</html>
