<?php

include("../../databasecredentials.php");
include("../index/getValues.php");


try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$stmt = $dbh->prepare("INSERT INTO synonyme (word, synonym, language) VALUES ('','','".$rowWebsite["language"]."')");
	$stmt->execute();
	$id = $dbh->lastInsertId();
	$dbh = null;

	} catch (PDOException $e) {
		print "Error: " . $e->getMessage() . "<br/>";
		die();
	}
	echo $id;
?>
