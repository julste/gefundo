<?php

include ("../../databasecredentials.php");

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$stmt = $dbh->prepare("UPDATE synonyme set word='".utf8_decode(trim($_POST["word"]))."' where id='".$_POST["id"]."'"); 
	$stmt->execute(); 
	$dbh = null;

	} catch (PDOException $e) {
		print "Error: " . $e->getMessage() . "<br/>";
		die();
	}
?>
