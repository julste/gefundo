<? 
include ("../../databasecredentials.php");
include("../index/getValues.php");

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	
	$sql_delete = 'DELETE FROM synonyme WHERE word="" AND synonym=""';
	$result = $dbh->prepare($sql_delete); 
	$result->execute(); 
	
	$sql = 'SELECT * FROM synonyme WHERE language = "'.$rowWebsite["language"].'"';
	$dbh->query("SET CHARACTER SET utf8");
	$row = $dbh->query($sql)->fetchall();
	
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}

$data = array();

foreach($row as $rowData){
	$d = array();
	$d["id"] = (int)$rowData["id"];
	$d["word"] = $rowData["word"];
	$d["synonym"] = $rowData["synonym"];
	array_push($data, $d);
}

//return JSON formatted data
echo(json_encode($data));
 
?>