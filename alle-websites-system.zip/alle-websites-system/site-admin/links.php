<?php require "login/loginheader.php"; ?>
<? $page = "links"; ?>
<? include ("../databasecredentials.php");?>
<? include ("../credentials.php");?>
<? include("helper/slug.php");?>
<? include("links/upload.php");?>
<? include("links/getValues.php"); ?>

<!DOCTYPE html>
<html lang="en">
 <? include("viewparts/head.php"); ?>

 <body>
   <div class="container">
   <? include("viewparts/header.php"); ?>
	<div class="row">
		<div class="col-md-12">
			<!-- Nav tabs -->
			<div class="card">

			<? include("viewparts/nav-tab.php"); ?>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="links">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<p class="lead ueberschrift">Links</p>
							<div class="form-group">
								<div class="col-sm-4">
									<div>
										<input type="file"  name="file" id="file" class="file">
										<div class="input-group">
											<input type="text" class="form-control input-xl" disabled placeholder=" CSV Datei hochladen">
											<span class="input-group-btn">
												<button class="browse btn btn-primary input-xl" type="button"> Browse</button>
											</span>
										</div>
									</div>
								</div>
								<div class="col-sm-2">
									<input type="submit"  class="btn btn-primary btn-xl" value="Upload CSV File" name="submit">
								</div>
								<div class="col-sm-2">
									<button type="button" name="add" id="add" class="btn btn-primary btn-xl">Add new Link</button>
								</div>
                <div class="col-sm-2">
                  <!-- Button trigger modal -->
									<button type="button" name="startLinkCheck" id="startLinkCheck" class="btn btn-primary btn-xl" data-toggle="modal" data-target="#modalChecker">Start Link Check</button>
								</div>
							</div>
						</form>
						<hr>
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<div class="form-group form-group-sm">
								<div class="col-sm-12">
								<table id="linkdata" class="table table-striped table-bordered" cellspacing="0" width="100%">
									<thead>
										<th>AmazonName</th>
										<th>GoogleName</th>
										<th>Slug</th>
										<th>Status</th>
										<th>Startpage</th>
										<th>Action</th>
										</tr>
									</thead>
								</table>
								 </div>
							</div>
						</form>
					</div>
				</div>
			</div>
        </div>
	</div>
</div><!-- /container -->

<!-- Modal -->
<div class="modal fade" id="modalChecker" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-big">
        <div class="modal-content modal-content-big">
         	<div class="container-fluid" style="padding:10px;">
                <div class="row">
                  <div class="col-md-1">
                      <button class="btn btn-danger" style="width:100%; min-height:1455px" id="linkCheckFalse" name="linkCheckFalse"></button>
                  </div>
                  <div class="col-md-10" id="linkCheckerContent" name="linkCheckerContent">
                  </div>
                  <div class="col-md-1">
                      <button class="btn btn-success" style="width:100%; min-height:1455px" id="linkCheckTrue" name="linkCheckTrue"></button>
                  </div>
        				</div> <!-- Modal - Row Ende -->
          </div> <!-- Modal - Container Ende -->
        <div class="modal-footer">
        </div>

        </div>
    </div>
</div>


  </body>
</html>
