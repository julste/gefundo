<?php require "login/loginheader.php"; ?>
<? include ("../databasecredentials.php");?>
<? include("helper/slug.php"); ?>

<? include("content/saveValues.php"); ?>
<? include("content/getValues.php"); ?>

<? $page = "content"; ?>
<!DOCTYPE html>
<html lang="en">
 <? include("viewparts/head.php"); ?>
	<script src="https://cdn.ckeditor.com/4.11.1/full-all/ckeditor.js"></script>
  <body>
   <div class="container">
   <? include("viewparts/header.php"); ?>
	<div class="row">
		<div class="col-md-12">
			<!-- Nav tabs -->
			<div class="card">

			<? include("viewparts/nav-tab.php"); ?>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="content">					
						<form class="form-horizontal" action="" method="POST">
						
						
						<?
						 $textCounter = 0;
						 foreach($rowText  as $rowPage){?>
							<input type="hidden" name="id-<? echo $textCounter; ?>" value="<? echo $rowText[$textCounter]["id"];?>">
							<p class="lead ueberschrift">Text <? echo $textCounter + 1; ?>
							</p>

							<div class="form-group">
								<label for="heading-<? echo $textCounter; ?>" class="col-sm-1 control-label">Heading</label>
								<div class="col-sm-11">
									<input type="text" class="form-control" id="heading-<? echo $textCounter; ?>" name="heading-<? echo $textCounter; ?>" placeholder="" value="<? echo $rowText[$textCounter]["heading"];?>">
								</div>
							</div>
							<div class="form-group">
							<label for="text-<? echo $textCounter; ?>" class="col-sm-1 control-label">Text</label>
								<div class="col-sm-11">
										<textarea rows="10" id="text-<? echo $textCounter; ?>" name="text-<? echo $textCounter; ?>"><? echo $rowText[$textCounter]["text"];?></textarea>	
								</div>
									<script>
										CKEDITOR.replace( 'text-<? echo $textCounter; ?>' );
									</script>			
							</div>
						<?
						 $textCounter++;
						}
						?>
						<?
						$textlimit = $textCounter + 4;

						for ($i = $textCounter; $i <= $textlimit; $i++) {?>
							<input type="hidden" name="id-<? echo $i; ?>" value="">
							<p class="lead ueberschrift">Text <? echo $i + 1; ?></p>
							<div class="form-group">
								<label for="heading-<? echo $i; ?>" class="col-sm-1 control-label">Heading</label>
								<div class="col-sm-11">
									<input type="text" class="form-control" id="heading-<? echo $i; ?>" name="heading-<? echo $i; ?>" placeholder=""  value="">
								</div>
							</div>
							<div class="form-group">
							<label for="text2" class="col-sm-1 control-label">Text</label>
								<div class="col-sm-11">
									<textarea rows="10" id="text-<? echo $i; ?>" name="text-<? echo $i; ?>"></textarea>	
								</div>
								
								<script>
										CKEDITOR.replace( 'text-<? echo $i; ?>' );

								</script>	
								
							</div>
						<?}?>
							<!-- Speicher Button -->
							<div class="form-group">
								<div class="col-sm-12">
									<button type="submit" class="pull-right btn btn-primary btn-xl">Speichern</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
        </div>
	</div>
   </div><!-- /container -->
  </body>
</html>
