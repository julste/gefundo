<?
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from website';
	$dbh->query("SET CHARACTER SET utf8");
	$rowWebsite = $dbh->query($sql)->fetchAll();
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}
?>