<?
if($_SERVER['REQUEST_METHOD'] === 'POST') {
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$stmt = $dbh->prepare("INSERT INTO website (websiteUrl, googlemail) VALUES (:websiteUrl, :googlemail)");
	$stmt->bindParam(':websiteUrl', utf8_decode($_POST["websiteUrl"]));
	$stmt->bindParam(':googlemail', utf8_decode($_POST["googlemail"]));
	$stmt->execute();
	$dbh = null;

	} catch (PDOException $e) {
		print "Error: " . $e->getMessage() . "<br/>";
		die();
	}

?>
<script>
alert("Informationen wurden erfolgreich gepeichert!");
</script>
<?
	}
?>
