<?
/**
* Modifies a string to remove all non ASCII characters and spaces.
*/
function sanitizeStringForUrl($string){
    $string = strtolower($string);
    $string = html_entity_decode($string);
    $string = str_replace(array('�','�','�','�'),array('ae','ue','oe','ss'),$string);
    $string = preg_replace('#[^\w\s����]#',null,$string);
    $string = preg_replace('#[\s]{2,}#',' ',$string);
    $string = str_replace(array(' '),array('-'),$string);
    return $string;
}

?>
