<?php require "login/loginheader.php"; ?>
<? $page = "images"; ?>
<? include ("../databasecredentials.php");?>
<? include("images/upload.php");?>
<? include("images/getValues.php"); ?>
<!DOCTYPE html>
<html lang="en">
<? include("viewparts/head.php"); ?>
  <body>
   <div class="container">
   <? include("viewparts/header.php"); ?>
	<div class="row">
		<div class="col-md-12">
			<!-- Nav tabs -->
			<div class="card">
			<? include("viewparts/nav-tab.php"); ?>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="images">
					
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<p class="lead ueberschrift">Hintergrundbild</p>
								<div class="form-group">
									<div class="col-sm-6">
										<div>
											<input type="file"  name="fileToUpload" id="fileToUpload" class="file">
											<div class="input-group">
												<input type="text" class="form-control input-xl" disabled placeholder="Upload Image">
												<span class="input-group-btn">
													<button class="browse btn btn-primary input-xl" type="button"> Browse</button>
												</span>
											</div>
										</div>
										<div class="pull-right" style="margin-top:15px;">
											<input type="hidden" name="identifier" id="identifier" value="backgroundImage">
											<input type="submit" class="btn btn-primary btn-xl" value="Upload Image" name="submit">
										</div>	
									 </div>		
									 <div class="col-sm-6">
									  <? if(isset($backgroundImage["path"])){ ?>
										<img src="../img/<? if(isset($backgroundImage["path"])){ echo $backgroundImage["path"];}?>" class="img-thumbnail">
										 <?}?>
									 </div>
								</div>
						</form>
<!--
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<p class="lead ueberschrift">Impressum / Datenschutz</p>
								<div class="form-group form-group-sm">
									<div class="col-sm-6">
										<div>
											<input type="file"  name="fileToUpload" id="fileToUpload" class="file">
											<div class="input-group">
												<input type="text" class="form-control input-xl" disabled placeholder="Upload Image">
												<span class="input-group-btn">
													<button class="browse btn btn-primary input-xl" type="button"> Browse</button>
												</span>
											</div>
										</div>
										<div class="pull-right" style="margin-top:15px;">
											<input type="hidden" name="identifier" id="identifier" value="imprintImage">
											<input type="submit" class="btn btn-primary btn-xl" value="Upload Image" name="submit">
										</div>	
									 </div>		
									 <div class="col-sm-6">
									 <?// if(isset($imprintImage["path"])){?>
										<img src="../img/<? //if(isset($imprintImage["path"])){ echo $imprintImage["path"];}?>" class="img-thumbnail">
									 <?//}?>	
									 </div>									 
								</div>
						</form>			
-->						
					</div>
				</div>
			</div>
        </div>
	</div>
</div><!-- /container -->
  </body>
</html>
