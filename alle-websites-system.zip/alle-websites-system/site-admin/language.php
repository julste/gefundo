<?php require "login/loginheader.php"; ?>
<? include ("../databasecredentials.php");?>
<? include("helper/slug.php"); ?>

<? include("language/saveValues.php"); ?>
<? include("language/getValues.php"); ?>

<? $page = "language"; ?>
<!DOCTYPE html>
<html lang="en">
 <? include("viewparts/head.php"); ?> 
  <body>
   <div class="container">
   <? include("viewparts/header.php"); ?>
	<div class="row">
		<div class="col-md-12">
			<!-- Nav tabs -->
			<div class="card">

			<? include("viewparts/nav-tab.php"); ?>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="colors">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<p class="lead ueberschrift">Language</p>
							<div class="form-group">
								<div class="col-sm-12">
								<div class="text-right">
									<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal">New Translation</button>
								</div>
									<table class="table">
									  <thead>
										<tr>
										  <th scope="col">Keyword</th>
										  <th scope="col">Deutsch</th>
										  <th scope="col">Englisch</th>
										  <th scope="col">Französisch</th>
										  <th scope="col">Spanisch</th>
										</tr>
									  </thead>
									  <tbody>
										<? foreach($rowLanguage as $language){ ?>
										<tr>
										  <td><? echo $language["keyword"]; ?></td>
										  <td><textarea class="expand" rows="1" style="width:100%;" id="<? echo $language["keyword"];?>" name="<? echo $language["keyword"] . "-!de";?>"><? echo trim($language["de"]); ?> </textarea></td>
										  <td><textarea class="expand" rows="1" style="width:100%;" id="<? echo $language["keyword"];?>" name="<? echo $language["keyword"] . "-!en";?>"><? echo trim($language["en"]); ?> </textarea></td>
										  <td><textarea class="expand" rows="1" style="width:100%;" id="<? echo $language["keyword"];?>" name="<? echo $language["keyword"] . "-!fr";?>"><? echo trim($language["fr"]); ?> </textarea></td>
										  <td><textarea class="expand" rows="1" style="width:100%;" id="<? echo $language["keyword"];?>" name="<? echo $language["keyword"] . "-!es";?>"><? echo trim($language["es"]); ?> </textarea></td>
										</tr>
										<?}?>
									  </tbody>
									</table>
								</div>	
							</div>

								<!-- Speicher Button -->
							<div class="form-group">
								<div class="col-sm-12">
									<button type="submit" class="pull-right btn btn-primary btn-xl" name="save" id="save">Speichern</button>
								</div>
							</div>
						</form>
						
						<!-- Modal -->
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data" id="modal">
						<div id="myModal" class="modal fade" role="dialog">
						  <div class="modal-dialog">

							<!-- Modal content-->
							<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Add new Translation</h4>
							  </div>
							  <div class="modal-body">
								<div class="container-fluid" style="padding:10px;">	
									<form action="" method="POST">
								  <div class="form-group">
									<label for="keyword">Keyword</label>
									<input type="input" class="form-control" id="keyword" name="keyword">
								  </div>
								  <button type="submit" class="btn btn-primary pull-right" id="add-keyword" name="add-keyword">Add</button>
								</form>
															</div>
							  </div>
							
							</div>

						  </div>
						</div>	
						</form>
						
					</div>
				</div>
			</div>
        </div>
	</div>
   </div><!-- /container -->
  </body>
</html>
