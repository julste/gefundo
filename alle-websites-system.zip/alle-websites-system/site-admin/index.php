<?php require "login/loginheader.php"; ?>
<? include ("../databasecredentials.php");?>
<? include("index/saveValues.php"); ?>
<? include("index/getValues.php"); ?>
<? $page = "index"; ?>
<!DOCTYPE html>
<html lang="en">
 <? include("viewparts/head.php"); ?>
  <body>
   <div class="container">
   <? include("viewparts/header.php"); ?>
		<div class="row">
			<div class="col-md-12">
				<!-- Nav tabs -->
				<div class="card">

					<? include("viewparts/nav-tab.php"); ?>
					<!-- Tab panes -->
					<div class="tab-content">
						<div class="tab-pane active" id="allgemein">
							<form class="form-horizontal" action=" " method="POST">
								<p class="lead ueberschrift">Allgemeine Daten</p>
								<div class="form-group form-group-sm">

									<!-- left column -->
									<div class="col-sm-6">
										<div class="form-group">
											<label for="websiteBame" class="col-sm-3 control-label">Website Name</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="websiteName" name="websiteName" placeholder="" value="<? echo $rowWebsite["websiteName"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="websiteUrl" class="col-sm-3 control-label">Site Url Short</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="websiteUrl" name="websiteUrl" placeholder="" value="<? echo $rowWebsite["websiteUrl"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="mailaddress" class="col-sm-3 control-label">Contact E-Mail</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="mailaddress" name="mailaddress" placeholder="" value="<? echo $rowWebsite["mailaddress"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="title" class="col-sm-3 control-label">Überschrift</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="title" name="title" placeholder="" value="<? echo $rowWebsite["title"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="title" class="col-sm-3 control-label">Suchfeldinhalt</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="searchField" name="searchField" placeholder="" value="<? echo $rowWebsite["searchField"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="title" class="col-sm-3 control-label">Sprache</label>
											<div class="col-sm-9">
												  <select class="form-control" id="language" name="language">
												    <option value="" <? if ($rowWebsite["language"] ==""){ echo 'selected=""'; }?>></option>
													<option value="de" <? if ($rowWebsite["language"] =="de"){ echo 'selected=""'; }?>>Deutsch</option>
													<option value="en" <? if ($rowWebsite["language"] =="en"){ echo 'selected=""'; }?>>Englisch</option>
													<option value="fr" <? if ($rowWebsite["language"] =="fr"){ echo 'selected=""'; }?>>Französisch</option>
													<option value="es" <? if ($rowWebsite["language"] =="es"){ echo 'selected=""'; }?>>Spanisch</option>
												  </select>
											</div>
										</div>
										<div class="form-group">
											<label for="title" class="col-sm-3 control-label">Land</label>
											<div class="col-sm-9">
												  <select class="form-control" id="country" name="country">
												    <option value="" <? if ($rowWebsite["country"] ==""){ echo 'selected=""'; }?>></option>
													<option value="de" <? if ($rowWebsite["country"] =="de"){ echo 'selected=""'; }?>>Deutschland</option>
													<option value="uk" <? if ($rowWebsite["country"] =="uk"){ echo 'selected=""'; }?>>Großbritannien</option>
													<option value="fr" <? if ($rowWebsite["country"] =="fr"){ echo 'selected=""'; }?>>Frankreich</option>
													<option value="es" <? if ($rowWebsite["country"] =="es"){ echo 'selected=""'; }?>>Spanien</option>
												  </select>
											</div>
										</div>
										<div class="form-group">
											<label for="title" class="col-sm-3 control-label">Synonyme</label>
											<div class="col-sm-9">
												  <select class="form-control" id="synonyme" name="synonyme">
												    <option value="" <? if ($rowWebsite["synonyme"] ==""){ echo 'selected=""'; }?>></option>
													<option value="1" <? if ($rowWebsite["synonyme"] ==1){ echo 'selected=""'; }?>>yes</option>
													<option value="2" <? if ($rowWebsite["synonyme"] ==2){ echo 'selected=""'; }?>>no</option>
												 </select>
											</div>
										</div>
									</div>

									<!-- right column -->
									<div class="col-sm-6">
										<div class="form-group">
											<label for="keyWordSingular" class="col-sm-3 control-label">Keyword Sing.</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="keyWordSingular" name="keyWordSingular" placeholder=""  value="<? echo $rowWebsite["keyWordSingular"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="keyWordPlural" class="col-sm-3 control-label">Keyword Plural</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="keyWordPlural" name="keyWordPlural" placeholder=""  value="<? echo $rowWebsite["keyWordPlural"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="keyWordsStartpage" class="col-sm-3 control-label">Keywords Start.</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="keyWordsStartpage" name="keyWordsStartpage" placeholder=""  value="<? echo $rowWebsite["metaKeywordsStartpage"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="position" class="col-sm-3 control-label">Ausrichtung</label>
											<div class="col-sm-9">
												<div class="btn-group" data-toggle="buttons">
													<label class="btn btn-primary <? if ($rowWebsite["position"] == "pull-left"){ echo "active";} ?>">
														<input type="radio" name="position" id="left" value="pull-left" autocomplete="off" <? if ($rowWebsite["position"] == "pull-left"){ echo "checked";} ?>> Links
													</label>
													<label class="btn btn-primary <? if ($rowWebsite["position"] == "pull-right"){ echo "active";} ?>">
														<input type="radio" name="position" id="right" value="pull-right" autocomplete="off" <? if ($rowWebsite["position"] == "pull-right"){ echo "checked";} ?>> Rechts
													</label>

												</div>
											</div>
										</div>
										<div class="form-group"><label for="googleVerification" class="col-sm-3 control-label">
                        <a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiw88fCtPPXAhXo1IMKHW0TBMEQFggqMAA&url=https%3A%2F%2Fwww.google.com%2Fwebmasters%2Ftools%2F%3Fhl%3Dde&usg=AOvVaw22K7HcY_35Ap_RwfKAXYnF" target="blank">Google Verif.</a>
                      </label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="googleVerification" name="googleVerification" placeholder=""  value="<? echo $rowWebsite["googleVerification"]; ?>">
											</div>
										</div>
                    <div class="form-group">
                      <label for="bingVerification" class="col-sm-3 control-label"><a href="https://www.bing.com/toolbox/webmaster" target="_blank">Bing Verif.</a></label>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="bingVerification" name="bingVerification" placeholder=""  value="<? echo $rowWebsite["bingVerification"]; ?>">
                      </div>
                    </div>
					<div class="form-group">
						<label for="layout" class="col-sm-3 control-label">Layout</label>
						<div class="col-sm-9">
							  <select class="form-control" id="layout" name="layout">
								<option value=""  <? if ($rowWebsite["layout"] ==""){ echo 'selected=""'; }?>></option>
								<option value="1" <? if ($rowWebsite["layout"] ==1){ echo 'selected=""'; }?>>4 Produktkarten</option>
								<option value="2" <? if ($rowWebsite["layout"] ==2){ echo 'selected=""'; }?>>2 Produktkarten</option>
								<option value="3" <? if ($rowWebsite["layout"] ==3){ echo 'selected=""'; }?>>Tabellenansicht</option>
							  </select>
						</div>
					</div>
				</div>
			</div>

								<p class="lead ueberschrift">Amazon Daten</p>
								<div class="form-group form-group-sm">

									<!-- left column -->
									<div class="col-sm-6">
										<div class="form-group">
											<label for="keyId" class="col-sm-3 control-label">Key ID</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="keyId" name="keyId" placeholder=""  value="<? echo $rowWebsite["keyId"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="secretKey" class="col-sm-3 control-label">Secret Key</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="secretKey" name="secretKey" placeholder=""  value="<? echo $rowWebsite["secretKey"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="amazonHost" class="col-sm-3 control-label">Host</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="amazonHost" name="amazonHost" placeholder=""  value="<? echo $rowWebsite["amazonHost"]; ?>">
											</div>
										</div>
									</div>

									<!-- right column -->
									<div class="col-sm-6">
										<div class="form-group">
											<label for="productCategory" class="col-sm-3 control-label"><a href="http://docs.aws.amazon.com/AWSECommerceService/latest/DG/LocaleDE.html" target="blank">Produktkategorie</a> <br>(All nur 5 Seiten)</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="productCategory" name="productCategory"  placeholder="" value="<? echo $rowWebsite["productCategory"]; ?>">
											</div>
										</div>
									<div class="form-group">
											<label for="associateId" class="col-sm-3 control-label">Associate ID</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="associateId" name="associateId" placeholder=""  value="<? echo $rowWebsite["associateId"]; ?>">
											</div>
										</div>
									<div class="form-group">
											<label for="amazonRegion" class="col-sm-3 control-label">Region</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="amazonRegion" name="amazonRegion" placeholder=""  value="<? echo $rowWebsite["amazonRegion"]; ?>">
											</div>
										</div>
									</div>

								</div>
								<p class="lead ueberschrift">Piwik</p>

								 <div class="form-group form-group-sm">
									<div class="col-sm-12">
										<div class="form-group">
											<label for="piwikLink" class="col-sm-1 control-label">Link</a></label>
											<div class="col-sm-11">
												<input type="text" class="form-control" id="piwikLink" name="piwikLink"  placeholder="" value="<? echo $rowWebsite["piwikLink"]; ?>">
												<br><p>(Bei Englischer Seite Tag auf en aendern --> language=en)</p>
											</div>
											
										</div>
										<div class="form-group">
										<label for="piwikScript" class="col-sm-1 control-label">Script</a></label>
											<div class="col-sm-11">
													<textarea class="form-control" rows="10" id="piwikScript" name="piwikScript"><? echo $rowWebsite["piwikScript"]; ?></textarea>
												<br><p>(Aus dem script Tag löschen --> type="text/javascript")</p>
											</div>

										</div>
									</div>
								</div>

								<!-- Speicher Button -->
								<div class="form-group">
									<div class="col-sm-12">
										<button type="submit" class="pull-right btn btn-primary btn-xl" id="submit">Speichern</button>
									</div>
								</div>

							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- /container -->
  </body>
</html>
