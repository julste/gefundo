<?
$url = substr($_SERVER[HTTP_HOST], 4);

if($_SERVER['REQUEST_METHOD'] === 'POST') {

try {
		$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
echo $_POST["text-".$i];

		for ($i = 0; $i <= count($_POST); $i++) {

			if(!empty($_POST["id-".$i])){

				// Update
				$sql = 'UPDATE content SET heading = :heading, text = :text, link = :link WHERE id = :id';
				$statement = $dbh->prepare($sql);
				$link = sanitizeStringForUrl(utf8_decode($_POST["heading-".$i]));
				$statement->bindParam(':heading', utf8_decode($_POST["heading-".$i]) , PDO::PARAM_STR);
				$statement->bindParam(':text', utf8_decode($_POST["text-".$i]), PDO::PARAM_STR);
				$statement->bindParam(':link', $link, PDO::PARAM_STR);
				$statement->bindParam(':id', utf8_decode($_POST["id-".$i]), PDO::PARAM_STR);
				$statement->execute();

			}else{

				if(!empty($_POST["heading-".$i]) and !empty($_POST["text-".$i])){

					$sql = 'SELECT * from website where websiteUrl = "'.$url.'"';
					$dbh->query("SET CHARACTER SET utf8");
					$rowWebsite = $dbh->query($sql)->fetch();
					$websiteId = $rowWebsite["id"];

					$sql = 'INSERT INTO content SET heading = :heading, text = :text, link = :link WHERE id = :id';
					$stmt = $dbh->prepare("INSERT INTO content (heading, text, link, websiteId) VALUES (?, ?, ?, ?)");

					$link = sanitizeStringForUrl($_POST["heading-".$i]);
					$stmt->bindParam(1, utf8_decode($_POST["heading-".$i]));
					$stmt->bindParam(2, utf8_decode($_POST["text-".$i]));
					$stmt->bindParam(3, $link);
					$stmt->bindParam(4, $websiteId);

					$stmt->execute();
				}
			}
		}


		} catch (PDOException $e) {
		print "Error: " . $e->getMessage() . "<br/>";
		die();
	}

?>

<script>
alert("Texte wurden erfolgreich gepeichert!");
</script>
<?
	}
?>
