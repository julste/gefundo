<?
$url = substr($_SERVER[HTTP_HOST], 4);

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT c.id as id, c.heading as heading, c.text as text, c.link as link from content c, website w where c.websiteId = w.id and w.websiteUrl = "'.$url.'"';
	$dbh->query("SET CHARACTER SET utf8");
	$rowText = $dbh->query($sql)->fetchall();
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}
?>