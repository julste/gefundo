<?
$url = substr($_SERVER[HTTP_HOST], 4);

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT i.path from image i, website w where i.websiteId = w.id and i.name = "backgroundImage" and w.websiteUrl = "'.$url.'"';
	$dbh->query("SET CHARACTER SET utf8");
	$backgroundImage = $dbh->query($sql)->fetch();

	/*
	$sql = 'SELECT * from image where name = "imprintImage"';
	$dbh->query("SET CHARACTER SET utf8");
	$imprintImage = $dbh->query($sql)->fetch();
	*/
	
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}

?>