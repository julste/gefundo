<?
$url = substr($_SERVER[HTTP_HOST], 4);

if($_SERVER['REQUEST_METHOD'] === 'POST') {

try {
		$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
		$sql = 'UPDATE website SET
				websiteUrl = :websiteUrl,
				websiteName = :websiteName,
				mailaddress = :mailaddress,
				searchField = :searchField,
				title = :title,
				position = :position,
				keyWordSingular = :keyWordSingular,
				keyWordPlural = :keyWordPlural,
				metaKeywordsStartpage = :metaKeywordsStartpage,
				keyId = :keyId,
				secretKey = :secretKey,
				associateId = :associateId,
				productCategory = :productCategory,
				browseNode = :browseNode,
				piwikScript = :piwikScript,
				piwikLink = :piwikLink,
				googleVerification = :googleVerification,
				bingVerification = :bingVerification,
				language = :language,
				layout = :layout,
				country = :country,
				synonyme = :synonyme
				WHERE websiteUrl = "'.$url.'"';
		$statement = $dbh->prepare($sql);

		$websiteUrl = utf8_decode($_POST['websiteUrl']);
		$websiteName = utf8_decode($_POST['websiteName']);
		$mailaddress = utf8_decode($_POST['mailaddress']);
		$searchField = utf8_decode($_POST['searchField']);
		$title = utf8_decode($_POST['title']);
		$position = utf8_decode($_POST['position']);
		$keyWordSingular = utf8_decode($_POST['keyWordSingular']);
		$keyWordPlural = utf8_decode($_POST['keyWordPlural']);
		$keyWordsStartpage = utf8_decode($_POST['keyWordsStartpage']);
		$keyId = utf8_decode($_POST['keyId']);
		$secretKey = utf8_decode($_POST['secretKey']);
		$associateId = utf8_decode($_POST['associateId']);
		$productCategory = utf8_decode($_POST['productCategory']);
		$browseNode = utf8_decode($_POST['browseNode']);
		$piwikScript = utf8_decode($_POST['piwikScript']);
		$piwikLink = utf8_decode($_POST['piwikLink']);
		$googleVerification = utf8_decode($_POST['googleVerification']);
		$bingVerification = utf8_decode($_POST['bingVerification']);
		$language = utf8_decode($_POST['language']);
		$layout = utf8_decode($_POST['layout']);
		$country = utf8_decode($_POST['country']);
		$synonyme = utf8_decode($_POST['synonyme']);


		$statement->bindParam(':websiteUrl', $websiteUrl, PDO::PARAM_STR);
		$statement->bindParam(':websiteName', $websiteName, PDO::PARAM_STR);
		$statement->bindParam(':mailaddress', $mailaddress, PDO::PARAM_STR);
		$statement->bindParam(':searchField', $searchField, PDO::PARAM_STR);
		$statement->bindParam(':title', $title, PDO::PARAM_STR);
		$statement->bindParam(':position', $position, PDO::PARAM_STR);
		$statement->bindParam(':keyWordSingular', $keyWordSingular, PDO::PARAM_STR);
		$statement->bindParam(':keyWordPlural', $keyWordPlural, PDO::PARAM_STR);
		$statement->bindParam(':metaKeywordsStartpage', $keyWordsStartpage, PDO::PARAM_STR);
		$statement->bindParam(':keyId', $keyId, PDO::PARAM_STR);
		$statement->bindParam(':secretKey', $secretKey, PDO::PARAM_STR);
		$statement->bindParam(':associateId', $associateId, PDO::PARAM_STR);
		$statement->bindParam(':productCategory', $productCategory, PDO::PARAM_STR);
		$statement->bindParam(':browseNode', $browseNode, PDO::PARAM_STR);
		$statement->bindParam(':piwikScript', $piwikScript, PDO::PARAM_STR);
		$statement->bindParam(':piwikLink', $piwikLink, PDO::PARAM_STR);
		$statement->bindParam(':googleVerification', $googleVerification, PDO::PARAM_STR);
		$statement->bindParam(':bingVerification', $bingVerification, PDO::PARAM_STR);
		$statement->bindParam(':language', $language, PDO::PARAM_STR);
		$statement->bindParam(':layout', $layout, PDO::PARAM_STR);
		$statement->bindParam(':country', $country, PDO::PARAM_STR);
		$statement->bindParam(':synonyme', $synonyme, PDO::PARAM_STR);
				
		$statement->execute();
		$dbh = null;

	} catch (PDOException $e) {
		print "Error: " . $e->getMessage() . "<br/>";
		die();
	}

?>

<script>
alert("Informationen wurden erfolgreich gepeichert!");
</script>
<?
	}
?>
