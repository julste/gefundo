
<?	$search = str_replace('-', ' ', $_GET['q']);  ?>

<div class="row " style="padding-top:70px;">
	<div class="col-md-9 col-sm-12 col-xs-12" >
		<h1>
			<? 
			if( $do_search == true) {
				if($_GET['q'] != ""){
					echo $languageArray["Ergebnisse_zu"].' "'.$search.'"';
				}
				$search = $_GET['q'];
				$searchToAmazon = "'".$keyWordSingular." ".$search."'";
			
			}elseif($do_search == false){ 
				echo $amazonname; 
				$searchToAmazon = "'".$amazonname."'";
			}	
			
			if(isset($searchButton)){
				echo "test";
			}
			
			?> 
			
			
		</h1>
	</div>
	<?
	if(isset($_GET["minprice"])){
		$minprice = $_GET["minprice"];
	}else{
		$minprice = 0;
	}
	
	if(isset($_GET["maxprice"])){
		$maxprice = $_GET["maxprice"];
	}else{
		$maxprice = 2000;
	}
	?>
	
	<div class="col-md-3 col-sm-12 col-xs-12">	
		<div class="filterkasten  pull-right">
			<form action="/result.php">	
				<input type="hidden" name="q" value="<?echo $search;?>" /> 
				<div class="controls" style="text-align:right;">
					<span><? echo $currency; ?></span>
					<input class="filter-input" id="minprice" name="minprice" type="text" value="<?echo $minprice; ?>" />
					<span>- <? echo $currency ?></span>
					<input class="filter-input" id="maxprice" name="maxprice" type="text" value="<?echo $maxprice; ?>" />
					<button type="submit" id="search" class="btn ">go</button>
				</div>	
			</form>
		</div> 
	</div>
	
</div>
 </div>
  <div class="container">		
<div class="result-hr">
<hr>
 </div>
				 														
<!-- Produktansicht Version 1 -->
		<? 
		$anfang = 1;
		$ende = 2;
		
		if (isset($_GET['page'])){
		switch ($_GET['page']) {
			case 1:
				$anfang = 1;
				$ende = 2;
				break;
			case 2:
				$anfang = 3;
				$ende = 4;
				break;
			case 3:
				$anfang = 5;
				$ende = 6;
				break;
			case 4:
				$anfang = 7;
				$ende = 8;
				break;
			case 5:
				$anfang = 9;
				$ende = 10;
				break;
		}
		}

?>
	<div class="row">
	<?
   

	$pageWork = false;
   	$totalPages = 0;

for ($i = $anfang; $i <= $ende; $i++) {
	
	$items = $amazonAPI->ItemSearch($searchToAmazon, $i, $productCategory, $browseNode, 'salesrank', $maxprice, $minprice);
	//$items = $amazonAPI->ItemSearch($search, $i, 'Shoes', '1760296031', 'salesrank', $maxprice, $minprice);
	//print_r($items);
	if($pageWork == false){
	$totalPages =$items[0]["Totalpages"];
	}
	$pageWork = true;
	
	foreach ($items as $item){
	//	print_r($item);
		// Bilder von http auf https umswitchen
		// siehe: https://stackoverflow.com/questions/31856365/amazon-ecs-api-to-return-secure-images-url
		$item["largeImage"] = str_replace('http://ecx.images-amazon.com','https://images-na.ssl-images-amazon.com',$item["largeImage"] );
		$item["mediumImage"] = str_replace('http://ecx.images-amazon.com','https://images-na.ssl-images-amazon.com',$item["mediumImage"] );
		$item["smallImage"] = str_replace('http://ecx.images-amazon.com','https://images-na.ssl-images-amazon.com',$item["smallImage"] );
		
		if($item["HasReviews"] == "true"){
		$item["iframe"] = str_replace('http://','https://',$item["iframe"]);
		}
		
		if($item['formattedprice1'] != ""){
			$displayPrice = number_format(( $item['formattedprice1'] /100.0) ,2,'.','');
		}elseif($item['formattedprice2'] != ""){
			$displayPrice = number_format(( $item['formattedprice2'] /100.0) ,2,'.','');
		}elseif($item['formattedprice3'] != ""){
			$displayPrice = number_format(( $item['formattedprice3'] /100.0) ,2,'.','');	
		}else{
			$displayPrice = 0.00;
		}
		
		?>
	
			<div class="col-md-6 col-sm-6 hero-feature">	
					<div class="thumbnail"> 
						<? 									 
						$string_laenge = strlen($item['title']);
						$string_title = $item['title'];
						$string_max_laenge = 60;
					
						 if ($string_laenge >= $string_max_laenge) {
								$string_title = preg_replace("/[^ ]*$/", '', substr($item['title'], 0, $string_max_laenge));
						}       	      					
						?>

						<div class="caption " style="min-height:50px;"><? echo "<b>".$string_title."</b>"; ?></div>

						<div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
						<img class="marginBottom align-horizontal"  src="<? echo $item['mediumImage'];?>" title="<?echo $string_title;?>" alt="<? echo $item['title']; ?>" >

						</div>
						
						<div class="col-md-8 col-sm-12 col-xs-12 col-lg-8 thumbText kuerzen">
							<ul>
							 <?if (isset($item['feature_0'])) {?>
								 <?}?> 
								 <? 
								  $string_feature =""; 
								   
								if (isset($item['feature_3'])) {
									$string_feature .= '<li>'.$item['feature_3'].'</li>';
									if (isset($item['feature_2'])) {
										$string_feature .= '<li>'.$item['feature_2'].'</li>';
										if (isset($item['feature_0'])) {
											$string_feature .= '<li>'.$item['feature_0'].'</li>';
											if (isset($item['feature_4'])) {
												$string_feature .= '<li>'.$item['feature_4'].'</li>';
													if (isset($item['feature_1'])) {
														$string_feature .= '<li>'.$item['feature_1'].'</li>';
													}
											}
										}
									}
								}	
								$text=wordwrap($string_feature, 250, "gefundo30"); 
								$text=explode("gefundo30",$text); 
								echo "$text[0]";
								?>
								<li>
								<a type="button" href="#" data-toggle="modal" data-target="#<?echo $item['asin']; ?>">...</a>
								</li>
							</ul>
					</div>

						<div style="text-align: center; padding-top:20px;">		
						<? if($item["HasReviews"] == "true" ){?>						
							 <a href="#" class="modalButton" data-toggle="modal" data-src="<? echo $item["iframe"]; ?>" aria-labelledby="myModalLabel" aria-hidden="true" data-target="#myModal">
								<? echo $languageArray["bewertungen"]; ?>
							 </a>
						   <div class="modal fade" id="myModal" role="dialog"  aria-labelledby="myModalLabel"  aria-hidden="true">
							  <div class="modal-dialog">
								 <div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
										<h4 class="modal-title" id="myModalLabel">
											<? echo $languageArray["bewertungen"]; ?>
										</h4>
								   </div>
								 <div class="embed-responsive embed-responsive-4by3" >
									  <iframe frameborder="0" class="embed-responsive-item"></iframe> 
								 </div>
								 <div class="modal-footer">
									<button type="button" class="btn btn-warning" data-dismiss="modal">
										<? echo $languageArray["schliessen"]; ?>
									</button>
								<form id="redirform" action="redirect.php" method="post">
									 <input type="hidden" name="redirdata" id="redirdata">
								</form>
								<span class="btn redir-link btn-primary" data-submit="<?=base64_encode($item['url']) ?>">
									<? echo $languageArray["zum_angebot"]; ?>
								</span>
								 </div> 
								</div><!-- /.modal-content -->
							 </div><!-- /.modal-dialog -->
						  </div>
							 |
						<?}?>
						<? 
							echo $languageArray["bester_preis"].": <b>". $displayPrice ." ".$currency."</b><br><br>"; 
						?>							
						</div>
						
						<div>
							<div class="">
								<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#<?echo $item['asin']; ?>"> 
									<span class="glyphicon glyphicon-search" aria-hidden="true"></span> Details
								</button>
								<form id="redirform" action="redirect.php" method="post">
									 <input type="hidden" name="redirdata" id="redirdata">
								</form>
								<span class="btn redir-link btn-primary" data-submit="<?=base64_encode($item['url']) ?>">
									<? echo $languageArray["zum_angebot"]; ?>
								</span>
							</div>
						</div>	
						
					</div>
			</div>
		
<!-- Modal - Start -->
<div class="modal fade" id="<? echo $item['asin']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<!-- Header -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="myModalLabel"><? echo $item['title']; ?></h4>
			</div>			
			
			<!-- Body -->
			<div class="modal-body">
				 <div class="container-fluid" style="padding:10px;">	 
					<div class="row">
						<div class="col-xs-6">
							<img class="media-object" src="<? echo $item['largeImage'];?>" alt="<? echo $item['title']; ?>" width="90%" height="90%" >
						</div>
						
						<div class="col-xs-6" >
							<div>
								<? echo $languageArray["angaben_zur_verfuegbarkeit"].":";?>
							</div>
							<div style="margin-top:10%;">
								
								<? 
								try {
									$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
									$sql = 'SELECT * from country where country = "'.$country.'"';
									$dbh->query("SET CHARACTER SET utf8");
									$rowCountry = $dbh->query($sql)->fetch();
									$dbh = null;
								} catch (PDOException $e) {
									print "Error: " . $e->getMessage() . "<br/>";
									die();
								}		
								?>
								<img class="media-object" src="<? echo $rowCountry['amazonImage'];?>" width="50%" height="50%" alt="Amazon Partnerprogramm Logo"/>

							</div>
								
							<div style="margin-top:10%;">
						
								<? echo "<h4>".$languageArray["preis"].": <b>". $displayPrice ." ".$currency."</b></h4>"; ?>
							</div>
							
							<div style="margin-top:5%;">
								<button type="button" class="btn btn-warning" data-dismiss="modal"><? echo $languageArray["schliessen"];?></button>
								<form id="redirform" action="redirect.php" method="post">
									 <input type="hidden" name="redirdata" id="redirdata">
								</form>
								<span class="btn redir-link btn-primary" data-submit="<?=base64_encode($item['url']) ?>">
									<? echo $languageArray["zum_angebot"]; ?>
								</span>								
							</div>
						</div>
					</div>
					 
					 <br>
					 
			 <!-- Footer -->
			 <div class="modal-footer">
				 <div class="row">
					 <div class="col-xs-12" style="text-align:left">

					 <?if (isset($item['feature_0'])) {?>
						 <b><h4><? echo $languageArray["produktbeschreibung"].":"; ?></h4></b>
					 <?}?> 
					 <ul>
					 <?
					 
					  $string_feature =""; 
					   
					if (isset($item['feature_3'])) {
						$string_feature .= '<li>'.$item['feature_3'].'</li>';
						if (isset($item['feature_2'])) {
							$string_feature .= '<li>'.$item['feature_2'].'</li>';
							if (isset($item['feature_0'])) {
								$string_feature .= '<li>'.$item['feature_0'].'</li>';
								if (isset($item['feature_4'])) {
									$string_feature .= '<li>'.$item['feature_4'].'</li>';
										if (isset($item['feature_1'])) {
											$string_feature .= '<li>'.$item['feature_1'].'</li>';
										}
								}
							}
						}
					}			
						echo $string_feature;
						
					
					?>
				</ul>
					<? if($item["EditorialReview"] != ""){ ?>
					<br>
					<h4><? echo $languageArray["weitere_details"]; ?></h4>
					<? echo $item["EditorialReview"]; ?>
					<?}?>
					
					</div>
				</div>
			</div>
		
		</div>		
	</div>
</div>
</div>
</div>
<!-- Modal - Ende -->	

<?}}?>
<? $search = $_GET["q"]; ?>
</div> 

<? if( $do_search == true) {?>

<? if($totalPages > 2){?>
<nav style="text-align:right;">
  <ul class="pagination">
     <li>
      <? if (isset($_GET['page']) and $_GET['page']!=1 ){  ?>
	  <a  href="/result.php?q=<? echo $search; ?>&page=<? echo $_GET['page']-1; ?>&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>" aria-label="Previous"><?}?>
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li class="<? if($_GET['page']==1 or !isset($_GET['page'])){echo "active";} ?>">
		<a href="/result.php?q=<? echo $search; ?>&page=1&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">1</a>
	</li>
    <li class="<? if($_GET['page']==2){echo "active";} ?>">
		<a href="/result.php?q=<? echo $search; ?>&page=2&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">2</a>
	</li>
    
	<? if($totalPages > 4){?>
	<li class="<? if($_GET['page']==3){echo "active";} ?>">
		<a href="/result.php?q=<? echo $search; ?>&page=3&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">3</a>
	</li>
    <?}?>
	
	<? if($totalPages > 6){?>
	<li class="<? if($_GET['page']==4){echo "active";} ?>">
		<a href="/result.php?q=<? echo $search; ?>&page=4&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">4</a>
	</li>
	<?}?>
	
	<? if($totalPages > 8){?>
    <li class="<? if($_GET['page']==5){echo "active";} ?>">
		<a href="/result.php?q=<? echo $search; ?>&page=5&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">5</a>
	</li>
	<?}?>

   <li>
		<? 
		if(isset($_GET['page'])){
			if ( ($totalPages/2) > $_GET['page'] and $_GET['page'] < 5 ){  ?>
				<a href="/result.php?q=<? echo $search; ?>&page=<? if (isset($_GET['page'])){ echo $_GET['page']+1; }else{ echo 2;} ?>&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>" aria-label="Next">
			<?}
		}?>
				<span aria-hidden="true">&raquo;</span>
			</a>
    </li>
  </ul>
</nav>
<?}?>

<?}elseif( $do_search == false){?>
<nav style="text-align:right;">
  <ul class="pagination">
     <li>
      <? if (isset($_GET['page']) and $_GET['page']!=1 ){  ?>
	  <a  href="<? echo $search; ?>&page=<? echo $_GET['page']-1; ?>" aria-label="Previous">
	  <?}?>
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li class="<? if($_GET['page']==1 or !isset($_GET['page'])){echo "active";} ?>">
		<a href="<? echo $search; ?>">1</a>
	</li>
    <li class="<? if($_GET['page']==2){echo "active";} ?>">
		<a href="<? echo $search; ?>&page=2">2</a>
	</li>
    
	<? if($totalPages > 4){?>
	<li class="<? if($_GET['page']==3){echo "active";} ?>">
		<a href="<? echo $search; ?>&page=3">3</a>
	</li>
    <?}?>
	
	<? if($totalPages > 6){?>
	<li class="<? if($_GET['page']==4){echo "active";} ?>">
		<a href="<? echo $search; ?>&page=4">4</a>
	</li>
	<?}?>
	
	<? if($totalPages > 8){?>
    <li class="<? if($_GET['page']==5){echo "active";} ?>">
		<a href="<? echo $search; ?>&page=5">5</a>
	</li>
	<?}?>

   <li>
		<? 
		if ( ($totalPages/2) > $_GET['page'] and $_GET['page'] < 5 ){ 
		?>	
			<a href="<? echo $search; ?>&page=<? if (isset($_GET['page'])){ echo $_GET['page']+1; }else{ echo 2;}?>" aria-label="Next">
		<?}
        ?>
		<span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
<?}?>
		