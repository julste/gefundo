<?php
// Database Credentials
$hostName = "10.35.249.143";
$dbName = "k62346_database";
$dbUserName = "k6234_gefundo";
$dbPassword = "Emxx75*6";
?>