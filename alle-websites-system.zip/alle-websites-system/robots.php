User-agent: *
Disallow: /

User-agent: bingbot
allow: /

User-agent: googlebot
allow: /

User-agent: duckduckbot
allow: /
<?php  
echo "Sitemap: https://". $_SERVER[HTTP_HOST]. "/sitemap.xml"; 
header("Content-Type: text/plain");
?>