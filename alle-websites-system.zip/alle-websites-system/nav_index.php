<?
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from content where text <> "" and websiteId = "'.$websiteId.'"';
	$dbh->query("SET CHARACTER SET utf8");
	$rowText = $dbh->query($sql)->fetchall();
	$dbh = null;
} catch (PDOException $e) {
	print "Error!: " . $e->getMessage() . "<br/>";
	die();
}
?>



<nav class="navbar navbar-default navbar-fixed-top topnav" >
    <div class="container topnav">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
				<p class="logo-schrift front-logo">
					<a href="/" title="<? echo $websiteName;?>">
						<? echo $websiteName; ?>
						<? /* falls	in Zukunft wieder Logos als Bild kommen
						<img src="" title="" alt="" class="img-responsive" />*/?>
					</a>
				</p>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="padding-top:8px;">
            <ul class="nav navbar-nav navbar-right">
                <li> <a href="/#<?echo $rowText[0]["link"];?>" title="<?echo $rowText[0]["heading"];?>"><?echo $rowText[0]["heading"];?></a> </li>
                <li> <a href="/#<?echo $rowText[1]["link"];?>" title="<?echo $rowText[1]["heading"];?>"><?echo $rowText[1]["heading"];?></a> </li>
                <li> <a href="/#<?echo $rowText[2]["link"];?>" title="<?echo $rowText[2]["heading"];?>"><?echo $rowText[2]["heading"];?></a> </li>
            </ul>
        </div>
    </div>
</nav>
