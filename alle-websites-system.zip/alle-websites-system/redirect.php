<?
 function prgRedirect()
{
   $url = "";
   
   if(!empty($_POST['redirdata']))
   {
      $url = base64_decode($_POST['redirdata']);
	  /*
	  if(strstr($url, $location) !== false)
      {
        $location = $url;
      } 
      else if(strstr($_SERVER['HTTP_REFERER'], $location) !== false)
     { 
       $location = $_SERVER['HTTP_REFERER'];
      }
    */
	}
	
	//echo "location:". $location;
    header("Location: " . $url, true, 302);
    exit();
 }
 prgRedirect();
?>