<?php    
include ("databasecredentials.php");
include ("credentials.php");

/* create a dom document with encoding utf8 */
$domtree = new DOMDocument('1.0', 'UTF-8');

/* create the root element of the xml tree */
$xmlRoot = $domtree->createElementNS('http://www.sitemaps.org/schemas/sitemap/0.9', 'urlset');
/* append it to the document created */
$xmlRoot = $domtree->appendChild($xmlRoot);

$currentTrack = $domtree->createElement("url");
$currentTrack = $xmlRoot->appendChild($currentTrack);

/* you should enclose the following two lines in a cicle */
$currentTrack->appendChild($domtree->createElement('loc','https://www.'.$websiteUrl));
$url = substr($_SERVER[HTTP_HOST], 4);

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$dbh->query("SET CHARACTER SET utf8");
	$sql = 'SELECT * from page p, website w where p.status = 1 and p.websiteId = w.id and w.websiteUrl = "'.$url.'"';
	
	foreach($dbh->query($sql) as $row){			
		$currentTrack = $domtree->createElement("url");
		$currentTrack = $xmlRoot->appendChild($currentTrack);
		$currentTrack->appendChild($domtree->createElement('loc','https://www.'.$websiteUrl.'/'.$row['slug']));
	}

	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}

$xml_string = $domtree->saveXML();
echo $xml_string;

header("Content-type: text/xml; charset=utf-8");
	
?>