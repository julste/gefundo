﻿<?
// Content SQL in Nav Index!
foreach($rowText as $row){?>
	<a id="<?echo $row["link"];?>"></a>
	<div class="content-section-anfang">
		<div class="container">
			<div class="row">
				<div class="col-lg-12" style="text-align:center">
					<div class="clearfix"></div>
					<h2 class="section-heading"><?echo $row["heading"];?></h2>
					
						<?echo $row["text"];?>
				
				</div>
			</div>
		</div>
	</div>
<?}?>

