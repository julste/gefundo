    <nav class="navbar navbar-default navbar-fixed-top topnav">

        <div class="container topnav">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle " data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
				
				<div>
				<p class="logo-schrift front-logo">
					<a href="/" title="<? echo $websiteName;?>">
						<? echo $websiteName; ?>
						<? /* falls	in Zukunft wieder Logos als Bild kommen
						<img src="" title="" alt="" class="img-responsive" />*/?>
					</a>
				</p>
            </div>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse collapse-button" id="bs-example-navbar-collapse-1">
              				<div class="col-lg-6 col-md-6 col-xs-12 col-sm-6 pull-right" style="padding-top:8px;padding-bottom:0px;">

						<form action="/result.php" method="GET" class="form-group margin-input-suche input-inline-block" role="search" name="Formular"  onsubmit="return chkFormular();">
						<div class="input-group col-lg-12 col-xs-12">
						
							<?
							if( $do_search == true) {
								if (isset($_GET['q'])){
									$q = str_replace('-', ' ', $_GET['q']); 
								}else{
									$q = "";
								}	
							}elseif($do_search == false){ 
								$q = $googlename; 
								
							}
							?>
							<input type="text" class="form-control input-lg" placeholder="<? echo $searchField; ?>" name="q" value="<? echo $q; ?>">
							<div class="input-group-btn">
									<button class="btn btn-success btn-lg" type="submit">
									<i class="glyphicon glyphicon-search"></i>
							</button>
						</div>
					</div>
				</form>
                   </div>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>