  <p>
                        <h3><strong>Legal Disclosure</strong></h3>
                        <br> <strong>Information in accordance with section 5 TMG:</strong>
                        </br>
                        </br>
               			<p>
							<img src="country/uk/Contact-address-GbR.png" alt="Contact Information - Imprint">
						</p>
                    </p>

					<p>
                        <br> <strong>Represented by:</strong>
                        <br>
                        <br>
                        <p>
							<img src="country/uk/vertreten.jpg" alt="Contact Information - Representatives">
						</p>
                    </p>


					<p>
                        <br> <strong>VAT number:</strong>
                        <br>
                        <br>
						VAT indentification number in accorance with section 27 a of the German VAT act:
						<br /> DE301596448
                    </p>

                    <br><strong>Person responsible for content in accordance with 55 Abs. 2 RStV:</strong>
                    <br>
                    <br>
					<p>
							<img src="country/uk/Contact-address-GbR.png" alt="Contact Information - Imprint">
					</p>
                    <br><strong>Indication of source for product images:</strong>
                    <p>
                        <br>Amazon.de (Affiliate Program)</p>

                    <br><strong>Indication of source for images and graphics:</strong>
                    <p>
                        <br>https://picjumbo.com/
						<br>Viktor Hanacek
					</p>

                    <br><strong>Important notice:</strong>
                    <p>
                        <ul>
                            <li class="impressum_bullets"><? echo $websiteUrl; ?> is not an online shop, we solely want to encourage your purchase decision.</li>
                            <li class="impressum_bullets">It is not possible to buy or order products at <? echo $websiteUrl; ?>.</li>
                            <li class="impressum_bullets">It is not possible to find information at <? echo $websiteUrl; ?> about products or manufacturer.</li>
                            <li class="impressum_bullets">If you have any questions regarding offers please direct them to the specific manufacturer or online shop.</li>
                        </ul>
                    </p>

					<br><strong>Actuality of costs:</strong>
                    <p>
                        <br>It is possible that the prices listed under <? echo $websiteUrl; ?>are outdated. Significant for you are the prices which are specified direct at the associated partner shop.
					</p>

                    <p>Thank you for your understanding!</p>
                    <p>
                        <br>Source: <a href="http://www.e-recht24.de">E-Recht24.de</a>
                    </p>
                    <br>
                     <strong>Picture Credits</strong>
                    <br>
                    <br>
                    <p style="text-align:justify">
                        Those pages use images provided by the Amazon product catalog, in any case images on <? echo $websiteUrl; ?>are subject to copyright. Without explicit written permission it is expressly prohibited to use or distribute images / pictures.
                    </p>

                    <br><strong>Intellectual Property Rights and Neighbouring Rights</strong>
                    <br>
                    <br>
                    <p style="text-align:justify">
                        The contents and works on the page prepared by the operator of the web page are subject to German copyright law. Copying, processing, or distributing them and any kind of use beyond the limitations of copyright law require the prior written agreement of the corresponding author or creator. Downloads and copies of this page are only allowed for private use and must not be used for commercial purposes. If the contents of this page have not been prepared by the operator, the copyrights of third parties are obeyed. Furthermore, contents quoted from third parties are marked. However, if you notice any copyright infringement, please inform us immediately. If we are informed about any injuries of law, we will immediately remove such contents.

                        The display of this website in external frames is only allowed after prior written agreement.
                    </p>

                    <br><strong>Data Privacy</strong>
                    <br>
                    <br>
                    <p style="text-align:justify">
                        Generally, it is possible to use our website without indicating personal data. If personal data (e.g. name, address or email address) are recorded on any of our pages, the owner generally enters the data voluntarily. Those data are not handed over to third parties without your explicit agreement.
                        <br><br>
                        We point out that there can be security gaps in the data transfer on the Internet (e.g. when communicating by email). It is not possible to completely protect the data from an access of third parties.
                        <br><br>
                        Hereby, we explicitly prohibit the use of contact data as disclosed in this legal information by third parties for sending unsolicited advertising and information material. The operators of this web page reserve the right to take legal action if unsolicited advertising information is sent e.g. by spam mail.
                    </p>

                    <br><strong>Amazon Associates Program</strong>
                    <br>
                    <br>
                    <p style="text-align:justify">
                        <? echo $websiteUrl; ?> is a participant in the Amazon Europe S.à r.l. Associates Programme, an affiliate advertising programme designed to provide a means for sites to earn advertising fees by advertising and linking to Amazon.co.uk / Amazon.de. The prices of products are automated provided by Amazon, errors and changes excepted.
                    </p>