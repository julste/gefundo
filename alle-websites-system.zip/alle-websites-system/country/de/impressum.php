<h3>
	<strong>Impressum</strong>
</h3>
<br> 
		<p>
			<img src="country/de/kontakt_adresse.jpg" alt="Kontaktdaten - Impressum">
		</p>                
<p> 
<strong>Vertreten durch:</strong>
</p>
<p>
	<img src="country/de/vertreten.jpg">
</p>  
		
<p> 
<strong>Kontakt:</strong>		
</p>
<p>
	<img src="country/de/kontakt_mail.jpg">
</p> 
<p> 
<strong>Umsatzsteuer:</strong>		
</p>
Umsatzsteuer-Identifikationsnummer gemäß §27 a Umsatzsteuergesetz:
<br>
DE301596448

<br>
<br><strong>Haftung für Inhalte</strong>
<br>
<br>

<p style="text-align:justify">Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den
	allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht
	verpflichtet, übermittelte oder gespeicherte fremde Informationen
	zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
	Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den allgemeinen Gesetzen
	bleiben hiervon unberührt. Eine diesbezügliche Haftung
	ist jedoch erst ab dem Zeitpunkt der Kenntnis einer konkreten Rechtsverletzung möglich. Bei
	Bekanntwerden von entsprechenden Rechtsverletzungen werden wir diese Inhalte umgehend entfernen.</p>

<br><strong>Haftung für Links</strong>
<br>
<br>

<p style="text-align:justify">Unser Angebot enthält Links zu externen Webseiten Dritter, auf deren Inhalte wir keinen Einfluss haben.
	Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der
	verlinkten Seiten ist stets der jeweilige Anbieter
	oder Betreiber der Seiten verantwortlich. Die verlinkten Seiten wurden zum Zeitpunkt der Verlinkung auf
	mögliche Rechtsverstöße überprüft. Rechtswidrige Inhalte waren zum Zeitpunkt der Verlinkung nicht
	erkennbar. Eine permanente inhaltliche Kontrolle
	der verlinkten Seiten ist jedoch ohne konkrete Anhaltspunkte einer Rechtsverletzung nicht zumutbar. Bei
	Bekanntwerden von Rechtsverletzungen werden wir derartige Links umgehend entfernen.</p>

<br><strong>Urheberrecht</strong>
<br>
<br>

<p style="text-align:justify">Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen
	Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der
	Grenzen des Urheberrechtes bedürfen der schriftlichen
	Zustimmung des jeweiligen Autors bzw. Erstellers. Downloads und Kopien dieser Seite sind nur für den
	privaten, nicht kommerziellen Gebrauch gestattet. Soweit die Inhalte auf dieser Seite nicht vom
	Betreiber erstellt wurden, werden die Urheberrechte
	Dritter beachtet. Insbesondere werden Inhalte Dritter als solche gekennzeichnet. Sollten Sie trotzdem
	auf eine Urheberrechtsverletzung aufmerksam werden, bitten wir um einen entsprechenden Hinweis. Bei
	Bekanntwerden von Rechtsverletzungen werden wir
	derartige Inhalte umgehend entfernen.</p>

   <p>
	 <br>Quelle: <a href="http://www.e-recht24.de">http://www.e-recht24.de</a>
	</p>

<br><strong>Amazon Partnerprogramm</strong>
<br>
<br>

<p style="text-align:justify">
	<? echo $websiteUrl; ?> ist Teilnehmer des Partnerprogramms von Amazon Europe S.à r.l. und Partner des
	Werbeprogramms, das zur Bereitstellung eines Mediums für Websites konzipiert wurde, mittels dessen durch
	die Platzierung von Werbeanzeigen und Links zu Amazon.de
	Werbekostenerstattung verdient werden kann. Die Preise der Produkte werden automatisiert von Amazon zur
	Verfügung gestellt, Irrtümer und Änderungen blieben vorbehalten.
</p>

<br><strong>Quellenangaben für die Produktbilder:</strong>
		<p>
			<br>Amazon.de (Partnerprogramm)</p>
		<br><strong>Quellenangaben für die verwendeten Bilder und Grafiken:</strong>
		<p>
			<br>https://pixabay.com/
		</p>

		<br><strong>Wichtige Hinweise:</strong>
		<p>
			<ul>
				<li class="impressum_bullets"><?echo $websiteUrl;?> ist kein Onlineshop, wir m&ouml;chten dich lediglich bei deiner Kaufentscheidung unterstützen.</li>
				<li class="impressum_bullets">Auf <? echo $websiteUrl;?> kannst du keine Produkte kaufen oder bestellen.</li>
				<li class="impressum_bullets">Bitte wende dich bei Fragen zu Angeboten direkt an den anbietenden Onlineshop bzw. Hersteller.</li>
			</ul>
		</p>

		<br><strong>Aktualität von Preisen:</strong>
		<p>
			<br>Die unter <? echo $websiteUrl;?> angegebenen Preise können gegebenenfalls nicht mehr aktuell sein, da Preisänderungen auf unserer Website nur zeitverzögert dargestellt werden können. Maßgeblich sind die Preise in den jeweiligen verlinkten Partnershops.
		</p>

		<p>Vielen Dank für dein Verständnis!</p>
	
