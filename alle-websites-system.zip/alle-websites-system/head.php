<head>
<?php if($page =="index"){?>
	<title>
	<?php
		$title_string = $languageArray["meta_title_startpage"];
		eval("\$title_string = \"$title_string\";");
		echo $title_string;
	?>
	</title>
<?
$metaTextStartpage = $languageArray["meta_text_startpage"];
eval("\$metaTextStartpage = \"$metaTextStartpage\";");
?>
<meta name="description" content="<? echo $metaTextStartpage;?>">
<meta name="keywords" content="<? echo $metaKeywordsStartpage;?>">
<?}?>
<? 
if($page =="impressum"){?>
		<meta name="robots" content="noindex, nofollow">
		<title><? echo $languageArray["Impressum"];?> - <?echo $websiteUrl;?></title>
	<?}?>
	
	<? //if($page =="kontakt"){?>
		<? /*
		<meta name="author" content="<? echo $websiteUrl;?>">
		<title>Kontakt - <?echo $websiteUrl;?></title>
		*/?>
	<?//}?>
	
	<? if($page =="datenschutzerklaerung"){?>
		<meta name="robots" content="noindex, nofollow">
		<title><? echo $languageArray["datenschutz"];?> - <?echo $websiteUrl;?></title>
	<?}?>
	
	<? if($page =="sitemap"){?>
    <title>Sitemap - <?echo $websiteUrl;?></title>
	<?}?>
	<?
	$url = substr($_SERVER[HTTP_HOST], 4);
	if (isset($_GET["q"]) != ""){
		try {
			$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
			$sql = 'SELECT * from page p, website w where p.websiteId = w.id and w.websiteUrl = "'.$url.'" and slug = "'.$_GET["q"].'"';
			$dbh->query("SET CHARACTER SET utf8");
			$row = $dbh->query($sql)->fetch();
			$slug = $row['slug'];
			$name = $row['name'];
			$dbh = null;
		} catch (PDOException $e) {
			print "Error!: " . $e->getMessage() . "<br/>";
			die();
		}
		
		$googleName = $row['googlename'];
	}
	?>
	<? if($page =="result"){?>

		<? if(isset($_GET['page']) and $_GET['page'] == 1){?>
			<? //ProductPage 1 
			
			$productPage_1_description = $languageArray["productPage_1_description"];
			eval("\$productPage_1_description = \"$productPage_1_description\";");
			
			$productPage_1_keywords = $languageArray["productPage_1_keywords"];
			eval("\$productPage_1_keywords = \"$productPage_1_keywords\";");
			
			$productPage_1_title = $languageArray["productPage_1_title"];
			eval("\$productPage_1_title = \"$productPage_1_title\";");
			
			?>
			<meta name="description" content="<? echo $productPage_1_description; ?>">
			<title><? echo $productPage_1_title; ?></title>
			<meta name="keywords" content="<? echo $productPage_1_keywords; ?>">

		<?}elseif(isset($_GET['page']) and $_GET['page'] == 2){?>
			<? //ProductPage 2 
			
			$productPage_2_description = $languageArray["productPage_2_description"];
			eval("\$productPage_2_description = \"$productPage_2_description\";");
			
			$productPage_2_keywords = $languageArray["productPage_2_keywords"];
			eval("\$productPage_2_keywords = \"$productPage_2_keywords\";");
			
			$productPage_2_title = $languageArray["productPage_2_title"];
			eval("\$productPage_2_title = \"$productPage_2_title\";");
			
			?>
			<meta name="description" content="<? echo $productPage_2_description;?>">
			<title><? echo $productPage_2_title; ?></title>
			<meta name="keywords" content="<? echo $productPage_2_keywords; ?>">

		<?}elseif(isset($_GET['page']) and $_GET['page'] == 3){?>
			<? //ProductPage 3
			
			$productPage_3_description = $languageArray["productPage_3_description"];
			eval("\$productPage_3_description = \"$productPage_3_description\";");
			
			$productPage_3_keywords = $languageArray["productPage_3_keywords"];
			eval("\$productPage_3_keywords = \"$productPage_3_keywords\";");
			
			$productPage_3_title = $languageArray["productPage_3_title"];
			eval("\$productPage_3_title = \"$productPage_3_title\";");
			
			?>
			<meta name="description" content="<? echo $productPage_3_description;?>">
			<title><? echo $productPage_3_title; ?></title>
			<meta name="keywords" content="<? echo $productPage_3_keywords; ?>">

		<?}elseif(isset($_GET['page']) and $_GET['page'] == 4){?>
			<? //ProductPage 4
			
			$productPage_4_description = $languageArray["productPage_4_description"];
			eval("\$productPage_4_description = \"$productPage_4_description\";");
			
			$productPage_4_keywords = $languageArray["productPage_4_keywords"];
			eval("\$productPage_4_keywords = \"$productPage_4_keywords\";");
			
			$productPage_4_title = $languageArray["productPage_4_title"];
			eval("\$productPage_4_title = \"$productPage_4_title\";");
			
			?>
			<meta name="description" content="<? echo $productPage_4_description;?>">
			<title><? echo $productPage_4_title; ?></title>
			<meta name="keywords" content="<? echo $productPage_4_keywords; ?>">

		<?}elseif(isset($_GET['page']) and $_GET['page'] == 5){?>
			<? //ProductPage 5
			
			$productPage_5_description = $languageArray["productPage_5_description"];
			eval("\$productPage_5_description = \"$productPage_5_description\";");
			
			$productPage_5_keywords = $languageArray["productPage_5_keywords"];
			eval("\$productPage_5_keywords = \"$productPage_5_keywords\";");
			
			$productPage_5_title = $languageArray["productPage_5_title"];
			eval("\$productPage_5_title = \"$productPage_5_title\";");
			
			?>
			<meta name="description" content="<? echo $productPage_5_description;?>">
			<title><? echo $productPage_5_title; ?></title>
			<meta name="keywords" content="<? echo $productPage_5_keywords; ?>">

		<?}else{?>
			<? //ProductPage Start
			
			$productPage_start_description = $languageArray["productPage_start_description"];
			eval("\$productPage_start_description = \"$productPage_start_description\";");
			
			
			$productPage_start_keywords = $languageArray["productPage_start_keywords"];
			eval("\$productPage_start_keywords = \"$productPage_start_keywords\";");
			
			$productPage_start_title = $languageArray["productPage_start_title"];
			eval("\$productPage_start_title = \"$productPage_start_title\";");
			?>
			<meta name="description" content="<? echo $productPage_start_description; ?>">
			<title><? echo $productPage_start_title; ?></title>
			<meta name="keywords" content="<? echo $productPage_start_keywords; ?>">
		<? }?>
	<?} // Ende Pageresult?>
	
	<meta name="google-site-verification" content="<? echo $googleVerification;?>" />
	<meta name="msvalidate.01" content="<? echo $bingVerification;?>" />
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="<? echo $websiteUrl;?>">

	<!-- Favicon
	<link rel="/shortcut icon" type="image/x-icon" href="favicon.ico" />
	<link rel="/icon" type="image/x-icon" href="favicon.ico" />	-->
	
<style>
	<?
	if($page == "result"){
		if ($rowWebsite["layout"] ==1){
			include("abovethefoldProductView4.php");
		}elseif	($rowWebsite["layout"] ==2){
			include("abovethefoldProductView2.php");
		}elseif	($rowWebsite["layout"] ==3){
			include("abovethefoldProductViewTable.php");
		}		
	}else{
		include("abovethefold.php");
	}?>
</style>
</head>