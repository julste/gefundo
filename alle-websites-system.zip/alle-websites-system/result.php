<? 
include ("credentials.php");

try {
 	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	
	$dbh->query("SET CHARACTER SET utf8");
	$sql = 'SELECT * from page p, website w where p.websiteId = w.id and w.websiteUrl = "'.$url.'" and  slug = "'.$_GET["q"].'"';
	$rowResult = $dbh->query($sql)->fetch();
	$slug = $rowResult['slug'];
	$amazonname = $rowResult['amazonname'];
	$googlename = $rowResult['googlename'];
    $dbh = null;
} catch (PDOException $e) {
   print "Error!: " . $e->getMessage() . "<br/>";
   die();
}

$url = $_SERVER['REQUEST_URI'];
$do_search = false;

if(strpos($url, "result.php") !== false)  {
	$do_search = true;
}


if($country == 'uk'){
	$currency = '£';
}else{	
	$currency = '€';	
}

if( $do_search == true or $slug != ""){?>

<!DOCTYPE html>
<html lang="<?echo $language;?>">
<? 
$page = "result"; 
include("head.php"); 
?>
<body>
	
<? 
include("nav.php");
include ("amazon_api5/SearchItems.php");

#include ("amazon/AmazonAPI.php");
#$amazonAPI = new AmazonAPI($keyId, $secretKey, $associateId);
#$amazonAPI->SetRetrieveAsArray();
#$amazonAPI->SetLocale($rowWebsite["country"]);´
?>

<div >
	<div class="container">	

<? 

if ($rowWebsite["layout"] == 1 ){
	include("ProductView4.php");
}elseif	($rowWebsite["layout"] == 2 ){
	include("ProductView2.php");
}elseif	($rowWebsite["layout"] == 3 ){
	include("ProductViewTable.php");
}		
	
?>
	</div>
<?	
include("footer.php"); 

?>

</div>
	
</body>
</html>

<?	
}else{
	header('HTTP/1.0 404 Not Found');
	include('404.php');
	exit();
}
?>
