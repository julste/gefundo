<!DOCTYPE html>
<html lang="de">
	<? include ("credentials.php");?>
	<? $page="datenschutzerklaerung"; ?>
	<? include( "head.php"); ?>
<body>
    <? include( "nav.php"); ?>
    <div style="padding-top: 80px; padding-bottom: 50px;">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-lg-12 col-md-12">
                <? 
					try {
						$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
						$sql = 'SELECT * from country where country = "'.$country.'"';
						$dbh->query("SET CHARACTER SET utf8");
						$rowCountry = $dbh->query($sql)->fetch();
						$dbh = null;
					} catch (PDOException $e) {
						print "Error: " . $e->getMessage() . "<br/>";
						die();
					}		
					include($rowCountry["privacyPolicy"]);
				?>
                </div>
                <? // ?>
            </div>
            <? // ?>
        </div>
    </div>
    <? include( "footer.php"); ?>
</body>
</html>