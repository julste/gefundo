﻿<div class="content-section-anfang">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" style="text-align:center">
                <div class="clearfix"></div>
                <h2 class="section-heading">Stoff123.de - Herzlich Willkommen!</h2>
                <p class="lead" style="text-align:justify">
				Wir helfen dir, schönen Stoff bequem online einzukaufen und dir direkt nach Hause liefern zu lassen. Du findest bei uns eine Vielzahl von unterschiedlichen Stoffen und Textilien. Egal ob du gemusterten Baumwollstoff oder einfarbigen Jersey kaufen möchtest, um für dich oder deine Kinder etwas zu nähen, oder ob du nach feinem Gardinenstoff für dein Zuhause suchst – bei uns wirst du sicher fündig! Außerdem bieten wir dir zahlreiche Möbelstoffe und Dekostoffe, darunter auch beschichtete Gewebe, die du problemlos draußen einsetzen kannst. Du suchst nach einem ganz speziellen Stoff, wie Leder, <a href="https://de.wikipedia.org/wiki/Chiffon" title="Chiffon">Chiffon</a>, Neopren, oder nach besonders hochwertigem Bio-Stoff? Auch diese besonderen Wünsche kannst du dir hier auf Stoff123 erfüllen.
				</p>

			   </div>
        </div>
    </div>
</div>
<a name="geschichte-des-stoffs"></a>
<div class="content-section-a">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" style="text-align:center">
                <div class="clearfix"></div>
                <h2 class="section-heading">Stoff – Geschichte, Tradition und Innovation</h2>
                <p class="lead" style="text-align:justify">
				Die Herstellung und Verarbeitung von textilen Stoffen ist eine Jahrtausende alte Kulturtechnik des Menschen. Die ältesten Überreste von menschengemachten Textilfasern wurden in Georgien gefunden und sollen ungefähr 30.000 Jahre alt sein. Lein, Flachs und Hanf waren die Hauptrohstoffe, die den Menschen in der Steinzeit zur Herstellung von Stoff dienten. 
				<br>
                <br>
				Während in den Anfängen der Menschheit Stoffe in Handarbeit gefertigt und nur für Bekleidung verwendet wurden, gibt es heute eine riesige Textilindustrie, die als einer der ältesten und wichtigsten Wirtschaftszweige des produzierenden Gewerbes gilt. Bis in die fünfziger Jahre hinein war Deutschland ein wichtiger Standort der Textilindustrie. Heute werden nur noch fünf Prozent der hierzulande verkauften Stoffe auch in Deutschland produziert. Stattdessen haben sich China, Indien und Bangladesch zu bedeutenden Textilherstellern entwickelt. Einzig die Sparte der sogenannten Technischen Textilien verzeichnet in Deutschland ein Wachstum. Technische Textilien sind Stoffe, die aufgrund ihrer funktionellen Eigenschaften eingesetzt werden und deren modischer oder optisch ästhetischer Charakter, wenn überhaupt, eine untergeordnete Rolle spielt – ganz im Gegensatz zu den textilen Stoffen, die im Bereich der Bekleidungs- und Heimtextilien verwendet werden.
				<br>
                <br>
				Dass diese dekorativen Stoffe nicht mehr nur in den Fabrikhallen der Bekleidungsindustrie, sondern zunehmend in den Arbeits- und Wohnzimmer der deutschen Bürger verarbeitet werden, ist einem Lifestyle zu verdanken, der sich seit einigen Jahren weltweit verbreitet: Do it yourself! Das angestaubte Image der Handarbeit gehört längst der Vergangenheit an – Selbstgemachtes liegt voll im Trend und gilt als cool und individuell. Neben Heimwerken, Basteln, Dekorieren und Upcycling erfreuen sich vor allem Nähen, Stricken und Häkeln neuer Beliebtheit. Diesen traditionellen, textilen Handarbeiten gehen in Deutschland fast 19 Millionen Menschen in ihrer Freizeit regelmäßig nach. Dass Frauen dabei in der großen Mehrheit sind, erstaunt nicht, obwohl es zunehmend auch Männer gibt, die sich dafür interessieren, ihre Kleidung oder Accessoires selbst herzustellen. Vor allem das selbst Nähen begeistert immer mehr Deutsche und ist inzwischen sogar beliebter als Stricken und Häkeln. Das kann auch daran festgemacht werden, dass der Absatz von Nähmaschinen, Stoffe und Kurzwaren bis zu acht Prozent zum Vorjahr gestiegen. 				
				</p>
            </div>
        </div>
    </div>
</div>
<a name="kleine-stoffkunde"></a>
<div class="content-section-b">
    <div class="container">
        <div class="row"> 
            <div class="col-lg-12" style="text-align:center">
                <div class="clearfix"></div>
                <h2 class="section-heading">Kleine Stoffkunde</h2>
                <p class="lead" style="text-align:justify">
				Grundsätzlich können alle textilen Stoffe in Naturfasern und Kunstfasern unterschieden werden. 
				<br>
                <br>
				Naturfasern können entweder pflanzlichen oder tierischen Ursprungs sein. Pflanzliche Naturfasern sind zum Beispiel Baumwolle, Leinen, Jute oder Hanf. Tierische Naturfasern umfassen zum einen die Wolle beziehungsweise Haare von Tieren, zum Beispiel Schurwolle, Kaschmir, Alpaka, Mohair, Kamelhaar. Zum anderen versteht man unter Stoffen tierischen Ursprungs auch Seide, die von verschiedenen Raupenarten produziert wird. Seit kurzem gibt es auch eine aus Milch gewonnene, moderne und neue Faser namens Polyactid, die sich ähnlich wie Seide anfühlt. 
                <br>
                <br>
				Kunstfasern können auch aus natürlichen Rohstoffen bestehen, die durch chemische Verfahren zu Stoff verarbeitet werden, dazu zählt zum Beispiel die aus Holz hergestellte Viskose. Andere Kunstfasern sind komplett synthetisch produziert. Für Bekleidungsstoff werden oft chemische Fasern wie Polyester, Polyamid (Nylon, Perlon) oder Elasthan verwendet.
                <br>
                <br>
				Im Handel werden vielfach verschiedene Fasern gemischt, um einem Stoff bestmögliche Eigenschaften zu verschaffen. So wird Baumwollgewebe häufig durch Elasthan ergänzt, um die Vorteile von Baumwolle (pflegeleicht, reißfest, robust, hautfreundlich, atmungsaktiv) mit der Dehnbarkeit von Kunstfasern zu kombinieren. 
				<br>
                <br>
				Wenn du noch nicht viel Erfahrung im Nähen hast, solltest du dich für die pflanzliche Naturfaser Baumwolle entscheiden, die im Gegensatz zu den meisten Synthetikstoffen unempfindlich gegen Hitze und aufgrund ihrer Reißfestigkeit sehr einfach zu verarbeiten ist. Weil die Baumwollfasern saugfähig und weich sind, bieten sie zudem ein besonders angenehmes Tragegefühl. Dabei können Baumwollstoffe nicht nur für Kleidungsstücke, wie Röcke benutzt werden, sondern auch für hübsche Kissenbezüge, kleine Täschchen oder dekorative Tischdecken. Weil es Baumwollstoffe in unzählbaren, verschiedenen Farben und Mustern und mit unterschiedlichen Motiven und Aufdrucken gibt, sind deiner Kreativität keine Grenzen gesetzt. Und da gerade bei Nähanfängern zu Beginn oft einiges schief geht, ist es auch finanziell gesehen die beste Entscheidung, günstige Baumwollstoffe online zu kaufen.
                <br>
                <br>
				Wenn ein Stoff zu hundert Prozent aus Baumwolle besteht, bedeutet das jedoch noch nicht, dass er für dein erstes Nähprojekt geeignet ist. Denn neben der Beschaffenheit der Fasern, also dem Stoffmaterial, spielt auch die Stoffausführung eine große Rolle. Das bedeutet, es kommt darauf an, wie ein Stoff hergestellt wird, ob es sich um eine gestrickte beziehungsweise gewirkte Maschenware handelt, oder um ein Gewebe. Während bei Maschenware ein oder mehrere Fäden mit Hilfe von Nadeln zu Maschen verschlungen werden, überkreuzen sich bei einem gewebten Stoff zwei Fäden rechtwinklig. Die verschiedenen Gewebearten werden nach ihrer Webart unterschieden. So gibt es eine Vielzahl von Bezeichnungen für gewebte Stoffe, zum Beispiel <a href="https://de.wikipedia.org/wiki/Chiffon" title="Chiffon">Chiffon</a>, Cord, <a href="https://de.wikipedia.org/wiki/Tweed_(Gewebe)" title="Tweed">Tweed</a>, Damast, <a href="https://de.wikipedia.org/wiki/Taft_(Gewebe)" title="Taft">Taft</a>, <a href="https://de.wikipedia.org/wiki/Gabardine" title="Gabardine">Gabardine</a>, <a href="https://de.wikipedia.org/wiki/Popeline" title="Popeline">Popeline</a>, Satin, Mesh oder Flanell – und das sind nur einige der zahlreichen Webstoffe, die du hier auf Stoff123 finden kannst.  
				<br>
                <br>
				Ein gestrickter Stoff aus Baumwolle wird Jersey genannt – Jersey zählt zu den beliebtesten Stoffqualitäten und ist in unzähligen Farben und Mustern erhältlich. Strickstoffe sind im Vergleich zu Webstoffen meist schwerer, dehnbarer und schwerer. Für Nähanfänger eignen sich deshalb besonders gewebte Baumwollstoffe, die sich einfach zuschneiden und verarbeiten lassen. Auf Stoff123 helfen wir dir, einen schönen Stoff für deine Nähprojekte auszusuchen. 
				</p>	
				</div>
        </div>
    </div>
</div>
<a name="stoffklassiker"></a>
<div class="content-section-a">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" style="text-align:center">
                <div class="clearfix"></div>
                <h3 class="section-heading">Stoffklassiker</h3>
                <p class="lead" style="text-align:justify">
				Ganz egal ob du Möbelstoff, Dekorationsstoffe, Kinderstoffe oder Bekleidungsstoffe für Erwachsene suchst – in allen Bereichen gibt es jedes Jahr neue Stofftrends, aber auch Klassiker, die nie aus der Mode kommen und mit denen man nichts falsch machen kann.
				<br>
                <br>
				Einer der größten Stoffklassiker ist mit Sicherheit das Karomuster, das du auf Stoff123 in vielen Varianten finden kannst. Wir stellen dir hier die bekanntesten Karo-Muster einmal vor:
				<br>
                <br>
				Das schottische Tartanmuster verleiht deinem Zuhause einen gediegenes, edles Flair, wenn du es für Heimtextilien wie Kissenhüllen verwendest. Auch für Wintermäntel und Kleider eignet sich der Stoff mit den großen Karos in gedeckten Farben hervorragend. Das britische Muster muss jedoch nicht nur klassisch dahergekommen – als Flanellhemd ist es ein typisches Kleidungsstück der Grunge-Szene
				<br>
                <br>
				Ebenso typisch britisch wirken Stoffe mit Argyle-Karos, einem Muster, das vor allem von Strümpfen und Socken bekannt ist. Einen ähnlich adretten, so genannten „preppy“, Look erzeugen Stoffe im karierten Glencheck- oder Prince-of-Wales-Muster, das oft bei Hemden, Krawatten oder Tagesanzüge zu finden ist. 
				<br>
                <br>
				Ein weiteres beliebtes Muster für Herrenhemden und Damenblusen ist das Vichy-Karo. In Pastellfarben gehalten, wird es außerdem oft für Heimtextilien im englischen Landhausstil verwendet, während der karierte Stoff in kräftigeren Farben ideal fürs Nähen von Dirndln oder Kinderkleidung ist. Vichy-Karos in leuchtendem Rot sind außerdem typisch für den rustikalen italienischen Stil und eignen sich ideal für Gardinenstoffe, zum Nähen von Tischdecken oder Kissenbezügen. 
				<br>
				<br>
				Neben dem Vichy-Karo sind auch Stoffe mit Vichy-Streifen ein Dauerbrenner bei Kinderkleidung und für die Gestaltung von individuellen Patchwork-Arbeiten – ebenso wie gepunktete Stoffe. Schöne Stoffe mit Polka Dots in unterschiedlichen Größen und Farben sind ein Klassiker für Damenbekleidung und Accessoires und können hier auf Stoff123 in einer großen Vielzahl ausgewählt werden. 
				<br>
				<br>
				Ein klassisches Muster, das jedem Kleidungsstück einen eleganten, französischen Touch verleiht, ist der Hahnentritt beziehungsweise das sehr ähnliche Pepita. Obgleich diese Muster immer in schlichtem schwarz und weiß gehalten sind, wirken Mäntel, Röcke oder Kleider aus Stoff mit Hahnentritt- oder Pepita-Muster sehr raffiniert und très chic. Und du kannst nicht nur Kleidungsstücke mit diesen Musterungen wählen – auch schönen Stoff für Möbelbezüge oder Kissenhüllen im Stil von Coco Chanel findest du hier auf Stoff123.
				<br>
				<br>
				Etwas exotischer, aber ebenso traditionell kommt das verspielte Paisleymuster daher. Dieses abstrakte Muster, das ein seiner Grundform ein spitz zulaufendes, geschwungenes Blatt darstellt, hat seinen Ursprung in Indien. Von dort aus brachten es britische Soldaten in der Mitte des 19. Jahrhunderts nach Europa, wo Paisley schnell zu einem absoluten Modetrend avancierte. Paisley-Stoff gibt es mittlerweile in vielen verschiedenen Farben, auch wenn das florale Muster traditionell in Rot-Tönen gehalten ist, und ziert nicht nur Schals, Tücher, Krawatten und Tuniken, sondern auch Heimtextilien wie Sofakissen und Polsterstoffe. 
				<br>
				<br>
				Neben Paisleystoff gibt es noch viele weitere florale Muster, die zu den Stoff-Klassikern gehören. Gedruckte Rosen und andere großflächige Blumenprints sind die klassischen Muster des gemütlichen Landhaus-Stils. Vor allem Kissenbezüge und Gardinen beziehungsweise Vorhänge werden aus diesen romantischen Stoffen genäht. Doch auch für ein Kleid im Look der fünfziger Jahre oder für ein Halstuch kannst du schöne Stoffe mit Blumenmustern verwenden – eine große Auswahl bieten wir dir hier auf Stoff123. Kleinteiligere Streublümchen-Musterstoffe sind ein Klassiker wenn es um Kinderbekleidung geht – vor allem Sommerkleider für Mädchen mit Blumenmuster sind süß anzusehen und einfach zu nähen.
				<br>
				<br>
				Zuletzt wollen wir euch einen klassischen Stoff vorstellen, der vor allem in Deutschland Tradition hat: Der Westfalenstoff. Sicher hast auch du noch Kindheitserinnerungen an das Kästchenmuster mit den niedlichen Tieren und Symbolen, das bereits in den dreißiger Jahren entwickelt und vom Stil des Bauhaus und des Künstlers Paul Klee inspiriert ist. Die zweifarbigen Westfalenstoffe haben jedoch bis heute nichts von ihrer Ausdruckskraft eingebüßt, sind ein zeitloser Klassiker, der von Traditionsbewusstsein und Schnörkellosigkeit zeugt. Kinderkleidung, aber auch Heimtextilien wie Tischdecken, Vorhänge, Patchwork-Arbeiten oder Handtücher werden gestern wie heute aus Westfalenstoff genäht.
				</p>
            </div>
        </div>
    </div>
</div>

<div class="banner">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <h2>Stoffe für jedermann!</h2> </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
</div>