<nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
    <div class="container topnav">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            <div style="padding-top:5px; padding-bottom: 5px;">
                <a href="/" title="stoff123.de"> <img src="/img/stoff123-logo.gif" title="Schöne Stoffe online finden!" alt="Stoff online - Finde online deinen Wuschstoff" class="img-responsive" /></a>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="padding-top:8px;">
            <ul class="nav navbar-nav navbar-right">
                <li> <a href="/#geschichte-des-stoffs" title="Geschichte des Stoffs">Geschichte des Stoffs</a> </li>
                <li> <a href="/#kleine-stoffkunde" title="Kleine Stoffkunde">Kleine Stoffkunde</a> </li>
                <li> <a href="/#stoffklassiker" title="Stoffklassiker">Stoffklassiker</a> </li>
            </ul>
        </div>
    </div> 
</nav>