<!-- Footer -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="list-inline footer-mittig">
					<li>
						<a href="/datenschutzerklaerung" class="footer-link" title="Datenschutzerklärung von stoff123.de">Datenschutzerklärung</a>
					</li>	
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/impressum" class="footer-link" title="Impressum von stoff123.de" >Impressum</a>
					</li>
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/sitemap" class="footer-link" title="Sitemap von stoff123.de">Sitemap</a>
					</li>
				</ul>
				<p class="copyright text-muted small footer-mittig">Copyright &copy; stoff123.de <?php echo date("Y"); ?></p>
			</div>
		</div>
	</div>
</footer>
<!-- Bootstrap Core CSS -->
<link href="/css/bootstrap.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="/css/landing-page.css" rel="stylesheet">
<!-- Custom Fonts -->
<link href="/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
<!-- Loadbar -->
<link href="/css/pace.min.css" rel="stylesheet">
<script src="/js/jquery-ui.min.js" type="text/javascript"></script>
<script src="/js/priceSlider.js" type="text/javascript"></script>
<script src="/js/default.js" type="text/javascript"></script>
<? /*
<!-- jQuery -->
<script src="/js/jquery.js" type="text/javascript"></script>
<!-- Bootstrap Core JavaScript -->
<script src="/js/bootstrap.min.js" type="text/javascript"></script>
<!-- Loadbar -->
<script src="/js/pace.min.js" type="text/javascript"></script>
<!-- Scroll to top Button -->
<script src="/js/scrolltotop.js" type="text/javascript"></script>
*/ ?> 
  <script>
$('a.modalButton').on('click', function(e) {
    var src = $(this).attr('data-src');
    var height = $(this).attr('data-height') || 400;
    var width = $(this).attr('data-width') || 500;
    $("#myModal iframe").attr({'src':src});
});
function chkFormular() {
  if (document.Formular.q.value == "") {
	      document.Formular.q.focus();
    return false;
  }else{
	return true;  
  }
}
</script>
<!-- Piwik 
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(["setDomains", ["*.www.stoff123.de"]]);
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.stoff123.de/analytics/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', '1']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//www.stoff123.de/analytics/piwik.php?idsite=1" style="border:0;" alt="" /></p></noscript>
End Piwik Code -->

<!-- Matomo -->
<script type="text/javascript">
  var _paq = window._paq = window._paq || [];
  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//www.tagesdecken-24.de/site-admin/piwik/";
    _paq.push(['setTrackerUrl', u+'matomo.php']);
    _paq.push(['setSiteId', '50']);
    _paq.push(['appendToTrackingUrl', 'bots=1']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Matomo Code -->
<!-- Matomo Image Tracker-->
<noscript>
<img src="https://www.tagesdecken-24.de/site-admin/piwik/matomo.php?idsite=50&bots=1&amp;rec=1" style="border:0" alt="" />
</noscript>
<!-- End Matomo -->
