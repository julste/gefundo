<a name="about"></a>
<div class="intro-header">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <br>
                <h1 class="hidden-xs pull-left"> Schöne Stoffe online <br> finden!</h1>
                <div class="intro-message">
                    <form action="/result.php" method="GET" class="form-group" name="Formular" role="search" onsubmit="return chkFormular();">
                        <div class="input-group col-xs-10 col-sm-8 col-md-8 col-lg-8 col-xs-offset-1 col-sm-offset-2 col-md-offset-2 searchbar">
                            <input type="text" class="form-control input-lg" placeholder="Suche nach Stoff, Muster, Farbe und mehr..." name="q">
                            <div class="input-group-btn">
                                <button class="btn btn-success btn-lg" type="submit"> <i class="glyphicon glyphicon-search"></i> </button>
                            </div>
                        </div>
                    </form>
                    <div class="hidden-xs col-xs-8 col-lg-8 col-xs-offset-2 col-md-offset-2" style="background-color:rgba(0, 0, 0, 0.7);">
                        <h4 class="startseite-linkfenster"> <a class="startseite" href="weihnachten"title="Stoff Weihnachten">Weihnachten</a> | <a class="startseite" href="kinder" title="Stoff Kinder">Kinderstoffe</a> | <a class="startseite" href="vorhangstoff" title="Vorhangstoff">Vorhangstoff</a> | <a class="startseite" href="moebelstoff" title="Möbelstoff">Möbelstoff</a> | <a class="startseite" href="weinrot" title="Stoff Weinrot">Weinrot</a> | <a class="startseite" href="mint" title="Stoff Mint">Mint</a> | <a class="startseite" href="eulen" title="Stoff Eulen">Eulen</a> | <a class="startseite" href="kariert" title="Stoff Kariert">Kariert</a></h4> </div>
                </div>
            </div>
        </div>
    </div>
</div>