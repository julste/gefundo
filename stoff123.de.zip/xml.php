<?php    
    /* create a dom document with encoding utf8 */
    $domtree = new DOMDocument('1.0', 'UTF-8');

    /* create the root element of the xml tree */
    $xmlRoot = $domtree->createElementNS('http://www.sitemaps.org/schemas/sitemap/0.9', 'urlset');
    /* append it to the document created */
    $xmlRoot = $domtree->appendChild($xmlRoot);

    $currentTrack = $domtree->createElement("url");
    $currentTrack = $xmlRoot->appendChild($currentTrack);

    /* you should enclose the following two lines in a cicle */
    $currentTrack->appendChild($domtree->createElement('loc','https://www.stoff123.de/'));

    try {
		$user = "stoff123_de";
		$pass = "DUFRcgyz";
		$dbh = new PDO('mysql:host=stoff123.de.mysql;dbname=stoff123_de', $user, $pass);
		$dbh->query("SET CHARACTER SET utf8");
		$sql = 'SELECT * from stoff123_page where category = "Farbe"';
		foreach($dbh->query($sql) as $row){
			
		$currentTrack = $domtree->createElement("url");
		$currentTrack = $xmlRoot->appendChild($currentTrack);
		$currentTrack->appendChild($domtree->createElement('loc','https://www.stoff123.de/'.$row['slug']));
	}

		$dbh = null;
	} catch (PDOException $e) {
	   //print "Error!: " . $e->getMessage() . "<br/>";
	   die();
	}	
	
	    try {
		$user = "stoff123_de";
		$pass = "DUFRcgyz";
		$dbh = new PDO('mysql:host=stoff123.de.mysql;dbname=stoff123_de', $user, $pass);
		$dbh->query("SET CHARACTER SET utf8");
		$sql = 'SELECT * from stoff123_page where category = "Muster"';
		foreach($dbh->query($sql) as $row){
			
		$currentTrack = $domtree->createElement("url");
		$currentTrack = $xmlRoot->appendChild($currentTrack);
		$currentTrack->appendChild($domtree->createElement('loc','https://www.stoff123.de/'.$row['slug']));
	}

		$dbh = null;
	} catch (PDOException $e) {
	   //print "Error!: " . $e->getMessage() . "<br/>";
	   die();
	}	
	
	    try {
		$user = "stoff123_de";
		$pass = "DUFRcgyz";
		$dbh = new PDO('mysql:host=stoff123.de.mysql;dbname=stoff123_de', $user, $pass);
		$dbh->query("SET CHARACTER SET utf8");
		$sql = 'SELECT * from stoff123_page where category = "Motiv"';
		foreach($dbh->query($sql) as $row){
			
		$currentTrack = $domtree->createElement("url");
		$currentTrack = $xmlRoot->appendChild($currentTrack);
		$currentTrack->appendChild($domtree->createElement('loc','https://www.stoff123.de/'.$row['slug']));
	}

		$dbh = null;
	} catch (PDOException $e) {
	   //print "Error!: " . $e->getMessage() . "<br/>";
	   die();
	}	
	
	    try {
		$user = "stoff123_de";
		$pass = "DUFRcgyz";
		$dbh = new PDO('mysql:host=stoff123.de.mysql;dbname=stoff123_de', $user, $pass);
		$dbh->query("SET CHARACTER SET utf8");
		$sql = 'SELECT * from stoff123_page where category = "Stoffart"';
		foreach($dbh->query($sql) as $row){
			
		$currentTrack = $domtree->createElement("url");
		$currentTrack = $xmlRoot->appendChild($currentTrack);
		$currentTrack->appendChild($domtree->createElement('loc','https://www.stoff123.de/'.$row['slug']));
	}

		$dbh = null;
	} catch (PDOException $e) {
	   //print "Error!: " . $e->getMessage() . "<br/>";
	   die();
	}	
	
	    try {
		$user = "stoff123_de";
		$pass = "DUFRcgyz";
		$dbh = new PDO('mysql:host=stoff123.de.mysql;dbname=stoff123_de', $user, $pass);
		$dbh->query("SET CHARACTER SET utf8");
		$sql = 'SELECT * from stoff123_page where category = "Merkmal"';
		foreach($dbh->query($sql) as $row){
			
		$currentTrack = $domtree->createElement("url");
		$currentTrack = $xmlRoot->appendChild($currentTrack);
		$currentTrack->appendChild($domtree->createElement('loc','https://www.stoff123.de/'.$row['slug']));
	}

		$dbh = null;
	} catch (PDOException $e) {
	   //print "Error!: " . $e->getMessage() . "<br/>";
	   die();
	}	

	    try {
		$user = "stoff123_de";
		$pass = "DUFRcgyz";
		$dbh = new PDO('mysql:host=stoff123.de.mysql;dbname=stoff123_de', $user, $pass);
		$dbh->query("SET CHARACTER SET utf8");
		$sql = 'SELECT * from stoff123_page where category = "Marke"';
		foreach($dbh->query($sql) as $row){
			
		$currentTrack = $domtree->createElement("url");
		$currentTrack = $xmlRoot->appendChild($currentTrack);
		$currentTrack->appendChild($domtree->createElement('loc','https://www.stoff123.de/'.$row['slug']));
	}

		$dbh = null;
	} catch (PDOException $e) {
	   //print "Error!: " . $e->getMessage() . "<br/>";
	   die();
	}	
	
    $domtree->save("sitemap2.xml");
?>