<head>
<style>
<?
if($page == "result"){
	include("abovethefoldResult.php");
}else{
	include("abovethefold.php");
}
?>
</style>
	<? if($page =="index"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Stoffe in vielen verschiedenen Farben, Mustern und mehr! Jetzt auf Stoff123.de online deinen Wunschstoff finden und dein nächstes Projekt kann beginnen!">
	<meta name="keywords" content="stoff, Stoff, Filz, online, Stoffe, Schön, günstig">
    <meta name="author" content="Stoff123.de">
    <title>Stoffe online finden - Ganz einfach auf Stoff123.de!</title>
	<?}?>
	<? if($page =="impressum"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Stoff123.de">
	<meta name="robots" content="noindex, nofollow">
    <title>Stoff 123 - Impressum</title>
	<?}?>
	<? if($page =="kontakt"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Stoff123.de">
    <title>Stoff 123 - Kontakt</title>
	<?}?>
	<? if($page =="datenschutzerklaerung"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Stoff123.de">
	<meta name="robots" content="noindex, nofollow">
    <title>Stoff 123 - Datenschutzerklärung</title>
	<?}?>
	<? if($page =="sitemap"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Stoff123.de">
    <title>Stoff 123 - Sitemap</title>
	<?}?>
	<?
	 try {
	$user = "stoff123_de";
	$pass = "DUFRcgyz";
	$dbh = new PDO('mysql:host=Stoff123.de.mysql;dbname=stoff123_de', $user, $pass);
	$sql = 'SELECT * from stoff123_page where slug = "'.$_GET["q"].'"';
	$dbh->query("SET CHARACTER SET utf8");
	$row = $dbh->query($sql)->fetch();
	$slug = $row['slug'];
	$searchname = $row['searchname'];
	$googlename = $row['googlename'];
	$category = $row['category'];
    $dbh = null;
} catch (PDOException $e) {
   //print "Error!: " . $e->getMessage() . "<br/>";
   die();
}
	?>
	<? if($page =="result"){?>
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
    	<meta name="author" content="Stoff123.de">
	<? if($row['category'] == "Farbe"){
		if($_GET['page'] == 1){?>
		<meta name="description" content="Stoff in <? echo $row['googlename']; ?> online finden auf Stoff123.de - Riesige Auswahl an Stoffen in <? echo $row['googlename']; ?> . Schnell und einfach deinen neuen Lieblingsstoff online auswählen!">
		<title>Stoff in <? echo $row['googlename']; ?> und in weiteren Farben - Jetzt finden auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, kaufen, Farbe">
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content="Stoff in <? echo $row['googlename']; ?> so weit das Auge reicht! Auf Stoff123.de findest du günstige Angebote für hochwertige Stoffe in <? echo $row['googlename']; ?> und vielen anderen tollen Farben.">
		<title>Günstige Stoffe in <? echo $row['googlename']; ?> - online auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, kaufen, Farbe">
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content="Wunderschöne Stoffe in <? echo $row['googlename']; ?> kannst du auf Stoff123.de online auswählen. Hier findest du eine tolle Auswahl an Stoffen in <? echo $row['googlename']; ?> und vielen anderen Farben.">
		<title><? echo $row['googlename']; ?> - eine tolle Farbe für Stoffe - hier auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, kaufen, Farbe">
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content="Du suchst Stoff in <? echo $row['googlename']; ?>? Auf Stoff123.de findest du eine riesige Auswahl an schönen Stoffen in <? echo $row['googlename']; ?> zu günstigen Preisen in hervorragender Qualität!">
		<title>Tolle Stoffe in <? echo $row['googlename']; ?> - online auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, kaufen, Farbe">
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content="Schöne Stoffe in <? echo $row['googlename']; ?> online zu dir nach Hause bestellen. Auf Stoff123.de findest du Stoffe in <? echo $row['googlename']; ?> und vielen anderen Farben zu günstigen Preisen.">
		<title>Schöne Stoffe in <? echo $row['googlename']; ?> - Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, kaufen, Farbe">
		<?}else{?>
		<meta name="description" content="Tolle Stoffe in <? echo $row['googlename']; ?> und vielen anderen schönen Farben kannst du hier schnell und einfach online aussuchen. Dein neuer Stoff in <? echo $row['googlename']; ?> wartet auf dich!">
		<title><? echo $row['googlename']; ?> und viele andere Farben - Stoffe online auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, kaufen, Farbe">
		<? }?>
	<?}elseif($row['category'] == "Muster"){?>
		<?if($_GET['page'] == 1){?>
		<meta name="description" content='Stoff in der Variante <? echo $row['googlename']; ?> ist das was du suchst? Finde auf hier deinen Stoff in der Variante <? echo $row['googlename']; ?> oder mit schönen anderen Mustern!'>
		<title>Stoff mit dem Muster <? echo $row['googlename']; ?> - schön und günstig auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Muster, schön">
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content='Du suchst Stoffe im Muster <? echo $row['googlename']; ?>? Sieh dich auf Stoff123.de um und finde deinen neuen Stoff mit dem Muster <? echo $row['googlename']; ?> zu günstigen Preisen.'>
		<title>Stoffe in der Variante <? echo $row['googlename']; ?> - online auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Muster, schön">
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content='Stoffe in der Variante <? echo $row['googlename']; ?> und viele weitere Musterstoffe findest du auf Stoff123.de. Günstige Preise und tolle Angebote - finde deinen neuen Stoff mit dem Muster <? echo $row['googlename']; ?>.'>
		<title><? echo $row['googlename']; ?> - ein tolles Stoffmuster - online auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Muster, schön">
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content='Günstige Stoffe mit dem Muster <? echo $row['googlename']; ?> kannst du auf Stoff123.de finden. Die Variante <? echo $row['googlename']; ?> und viele andere Muster jetzt hier bei uns.'>
		<title>Musterstoffe online finden - zum Beispiel <? echo $row['googlename']; ?></title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Muster, schön">
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content='Du suchst nach Stoffen in der Variante <? echo $row['googlename']; ?> - schau auf stoff 123.de vorbei. Hier findest du Stoffe in der Variante <? echo $row['googlename']; ?> und vieles mehr.'>
		<title>Schöne Stoffe mit dem Muster <? echo $row['googlename']; ?> - auf Stoff123.de!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Muster, schön">
		<?}else{?>
		<meta name="description" content='Tolle Stoffe in der Variante <? echo $row['googlename']; ?> online finden auf Stoff123.de. Hier kannst du schnell und einfach Stoffe in der Variante <? echo $row['googlename']; ?> raussuchen.'>
		<title><? echo $row['googlename']; ?> und weitere Muster - Stoffe online auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Muster, schön">
		<?}?>
	<? }elseif($row['category'] == "Motiv"){?>
		<?if($_GET['page'] == 1){?>
		<meta name="description" content='Du suchst nach Stoff mit dem Motiv <? echo $row['googlename']; ?>? Hier findest du tolle Angebote und viele schöne Motive - natürlich auch <? echo $row['googlename']; ?> - komm vorbei!'>
		<title>Schöne Stoffe mit dem Motiv <? echo $row['googlename']; ?> - hier auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Motiv, toll">
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content='Toller Stoff mit dem Motiv <? echo $row['googlename']; ?> gesucht? Komm vorbei und finde deinen neuen Stoff mit dem Motiv <? echo $row['googlename']; ?> zu einem günstigen Preis!'>
		<title>Motivstoffe online - <? echo $row['googlename']; ?> und vieles mehr auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Motiv, toll">
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content='Stoffe mit dem Motiv <? echo $row['googlename']; ?> online auf Stoff123.de - tolle Angebote und schöne Motive, zum Beispiel <? echo $row['googlename']; ?>, findest du hier! '>
		<title><? echo $row['googlename']; ?> - Motivstoffe zu günstigen Preisen auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Motiv, toll">
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content='<? echo $row['googlename']; ?> und andere schöne Motive findest du bei uns! Stoff soweit das Auge reicht und viele Motive - zum Beispiel <? echo $row['googlename']; ?>. Schau vorbei!'>
		<title>Stoff mit dem Motiv <? echo $row['googlename']; ?> gesucht? - Stoff123.de hilft dir!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Motiv, toll">
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content='Auf Stoff123.de findest du schönen Stoff mit dem Motiv <? echo $row['googlename']; ?> und vieles mehr. Dein neuer Stoff mit dem Motiv <? echo $row['googlename']; ?> wartet auf dich!'>
		<title><? echo $row['googlename']; ?> und andere Motive - online günstig Stoff kaufen!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Motiv, toll">
		<?}else{?>
		<meta name="description" content='Stoff mit dem Motiv <? echo $row['googlename']; ?> findest du hier zu günstigen Preisen. <? echo $row['googlename']; ?> und viele andere Motive - lass dich inspirieren auf Stoff123.de!'>
		<title><? echo $row['googlename']; ?> - ein tolles Stoffmotiv - online auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Motiv, toll">
		<?}?>
	<? }elseif($row['category'] == "Stoffart"){?>	
		<?if($_GET['page'] == 1){?>
		<meta name="description" content='Du suchst nach <? echo $row['googlename']; ?>? Bei uns findest du Stoff in schönen Farben zu günstigen Preisen - <? echo $row['googlename']; ?> und vieles mehr!'>
		<title><? echo $row['googlename']; ?> - tolle Angebote auf Stoff123.de!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Stoffart, toll">
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content='<? echo $row['googlename']; ?> findest du bei uns online! <? echo $row['googlename']; ?>, schön und günstig, wartet auf Stoff123.de auf dich - lass dich überraschen!'>
		<title><? echo $row['googlename']; ?> - Stoff123.de hat eine große Auswahl für dich!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Stoffart, toll">
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content='Auf Stoff123.de findest du was du suchst - <? echo $row['googlename']; ?>! Tolle Angebote für <? echo $row['googlename']; ?> und andere Stoffe - schau doch einfach mal vorbei!'>
		<title>Stoff online finden - zum Beispiel <? echo $row['googlename']; ?>!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Stoffart, toll">
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content='Du suchst <? echo $row['googlename']; ?>? Auf Stoff123.de wirst du fündig! <? echo $row['googlename']; ?> und viele andere schöne Stoffe zu tollen Preisen findest du bei uns!'>
		<title><? echo $row['googlename']; ?>- große Auswahl, günstige Preise!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Stoffart, toll">
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content='<? echo $row['googlename']; ?> und viele schöne andere Stoffe - online auf Stoff123.de! Lass dich inspirieren und finde bei uns <? echo $row['googlename']; ?> und vieles mehr!'>
		<title>Auf der Suche nach <? echo $row['googlename']; ?>?</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Stoffart, toll">
		<?}else{?>
		<meta name="description" content='Wir bieten dir eine große Auswahl an <? echo $row['googlename']; ?> zu günstigen Preisen. <? echo $row['googlename']; ?> und viele andere Stoffe sind nur einen Klick entfernt!'>
		<title><? echo $row['googlename']; ?> - ganz einfach online finden - auf Stoff123.de</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Stoffart, toll">
		<?}?>		
	<? }elseif($row['category'] == "Merkmal"){?>	
		<?if($_GET['page'] == 1){?>
		<meta name="description" content='<? echo $row['googlename']; ?> - Stoffe mit diesem und vielen anderen Merkmalen bieten wir dir hier.  Klick rein und finde deinen Stoff - <? echo $row['googlename']; ?>!'>
		<title>Stoff mit dem Merkmal <? echo $row['googlename']; ?> findest du auf stoff123.de!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Merkmal, schön">
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content='<? echo $row['googlename']; ?> - diese Eigenschaft soll dein neuer Stoff haben? Auf stoff123.de gibt es viele schöne Stoffe mit dem Merkmal <? echo $row['googlename']; ?>!'>
		<title>Günstig online finden - Stoff <? echo $row['googlename']; ?> auf stoff123.de!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Merkmal, schön">
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content='Auf stoff123.de wartet eine große Auswahl an Stoff mit dem Merkmal <? echo $row['googlename']; ?> auf dich. Finde hier deinen Stoff mit dem Merkmal <? echo $row['googlename']; ?>!'>
		<title>Stoff mit dem Attribut Schwer Entflammbar günstig online finden!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Merkmal, schön">
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content='Große Auswahl, Günstige Preise - Stoff mit dem Merkmal <? echo $row['googlename']; ?> online finden. <? echo $row['googlename']; ?> - dies und mehr online auf stoff123.de'>
		<title>Schöner Stoff mit der Eigenschaft <? echo $row['googlename']; ?></title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Merkmal, schön">
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content='Stoff mit dem Merkmal <? echo $row['googlename']; ?> wartet auf stoff123.de auf dich! Günstige Preise und schöne Stoffe - komm vorbei und lass dich überraschen!'>
		<title>Finde deinen Stoff mit dem Merkmal <? echo $row['googlename']; ?> online!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Merkmal, schön">
		<?}else{?>
		<meta name="description" content='Stoff123.de hilft dir, Stoff mit dem Merkmal <? echo $row['googlename']; ?> zu finden. Tolle Preise und dein Stoff mit dem Merkmal <? echo $row['googlename']; ?> warten auf dich!'>
		<title><? echo $row['googlename']; ?> - diese und andere Stoffe online!</title>
		<meta name="keywords" content="Stoff, <? echo $row['googlename']; ?>, online, Merkmal, schön">
		<?}?>		
	<? }elseif($row['category'] == "Marke"){?>		
		<?if($_GET['page'] == 1){?>
		<meta name="description" content='Suchst du nach Stoff von <? echo $row['googlename']; ?>? Dann bist du hier genau richtig! Stoff von <? echo $row['googlename']; ?> und vielen anderen Marken findest du bei stoff123.de!'>
		<title>Dein neuer Stoff von <? echo $row['googlename']; ?> auf stoff123.de!</title>
		<meta name="keywords" content="Stoff, Marken, <? echo $row['googlename']; ?>, online, günstig">
		<?}elseif($_GET['page'] == 2){?>
		<meta name="description" content='Du kannst von Stoffen der Marke <? echo $row['googlename']; ?> auch nicht genug bekommen? Dann schau vorbei und finde Stoff von <? echo $row['googlename']; ?> und vielen anderen Marken!'>
		<title>Schöne Stoffe von <? echo $row['googlename']; ?> - auf stoff123.de online finden!</title>
		<meta name="keywords" content="Stoff, Marken, <? echo $row['googlename']; ?>, online, günstig">
		<?}elseif($_GET['page'] == 3){?>
		<meta name="description" content='Deine Suche nach Stoffen der Marke <? echo $row['googlename']; ?> hat jetzt ein Ende - wir haben eine riesige Auswahl an schönen Markenstoffen für dich! Komm vorbei!'>
		<title><? echo $row['googlename']; ?> online finden - auf stoff123.de!</title>
		<meta name="keywords" content="Stoff, Marken, <? echo $row['googlename']; ?>, online, günstig">
		<?}elseif($_GET['page'] == 4){?>
		<meta name="description" content='Dein neuer Stoff von <? echo $row['googlename']; ?> ist nur noch einen Klick entfernt! Bei uns findest du Stoff der Marke <? echo $row['googlename']; ?> und andere Marken ganz leicht!'>
		<title>Günstiger Stoff von <? echo $row['googlename']; ?> - online auf stoff123.de!</title>
		<meta name="keywords" content="Stoff, Marken, <? echo $row['googlename']; ?>, online, günstig">
		<?}elseif($_GET['page'] == 5){?>
		<meta name="description" content='Stoffe der Marke <? echo $row['googlename']; ?> warten auf stoff123.de auf dich! Günstige Preise und schöne Stoffe von <? echo $row['googlename']; ?> - komm vorbei!'>
		<title>Finde deinen Stoff der Marke <? echo $row['googlename']; ?> einfach online!</title>
		<meta name="keywords" content="Stoff, Marken, <? echo $row['googlename']; ?>, online, günstig">
		<?}else{?>
		<meta name="description" content='Auf stoff123.de findest du eine große Auswahl an Stoffen von <? echo $row['googlename']; ?> und anderen Marken. Dein neuer Stoff von <? echo $row['googlename']; ?> wartet schon auf dich!'>
		<title><? echo $row['googlename']; ?> und viele andere Marken - finde deinen Stoff online!</title>
		<meta name="keywords" content="Stoff, Marken, <? echo $row['googlename']; ?>, online, günstig">
		<?}?>	
	<?} // Ende ElseIF?>	
	<?} // Ende Pageresult?>
	<? /*
    <!-- Bootstrap Core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="/css/landing-page.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="/css/font-awesome-corp.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
	<!-- Loadbar -->
    <link href="/css/pace.min.css" rel="stylesheet">
	*/ ?>
	<!-- Scroll to top Button -->
	<!--<a class="scrollicon" title="zum Seitenanfang" href="#" style="display: inline;"><div>&Lambda;</div></a>-->
	<a class="scrollicon" title="zum Seitenanfang" href="#" style="display: inline;"><div><i class="fa fa-arrow-circle-up"></i></div></a>
	<? /*
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    */ ?>
	<!-- Favicon -->
	<link rel="/shortcut icon" type="image/x-icon" href="favicon.ico" />
	<link rel="/icon" type="image/x-icon" href="favicon.ico" />
</head>