body,
html {
  width: 100%;
  height: 100%;
}

body,
h1,
h2,
h4 {
  font-family: Helvetica, Arial;
}

a {
  color: #F08427;
}

.topnav {
  font-family: Helvetica, Arial;
  font-size: 16px;
}

.lead {
  font-size: 18px;
  font-weight: 400;
}

.intro-header {
  padding-top: 50px;
  padding-bottom: 50px;
  text-align: center;
  color: #f8f8f8;
  background: url(../img/stoff_online2.jpg) no-repeat center center;
  background-size: cover;
}

.intro-message {
  position: relative;
  padding-top: 20%;
  padding-bottom: 20%;
}

.content-section-anfang {
  border-bottom: 1px solid #e7e7e7;
}

.section-heading {
  margin-bottom: 30px;
}

.input-lg {
  height: 46px;
  font-size: 18px;
  line-height: 1.33333;
  border-radius: 1px;
}

.btn {
  border-radius: 1px;
}

.searchbar {
  border: 4px solid rgba(0, 0, 0, 0.3);
}

a.startseite:link {
  color: #ffffff;
}

.startseite-linkfenster {
  color: #99A899;
}

.scrollicon {
  text-align: center;
  text-decoration: none;
  width: 40px;
  height: 40px;
  background: #FD911A;
  opacity: 0.9;
  position: fixed;
  bottom: 20px;
  right: 25px;
  display: none;
  border: 1px solid #FD911A;
  z-index: 100;
  margin: 0;
}

.scrollicon div {
  font-weight: bold;
  font-size: 28px;
  color: #fff;
  padding-top: 0px;
}

@media (max-width:767px) {
  .intro-message {
    padding-bottom: 15%;
  }
}

@media (max-width:991px) {
  .navbar-header {
    float: none;
  }

  .navbar-toggle {
    display: block;
  }

  .navbar-collapse {
    border-top: 1px solid transparent;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1);
  }

  .navbar-collapse.collapse {
    display: none!important;
  }

  .navbar-nav {
    float: none!important;
    margin: 7.5px -15px;
  }

  .navbar-nav>li {
    float: none;
  }

  .navbar-nav>li>a {
    padding-top: 10px;
    padding-bottom: 10px;
  }
}

@media (max-width:1199px) {
  .navbar-header {
    float: none;
  }

  .navbar-toggle {
    display: block;
  }

  .navbar-collapse {
    border-top: 1px solid transparent;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1);
  }

  .navbar-collapse.collapse {
    display: none!important;
  }

  .navbar-nav {
    float: none!important;
    margin: 7.5px -15px;
  }

  .navbar-nav>li {
    float: none;
  }

  .navbar-nav>li>a {
    padding-top: 10px;
    padding-bottom: 10px;
  }
}

html {
  font-family: sans-serif;
  -webkit-text-size-adjust: 100%;
  -ms-text-size-adjust: 100%;
}

body {
  margin: 0;
}

nav {
  display: block;
}

a {
  background-color: transparent;
}

h1 {
  margin: .67em 0;
  font-size: 2em;
}

img {
  border: 0;
}

button,
input {
  margin: 0;
  font: inherit;
  color: inherit;
}

button {
  overflow: visible;
}

button {
  text-transform: none;
}

button {
  -webkit-appearance: button;
}

button::-moz-focus-inner,
input::-moz-focus-inner {
  padding: 0;
  border: 0;
}

input {
  line-height: normal;
}

@font-face {
  font-family: 'Glyphicons Halflings';
  src: url(../fonts/glyphicons-halflings-regular.eot);
  src: url(../fonts/glyphicons-halflings-regular.eot?#iefix) format('embedded-opentype'), url(../fonts/glyphicons-halflings-regular.woff2) format('woff2'), url(../fonts/glyphicons-halflings-regular.woff) format('woff'), url(../fonts/glyphicons-halflings-regular.ttf) format('truetype'), url(../fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular) format('svg');
}

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  font-style: normal;
  font-weight: 400;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.glyphicon-search:before {
  content: "\e003";
}

* {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}

:after,
:before {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}

html {
  font-size: 10px;
}

body {
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 14px;
  line-height: 1.42857143;
  color: #333;
  background-color: #fff;
}

button,
input {
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}

a {
  color: #337ab7;
  text-decoration: none;
}

img {
  vertical-align: middle;
}

.img-responsive {
  display: block;
  max-width: 100%;
  height: auto;
}

.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  border: 0;
}

h1,
h2,
h4 {
  font-family: inherit;
  font-weight: 500;
  line-height: 1.1;
  color: inherit;
}

h1,
h2 {
  margin-top: 20px;
  margin-bottom: 10px;
}

h4 {
  margin-top: 10px;
  margin-bottom: 10px;
}

h1 {
  font-size: 36px;
}

h2 {
  font-size: 30px;
}

h4 {
  font-size: 18px;
}

p {
  margin: 0 0 10px;
}

.lead {
  margin-bottom: 20px;
  font-size: 16px;
  font-weight: 300;
  line-height: 1.4;
}

@media (min-width:768px) {
  .lead {
    font-size: 21px;
  }
}

ul {
  margin-top: 0;
  margin-bottom: 10px;
}

.container {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}

@media (min-width:768px) {
  .container {
    width: 750px;
  }
}

@media (min-width:992px) {
  .container {
    width: 970px;
  }
}

@media (min-width:1200px) {
  .container {
    width: 1170px;
  }
}

.row {
  margin-right: -15px;
  margin-left: -15px;
}

.col-lg-12,
.col-lg-8,
.col-md-8,
.col-sm-8,
.col-xs-10,
.col-xs-8 {
  position: relative;
  min-height: 1px;
  padding-right: 15px;
  padding-left: 15px;
}

.col-xs-10,
.col-xs-8 {
  float: left;
}

.col-xs-10 {
  width: 83.33333333%;
}

.col-xs-8 {
  width: 66.66666667%;
}

.col-xs-offset-2 {
  margin-left: 16.66666667%;
}

.col-xs-offset-1 {
  margin-left: 8.33333333%;
}

@media (min-width:768px) {
  .col-sm-8 {
    float: left;
  }

  .col-sm-8 {
    width: 66.66666667%;
  }

  .col-sm-offset-2 {
    margin-left: 16.66666667%;
  }
}

@media (min-width:992px) {
  .col-md-8 {
    float: left;
  }

  .col-md-8 {
    width: 66.66666667%;
  }

  .col-md-offset-2 {
    margin-left: 16.66666667%;
  }
}

@media (min-width:1200px) {
  .col-lg-12,
  .col-lg-8 {
    float: left;
  }

  .col-lg-12 {
    width: 100%;
  }

  .col-lg-8 {
    width: 66.66666667%;
  }
}

.form-control {
  display: block;
  width: 100%;
  height: 34px;
  padding: 6px 12px;
  font-size: 14px;
  line-height: 1.42857143;
  color: #555;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
}

.form-control::-moz-placeholder {
  color: #999;
  opacity: 1;
}

.form-control:-ms-input-placeholder {
  color: #999;
}

.form-control::-webkit-input-placeholder {
  color: #999;
}

.form-group {
  margin-bottom: 0px;
}

.input-lg {
  height: 46px;
  padding: 10px 16px;
  font-size: 18px;
  line-height: 1.3333333;
  border-radius: 6px;
}

.btn {
  display: inline-block;
  padding: 6px 12px;
  margin-bottom: 0;
  font-size: 14px;
  font-weight: 400;
  line-height: 1.42857143;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  -ms-touch-action: manipulation;
  touch-action: manipulation;
  background-image: none;
  border: 1px solid transparent;
  border-radius: 4px;
}

.btn-success {
  color: #fff;
  background-color: #EC971F;
  /*Farbe 1*/
  border-color: #EC971F;
}

.btn-lg {
  padding: 10px 16px;
  font-size: 18px;
  line-height: 1.3333333;
  border-radius: 1px;
}

.collapse {
  display: none;
  visibility: hidden;
}

.input-group {
  position: relative;
  display: table;
  border-collapse: separate;
}

.input-group[class*=col-] {
  float: none;
  padding-right: 0;
  padding-left: 0;
}

.input-group .form-control {
  position: relative;
  z-index: 2;
  float: left;
  width: 100%;
  margin-bottom: 0;
}

.input-group .form-control,
.input-group-btn {
  display: table-cell;
}

.input-group-btn {
  width: 1%;
  white-space: nowrap;
  vertical-align: middle;
}

.input-group .form-control:first-child {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}

.input-group-btn:last-child>.btn {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

.input-group-btn {
  position: relative;
  font-size: 0;
  white-space: nowrap;
}

.input-group-btn>.btn {
  position: relative;
}

.input-group-btn:last-child>.btn {
  margin-left: -1px;
}

.nav {
  padding-left: 0;
  margin-bottom: 0;
  list-style: none;
}

.nav>li {
  position: relative;
  display: block;
}

.nav>li>a {
  position: relative;
  display: block;
  padding: 10px 15px;
}

.navbar {
  position: relative;
  min-height: 50px;
  margin-bottom: 20px;
  border: 1px solid transparent;
}

@media (min-width:768px) {
  .navbar {
    border-radius: 4px;
  }
}

@media (min-width:768px) {
  .navbar-header {
    float: left;
  }
}

.navbar-collapse {
  padding-right: 15px;
  padding-left: 15px;
  overflow-x: visible;
  -webkit-overflow-scrolling: touch;
  border-top: 1px solid transparent;
  -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);
}

@media (min-width:768px) {
  .navbar-collapse {
    width: auto;
    border-top: 0;
    -webkit-box-shadow: none;
    box-shadow: none;
  }

  .navbar-collapse.collapse {
    display: block!important;
    height: auto!important;
    padding-bottom: 0;
    overflow: visible!important;
    visibility: visible!important;
  }

  .navbar-fixed-top .navbar-collapse {
    padding-right: 0;
    padding-left: 0;
  }
}

.navbar-fixed-top .navbar-collapse {
  max-height: 340px;
}

@media (max-device-width:480px) and (orientation:landscape) {
  .navbar-fixed-top .navbar-collapse {
    max-height: 200px;
  }
}

.container>.navbar-collapse,
.container>.navbar-header {
  margin-right: -15px;
  margin-left: -15px;
}

@media (min-width:768px) {
  .container>.navbar-collapse,
  .container>.navbar-header {
    margin-right: 0;
    margin-left: 0;
  }
}

.navbar-fixed-top {
  position: fixed;
  right: 0;
  left: 0;
  z-index: 1030;
}

@media (min-width:768px) {
  .navbar-fixed-top {
    border-radius: 0;
  }
}

.navbar-fixed-top {
  top: 0;
  border-width: 0 0 1px;
}

.navbar-toggle {
  position: relative;
  float: right;
  padding: 9px 10px;
  margin-top: 15px;
  margin-right: 15px;
  margin-bottom: 8px;
  background-color: transparent;
  background-image: none;
  border: 1px solid transparent;
  border-radius: 4px;
}

.navbar-toggle .icon-bar {
  display: block;
  width: 22px;
  height: 2px;
  border-radius: 1px;
}

.navbar-toggle .icon-bar+.icon-bar {
  margin-top: 4px;
}

@media (min-width:768px) {
  .navbar-toggle {
    display: none;
  }
}

.navbar-nav {
  margin: 7.5px -15px;
}

.navbar-nav>li>a {
  padding-top: 10px;
  padding-bottom: 10px;
  line-height: 20px;
}

@media (min-width:768px) {
  .navbar-nav {
    float: left;
    margin: 0;
  }

  .navbar-nav>li {
    float: left;
  }

  .navbar-nav>li>a {
    padding-top: 15px;
    padding-bottom: 15px;
  }
}

@media (min-width:768px) {
  .navbar-right {
    float: right!important;
    margin-right: -15px;
  }
}

.navbar-default {
  background-color: #fafafa;
  border-color: #e7e7e7;
}

.navbar-default .navbar-nav>li>a {
  color: #373737;
}

.navbar-default .navbar-toggle {
  border-color: #ddd;
}

.navbar-default .navbar-toggle .icon-bar {
  background-color: #888;
}

.navbar-default .navbar-collapse {
  border-color: #e7e7e7;
}

.clearfix:after,
.clearfix:before,
.container:after,
.container:before,
.nav:after,
.nav:before,
.navbar-collapse:after,
.navbar-collapse:before,
.navbar-header:after,
.navbar-header:before,
.navbar:after,
.navbar:before,
.row:after,
.row:before {
  display: table;
  content: " ";
}

.clearfix:after,
.container:after,
.nav:after,
.navbar-collapse:after,
.navbar-header:after,
.navbar:after,
.row:after {
  clear: both;
}

.pull-left {
  float: left!important;
}

@-ms-viewport {
  width: device-width;
}

@media (max-width:767px) {
  .hidden-xs {
    display: none!important;
  }
}