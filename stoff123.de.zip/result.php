<?
$url = $_SERVER['REQUEST_URI'];
$do_search = false;
if(strpos($url, "result.php") !== false)  {
	$do_search = true;
}

 try {
	$user = "stoff123_de";
	$pass = "DUFRcgyz";
	$dbh = new PDO('mysql:host=stoff123.de.mysql;dbname=stoff123_de', $user, $pass);
	$dbh->query("SET CHARACTER SET utf8");
	$stmt = $dbh->prepare('SELECT * FROM stoff123_page WHERE slug = :slug');
	$stmt->execute([ 'slug' => $_GET["q"] ]);
	$row = $stmt->fetch();
	//$sql = 'SELECT * from stoff123_page where slug = "'.$_GET["q"].'"';
	//$row = $dbh->query($sql)->fetch();
	$slug = $row['slug'];
	$searchname = $row['searchname'];
    $dbh = null;
} catch (PDOException $e) {
   //print "Error!: " . $e->getMessage() . "<br/>";
   die();
}

if( $do_search == true or $slug != ""){?>

<!DOCTYPE html>
<html lang="de">

<? $page = "result"; ?>
	
<? include("head.php"); ?>

<body>
	
<? 
include("nav.php");
include ("amazon_api5/SearchItems.php");

?>

<!-- Header -->
<div >
	<div class="container">	
<?	$search = str_replace('-', ' ', $_GET['q']);  ?>

<div class="row " style="padding-top:70px;">
	<div class="col-md-9 col-sm-12 col-xs-12" >
		<h1>
			<? 
			if( $do_search == true) {
				
				if($_GET['q'] != ""){
					echo 'Ergebnisse zu "'.$search.'"';
				}else{
					echo "Stoffe";
				}
				
				$search = $_GET['q'];
			
			}elseif($do_search == false){ 
				echo $searchname; 
			}	
			?> 
		</h1>
	</div>
	<?
	if(isset($_GET["minprice"])){
		$minprice = $_GET["minprice"];
	}else{
		$minprice = 0;
	}
	
	if(isset($_GET["maxprice"])){
		$maxprice = $_GET["maxprice"];
	}else{
		$maxprice = 2000;
	}
	?>
	
	<div class="col-md-3 col-sm-12 col-xs-12">	
		<div class="filterkasten  pull-right">
			<form action="/result.php">	
				<input type="hidden" name="q" value="<?echo $search;?>" /> 
				<div class="controls" style="text-align:right;">
					<span>EUR</span>
					<input class="filter-input" id="minprice" name="minprice" type="text" value="<?echo $minprice; ?>" />
					<span>bis EUR</span>
					<input class="filter-input" id="maxprice" name="maxprice" type="text" value="<?echo $maxprice; ?>" />
					<button type="submit"  class="btn ">go</button>
				</div>	
			</form>
		</div> 
	</div>
	
</div>
 </div>
  <div class="container">		
<div class="result-hr">
<hr>
 </div>

  

				 														
<!-- Produktansicht Version 1 -->

		<? 
		$anfang = 1;
		$ende = 2;
		switch ($_GET['page']) {
			case 1:
				$anfang = 1;
				$ende = 1;
				$productpage = 1;
				break;
			case 2:
				$anfang = 2;
				$ende = 2;
				$productpage = 2;
				break;
			case 3:
				$anfang = 3;
				$ende = 3;
				$productpage = 3;
				break;
			case 4:
				$anfang = 4;
				$ende = 4;
				$productpage = 4;
				break;
			case 5:
				$anfang = 5;
				$ende = 5;
				$productpage = 5;
				break;
		}


?>
	<div class="row">
<?
	$keyId = 'AKIAJE4BG3CSX5X65WZA';
	$secretKey = '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';
	$associateId = "stoff1230b-21";
	$amazonHost = "webservices.amazon.de";
	$amazonRegion ="eu-west-1";
	$searchToAmazon = $search;
	$productCategory = 'HomeAndKitchen';
	$maxprice = $maxprice;
	$minprice = $minprice;
	$browseNode = "2992884031";
	$pageWork = false;
   	$totalPages = 0;

//for ($i = $anfang; $i <= $ende; $i++) {

	$items = searchItems($keyId, $secretKey, $associateId, $amazonHost, $amazonRegion, $searchToAmazon, $productCategory, $browseNode,  $maxprice, $minprice, $i);
	//print_r($items);
	//$items = $amazonAPI->ItemSearch($search, $i, 'Kitchen', '2992884031', 'salesrank', $maxprice, $minprice);
	//$items = $amazonAPI->ItemSearch($search, $i, 'Shoes', '1760296031', 'salesrank', $maxprice, $minprice);
	if($pageWork == false){
	$totalPages =$items[0]["Totalpages"];
	}
	$pageWork = true;
	foreach ($items as $item){
		// Bilder von http auf https umswitchen
		// siehe: https://stackoverflow.com/questions/31856365/amazon-ecs-api-to-return-secure-images-url
		$item["largeImage"] = str_replace('http://ecx.images-amazon.com','https://images-na.ssl-images-amazon.com',$item["largeImage"] );
		$item["mediumImage"] = str_replace('http://ecx.images-amazon.com','https://images-na.ssl-images-amazon.com',$item["mediumImage"] );
		$item["smallImage"] = str_replace('http://ecx.images-amazon.com','https://images-na.ssl-images-amazon.com',$item["smallImage"] );
		
		if($item["HasReviews"] == "true"){
		$item["iframe"] = str_replace('http://','https://',$item["iframe"]);
		}
		
		if($item['formattedprice1'] != ""){
			$displayPrice = number_format(( $item['formattedprice1'] /100.0) ,2,'.','');
		}else{
			$displayPrice = number_format(( $item['formattedprice2'] /100.0) ,2,'.','');;
		}
		
		?>
	
			<div class="col-md-3 col-sm-6 hero-feature">	
					<div class="thumbnail" >
						<? 									 
						$string_laenge = strlen($item['title']);
						$string_title = $item['title'];
						$string_max_laenge = 60;
					
						 if ($string_laenge >= $string_max_laenge) {
								$string_title = preg_replace("/[^ ]*$/", '', substr($item['title'], 0, $string_max_laenge));
						}       	      					
						?>

						<div class="caption " style="min-height:80px;"><? echo "<b>".$string_title."</b>"; ?></div>

						<img src="<? echo $item['mediumImage'];?>" title="<?echo $string_title;?>" alt="<? echo $string_title; ?>" >

						<div style="text-align: center; padding-top:20px;">		
						<? if($item["HasReviews"] == "true" ){?>						
							 <a href="#" class="modalButton" data-toggle="modal" data-src="<? echo $item["iframe"]; ?>" aria-labelledby="myModalLabel" aria-hidden="true" data-target="#myModal">Bewertungen</a>

						   <div class="modal fade" id="myModal" tabindex="-1" role="dialog"  aria-labelledby="myModalLabel"  aria-hidden="true">
							  <div class="modal-dialog">
								 <div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
										<h4 class="modal-title" id="myModalLabel">Kundenbewertungen</h4>
								   </div>
								   
								 <div class="modal-body embed-responsive embed-responsive-4by3" >
									  <iframe frameborder="0" class="embed-responsive-item"></iframe> 
								 </div>
								 
								 
								 <div class="modal-footer">
									<button type="button" class="btn btn-warning" data-dismiss="modal">Schließen</button>
									<a href="<? echo $item['url'];?>" rel="nofollow" target="_blank" class="btn btn-primary" title="<? echo $string_title;?>"><span class="icon-amazon"></span> Zu Amazon</a>
								 </div> 
								</div><!-- /.modal-content -->
							 </div><!-- /.modal-dialog -->
						  </div>
							
							 |
						<?}?>
						<? echo "Preis: <b>". $displayPrice ." €</b><br><br>"; ?>							
						</div>
						
						<div>
							<div class="">
								<a href="#" type="button" class="btn btn-warning" data-toggle="modal" data-target="#<?echo $item['asin']; ?>"><span class="glyphicon glyphicon-search" aria-hidden="true"></span> Details</a>
								<a href="<? echo $item['url'];?>" rel="nofollow" target="_blank" class="btn btn-primary" title="<? echo $string_title;?>"><span class="icon-amazon"></span> Zu Amazon</a> 
							</div>
						</div>	
						
					</div>
			</div>
		
<!-- Modal - Start -->
<div class="modal fade" id="<? echo $item['asin']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog ">
		<div class="modal-content">
			<!-- Header -->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="myModalLabel"><? echo $item['title']; ?></h4>
			</div>			
			
			<!-- Body -->
			<div class="modal-body">
				 <div class="container-fluid" style="padding:10px;">	 
					<div class="row">
						<div class="col-xs-6">
							<a href="<? echo $item['url'];?>" rel="nofollow"><img class="media-object" src="<? echo $item['largeImage'];?>" width="90%" height="90%" ></a>
						</div>
						
						<div class="col-xs-6" >
							<div>
								Angaben zur Verfügbarkeit des Artikels, sowie die Informationen zu den Versandkosten erhältst Du auf der Webseite von:		
							</div>
							<div style="margin-top:10%;">
								<a href="<? echo $item['url'];?>" rel="nofollow"><img class="media-object" src="/img/Amazon-Logo.PNG" width="50%" height="50%" alt="Amazon Partnerprogramm Logo"/></a>
							</div>
								
							<div style="margin-top:10%;">
						
								<? echo "<h4>Preis: <b>". $displayPrice ." EUR </b></h4>"; ?>
							</div>
							
							<div style="margin-top:5%;">
								<button type="button" class="btn btn-warning" data-dismiss="modal">Schließen</button>
								<a href="<? echo $item['url'];?>" target="_blank" rel="nofollow" class="btn btn-primary"><i class="icon-amazon"></i> Zu Amazon</a>								
							</div>
						</div>
					</div>
					 
					 <br>
					 
			 <!-- Footer -->
			 <div class="modal-footer">
				 <div class="row">
					 <div class="col-xs-12" style="text-align:left">
					 <?if (isset($item['feature_0'])) {?>
						 <b><h4>Produktbeschreibung:</h4></b>
					 <?}?> 
					 <?
					 
					  $string_feature =""; 
					   
					if (isset($item['feature_0'])) {
						$string_feature .= '<li>'.$item['feature_0'].'</li>';
						if (isset($item['feature_1'])) {
							$string_feature .= '<li>'.$item['feature_1'].'</li>';
							if (isset($item['feature_2'])) {
								$string_feature .= '<li>'.$item['feature_2'].'</li>';
								if (isset($item['feature_3'])) {
									$string_feature .= '<li>'.$item['feature_3'].'</li>';
										if (isset($item['feature_4'])) {
											$string_feature .= '<li>'.$item['feature_4'].'</li>';
										}
								}
							}
						}
					}			
						echo $string_feature;
						
					
					?>
					<? if($item["EditorialReview"] != ""){ ?>
					<br>
					<h4>Weitere Details</h4>
					<? echo $item["EditorialReview"]; ?>
					<?}?>
					
					</div>
				</div>
			</div>
		
		</div>		
	</div>
</div>
</div>
</div>
<!-- Modal - Ende -->	

<?
	//}
    
}
?>
<? $search = $_GET["q"]; ?>
</div> 

<? if($totalPages > 2){?>
<nav style="text-align:right;">
  <ul class="pagination">
     <li>
      <? if (isset($_GET['page']) and $_GET['page']!=1 ){  ?><a  href="result.php?q=<? echo $search; ?>&page=<? echo $_GET['page']-1; ?>&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>" aria-label="Previous"><?}?>
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li class="<? if($_GET['page']==1 or !isset($_GET['page'])){echo "active";} ?>"><a href="result.php?q=<? echo $search; ?>&page=1&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">1</a></li>
    <li class="<? if($_GET['page']==2){echo "active";} ?>"><a href="/result.php?q=<? echo $search; ?>&page=2&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">2</a></li>
    
	<? if($totalPages > 4){?>
	<li class="<? if($_GET['page']==3){echo "active";} ?>"><a href="/result.php?q=<? echo $search; ?>&page=3&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">3</a></li>
    <?}?>
	
	<? if($totalPages > 6){?>
	<li class="<? if($_GET['page']==4){echo "active";} ?>"><a href="/result.php?q=<? echo $search; ?>&page=4&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">4</a></li>
	<?}?>
	
	<? if($totalPages > 8){?>
    <li class="<? if($_GET['page']==5){echo "active";} ?>"><a href="/result.php?q=<? echo $search; ?>&page=5&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>">5</a></li>
	<?}?>

   <li>
		<? 
		
		if ( ($totalPages/2) > $_GET['page'] and $_GET['page'] < 5 ){  ?><a href="/result.php?q=<? echo $search; ?>&page=<? if (isset($_GET['page'])){ echo $_GET['page']+1; }else{ echo 2;} ?>&minprice=<? echo $minprice; ?>&maxprice=<? echo $maxprice;?>" aria-label="Next"><?}?>
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
<?}?>
 
		
</div>
</div>
	
<? include("footer.php"); ?>
	
</body>
</html>

<?	
}else{
	header('HTTP/1.0 404 Not Found');
	include('404.php');
	exit();
}
?>


