﻿<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="stoff123.de">
    <title>stoff123.de - Diese Seite existiert nicht!</title>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/landing-page.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome-corp.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    <link href="/css/pace.min.css" rel="stylesheet">
    <link rel="shortcut icon" type="image/x-icon" href="/img/favicon/favicon.ico" />
    <link rel="icon" type="image/x-icon" href="/img/favicon/favicon.ico" />

</head>

<body>
    <?include( "nav.php");?>
        <div class="container">
            <div class="col-lg-10 col-lg-offset-1 text-center">
                <div class="logo">
                    <br/>
                    <br/>
                    <br/>
                    <h1>Fehler 404!</h1> </div>
                <div class="clearfix"></div>
                <br/>
                <h3>Nur keine Sorge! Über diesen <a href="https://stoff123.de">Link</a> gelangst du wieder zurück zu unserer Startseite.</h3>
                <div class="clearfix"></div>
                <br/> </div>
            
        <br/>
        <br/>
		</div>
        <?include( "footer.php");?>
</body>

</html>