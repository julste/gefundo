$(function() {
	var minP = parseInt(document.getElementById('minPrice').value);
	var maxP = parseInt(document.getElementById('maxPrice').value);

		$( "#slider-range" ).slider({
			range: true,
			min: 1,
			max: 5000,
			values: [ minP, maxP ],
			slide: function( event, ui ) {
				$( "#amount" ).val( ui.values[ 0 ] + " � - " + ui.values[ 1 ] + " �");
				$( "#minPrice" ).val(ui.values[ 0 ]);
				$( "#maxPrice" ).val(ui.values[ 1 ]);
			},
			stop: function( event, ui ) {
				$( "#minPrice" ).val(ui.values[ 0 ]);
				$( "#maxPrice" ).val(ui.values[ 1 ]);
				document.forms["filterbox"].submit();
			}

		});
		
	});
	

