<!DOCTYPE html>
<html lang="de"> 
<? include ("credentials.php");?>
<?	

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from content';
	$dbh->query("SET CHARACTER SET utf8");
	$rowText = $dbh->query($sql)->fetchall();
	$dbh = null;
} catch (PDOException $e) {
	print "Error!: " . $e->getMessage() . "<br/>";
	die();
}

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	
	$sql = 'SELECT * from image where name = "backgroundImage"';
	$dbh->query("SET CHARACTER SET utf8");
	$backgroundImage = $dbh->query($sql)->fetch();
	
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}


?>
<? $page = "index"; ?> 
<? include("head.php");?> 

<body> 

<? 
include("nav_index.php");
include("searchbar.php"); 
include("content.php"); 
include("footer.php"); 
?> 
</body> 
</html>