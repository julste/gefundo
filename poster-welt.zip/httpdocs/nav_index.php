<nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
    <div class="container topnav">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only"></span> 
			<span class="icon-bar"></span> 
			<span class="icon-bar"></span> 
			<span class="icon-bar"></span> 
			</button>
            <div>
				<h1 class="logo-schrift">
					<a href="/" title="<? echo $websiteUrl;?>">
						<? echo $websiteUrl; ?>
						<? /* falls	in Zukunft wieder Logos als Bild kommen
						<img src="" title="" alt="" class="img-responsive" />*/?>
					</a>
				</h1>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="padding-top:8px;">
            <ul class="nav navbar-nav navbar-right">
                <li> <a href="/#<?echo $rowText[0]["link"];?>" title="<?echo $rowText[0]["heading"];?>"><?echo $rowText[0]["heading"];?></a> </li>
                <li> <a href="/#<?echo $rowText[1]["link"];?>" title="<?echo $rowText[1]["heading"];?>"><?echo $rowText[1]["heading"];?></a> </li>
                <li> <a href="/#<?echo $rowText[2]["link"];?>" title="<?echo $rowText[2]["heading"];?>"><?echo $rowText[2]["heading"];?></a> </li>
            </ul>
        </div>
    </div> 
</nav>