User-agent: WebReaper 
User-agent: WebCopier
User-agent: Offline Explorer
User-agent: HTTrack
User-agent: Microsoft.URL.Control
User-agent: EmailCollector
User-agent: penthesilea
Disallow: /
<?php  
echo "Sitemap: https://". $_SERVER[HTTP_HOST]. "/sitemap.xml"; 
header("Content-Type: text/plain");
?>