<?php
// Database Credentials
$hostName = "10.35.46.191:3306";
$dbName = "k60370_database";
$dbUserName = "k149908_poster";
$dbPassword = "@Amja602";
?>
