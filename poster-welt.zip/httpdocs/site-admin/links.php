<?php require "login/loginheader.php"; ?>
<? $page = "links"; ?>
<? include ("../databasecredentials.php");?>
<? include("helper/slug.php");?>
<? include("links/upload.php");?>
<? include("links/getValues.php"); ?>
<!DOCTYPE html>
<html lang="en">
 <? include("head.php"); ?> 

 <body>
   <div class="container">

	<div class="row">
		<div class="col-md-12">
			<!-- Nav tabs -->
			<div class="card">

			<? include("nav-tab.php"); ?>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="links">
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<p class="lead ueberschrift">Links</p>
							<div class="form-group form-group-sm">
								<div class="col-sm-4">
									<div>
										<input type="file"  name="file" id="file" class="file">
										<div class="input-group">
											<input type="text" class="form-control input-xl" disabled placeholder=" CSV Datei hochladen">
											<span class="input-group-btn">
												<button class="browse btn btn-primary input-xl" type="button"> Browse</button>
											</span>
										</div>
									</div>
								</div>	
								<div class="col-sm-2">
									<input type="submit"  class="btn btn-primary btn-xl" value="Upload CSV File" name="submit">
								</div>
								<div class="col-sm-2">
									<button type="button" name="add" id="add" class="btn btn-primary btn-xl">Add new Link</button>			
								</div>		
								<div class="col-sm-4">
									<div class="pull-right">
									<button type="button" name="createXml" id="createXml" class="btn btn-primary btn-xl">Create XML File</button>
									</div>									
								</div>									
							</div>
						</form>
						<hr>
						<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
							<div class="form-group form-group-sm">
								<div class="col-sm-12">	
								<table id="linkdata" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
												<th>AmazonName</th>
												<th>GoogleName</th>
												<th>Slug</th>
												<th>Startpage</th>
												<th>Action</th>
											</tr>
										</thead>
									</table>			
								 </div>		
							</div>
						</form>				
					</div>
				</div>
			</div>
        </div>
	</div>
</div><!-- /container -->
  </body>
</html>
