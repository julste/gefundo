<head>
    <meta charset="utf-8">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="css/main.css" rel="stylesheet" media="screen">
	<link href="css/custom.css" rel="stylesheet" media="screen">
	<link href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css	" rel="stylesheet" media="screen">
	<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
	<script src="https://netdna.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
	<style>
	.file {
		visibility: hidden;
		position: absolute;
	}
	</style>
	
	<script>
	// File upload 
	$(document).on('click', '.browse', function(){
		  var file = $(this).parent().parent().parent().find('.file');
		  file.trigger('click');
		});
		$(document).on('change', '.file', function(){
		  $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
		});
	</script>

<script type="text/javascript" language="javascript" >
 $(document).ready(function(){
  
  fetch_data();

  function fetch_data()
  {
   var dataTable = $('#linkdata').DataTable({
    "processing" : true,
    "serverSide" : true,
	"ordering": false,
    "ajax" : {
     url:"/site-admin/links/table/fetch.php",
     type:"POST"
    }
   });
  }
  
  $(document).on('click', '.delete', function(){
   var id = $(this).attr("id");
   if(confirm("Are you sure you want to remove this?"))
   {
    $.ajax({
     url:"/site-admin/links/table/delete.php",
     method:"POST",
     data:{id:id},
     success:function(data){
      $('#linkdata').DataTable().destroy();
      fetch_data();
     }
    });
    setInterval(function(){
     $('#alert_message').html('');
    }, 5000);
   }
  });
  
  function update_data(id, column_name, value)
  {
   $.ajax({
    url:"/site-admin/links/table/update.php",
    method:"POST",
    data:{id:id, column_name:column_name, value:value},
    success:function(data)
    {
     $('#linkdata').DataTable().destroy();
     fetch_data();
    }
   });
   setInterval(function(){
    $('#alert_message').html('');
   }, 5000);
  }
  
   $(document).on('blur', '.update', function(){
   var id = $(this).data("id");
   var column_name = $(this).data("column");
   var value = $(this).text();
   update_data(id, column_name, value);
  });

  
  $('#add').click(function(){
   var html = '<tr>';
   html += '<td contenteditable id="data1"></td>';
   html += '<td contenteditable id="data2"></td>';
   html += '<td contenteditable id="data3"></td>';
   html += '<td contenteditable id="data4"></td>';
   html += '<td><button type="button" name="insert" id="insert" class="btn btn-success btn-xs">Insert</button></td>';
   html += '</tr>';
   $('#linkdata tbody').prepend(html);
  });
  
  $(document).on('click', '#insert', function(){
   var amazonName = $('#data1').text();
   var googleName = $('#data2').text();
   var slug = $('#data3').text();
   var startpage = $('#data4').text();
   if(name != '' && slug != '')
   {
    $.ajax({
     url:"/site-admin/links/table/insert.php",
     method:"POST",
     data:{amazonName:amazonName, googleName:googleName, slug:slug, startpage:startpage},
     success:function(data)
     {
      $('#linkdata').DataTable().destroy();
      fetch_data();
     }
    });
    setInterval(function(){
     $('#alert_message').html('');
    }, 5000);
   }
   else
   {
    alert("Both Fields is required");
   }
  });
  
  $('#createXml').click(function(){
	 $.ajax({
		 url:"/site-admin/links/sitemap/createSitemap.php",
		 method:"POST",
		 success:function(data){
			alert("Die Xml Datei wurde erfolgreich erstellt.");
		 }
		});
  });
  
  
  
  });
  
 </script> 

	
  </head>
