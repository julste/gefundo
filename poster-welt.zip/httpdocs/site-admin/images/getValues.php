<?
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from image where name = "backgroundImage"';
	$dbh->query("SET CHARACTER SET utf8");
	$backgroundImage = $dbh->query($sql)->fetch();
	
	$sql = 'SELECT * from image where name = "imprintImage"';
	$dbh->query("SET CHARACTER SET utf8");
	$imprintImage = $dbh->query($sql)->fetch();
	
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}

?>