<?

if($_SERVER['REQUEST_METHOD'] === 'POST') {

try {
		$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);

		// Text 1
		$sql = 'UPDATE content SET
				heading = :heading1,
				text = :text1,
				link = :link1
				WHERE identifier = "text-1"';
		$statement = $dbh->prepare($sql);

		$heading1 = utf8_decode($_POST['heading1']);
		$text1 = utf8_decode($_POST['text1']);
		$link1 = sanitizeStringForUrl($heading1);

		$statement->bindParam(':heading1', $heading1, PDO::PARAM_STR);
		$statement->bindParam(':text1', $text1, PDO::PARAM_STR);
		$statement->bindParam(':link1', $link1, PDO::PARAM_STR);


		$statement->execute();

		// Text 2
		$sql = 'UPDATE content SET
				heading = :heading2,
				text = :text2,
				link = :link2
				WHERE identifier = "text-2"';
		$statement = $dbh->prepare($sql);

		$heading2 = utf8_decode($_POST['heading2']);
		$text2 = utf8_decode($_POST['text2']);
		$link2 = sanitizeStringForUrl($heading2);

		$statement->bindParam(':heading2', $heading2, PDO::PARAM_STR);
		$statement->bindParam(':text2', $text2, PDO::PARAM_STR);
		$statement->bindParam(':link2', $link2, PDO::PARAM_STR);

		$statement->execute();


		// Text 3
		$sql = 'UPDATE content SET
				heading = :heading3,
				text = :text3,
				link = :link3
				WHERE identifier = "text-3"';
		$statement = $dbh->prepare($sql);

		$heading3 = utf8_decode($_POST['heading3']);
		$text3 = utf8_decode($_POST['text3']);
		$link3 = sanitizeStringForUrl($heading3);

		$statement->bindParam(':heading3', $heading3, PDO::PARAM_STR);
		$statement->bindParam(':text3', $text3, PDO::PARAM_STR);
		$statement->bindParam(':link3', $link3, PDO::PARAM_STR);

		$statement->execute();


		} catch (PDOException $e) {
		print "Error: " . $e->getMessage() . "<br/>";
		die();
	}

?>

<script>
alert("Texte wurden erfolgreich gepeichert!");
</script>
<?
	}
?>
