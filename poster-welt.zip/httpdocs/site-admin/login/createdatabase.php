<?php
	// Create the table "website" and fill in the first entry with the identifier 1000 
	$dbh->query("CREATE TABLE `website` (
			`id` int(11) NOT NULL AUTO_INCREMENT,
			`identifier` varchar(200),
			`websiteUrl` varchar(200),
			`websiteName` varchar(200),
			`keyWordSingular` varchar(200),
			`keyWordPlural` varchar(200),
			`metaKeywordsStartpage` varchar(2000),
			`mailaddress` varchar(200),
			`searchField` varchar(200),
			`title` varchar(200),
			`position` varchar(200),
			`piwikScript` varchar(2000),
			`piwikLink` varchar(200),
			`verification` varchar(200),
			`keyId` varchar(200),
			`secretKey` varchar(200),
			`associateId` varchar(200),
			`productCategory` varchar(200),
			`browseNode` varchar(200),
			PRIMARY KEY (`id`)
			) CHARACTER SET utf8 COLLATE utf8_bin");
		
	$stmt = $dbh->prepare("INSERT INTO website (identifier) VALUES (:identifier)");
	$stmt->bindParam(':identifier', $identifier);
	$identifier = '1000';
	$stmt->execute();
	
	// Create the table "content" and fill in three entries with identifier
	$dbh->query("CREATE TABLE `content` (
			`id` int(11) NOT NULL AUTO_INCREMENT,
			`heading` varchar(200),
			`text` TEXT,
			`link` varchar(200),			
			`identifier` varchar(200),			
			PRIMARY KEY (`id`)
			) CHARACTER SET utf8 COLLATE utf8_bin");
			
	$stmt = $dbh->prepare("INSERT INTO content (identifier) VALUES (:identifier)");
	$stmt->bindParam(':identifier', $identifier);
	
	$identifier = 'text-1';
	$stmt->execute();	

	$identifier = 'text-2';
	$stmt->execute();	

	$identifier = 'text-3';
	$stmt->execute();		
	
	// Create the table "images" and fill in two entries with identifier
	$dbh->query("CREATE TABLE `image` (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`name` varchar(200),
		`path` varchar(200),		
		PRIMARY KEY (`id`)
		) CHARACTER SET utf8 COLLATE utf8_bin");
	
	$stmt = $dbh->prepare("INSERT INTO image (name) VALUES (:identifier)");
	$stmt->bindParam(':identifier', $identifier);
	
	$identifier = 'imprintImage';
	$stmt->execute();	

	$identifier = 'backgroundImage';
	$stmt->execute();
	
	// Create the table "Page" and fill in two entries with identifier
	$dbh->query("CREATE TABLE `page` (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`googlename` varchar(200),
		`amazonname` varchar(200),
		`slug` varchar(200),
		`startpage` int(200),		
		PRIMARY KEY (`id`)
		) CHARACTER SET utf8 COLLATE utf8_bin");
	
	?>