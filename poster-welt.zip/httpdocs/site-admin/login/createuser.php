<?php
require 'includes/functions.php';
include ("../../databasecredentials.php");
$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);

$dbh->query("CREATE TABLE `members` (
		`id` char(23) NOT NULL,
		`username` varchar(65) NOT NULL DEFAULT '',
		`password` varchar(65) NOT NULL DEFAULT '',
		`verified` tinyint(1) NOT NULL DEFAULT '1	',
		`mod_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		PRIMARY KEY (`id`),
		UNIQUE KEY `username_UNIQUE` (`username`),
		UNIQUE KEY `id_UNIQUE` (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8");

			
$dbh->query("CREATE TABLE `loginAttempts` (
			  `IP` varchar(20) NOT NULL,
			  `Attempts` int(11) NOT NULL,
			  `LastLogin` datetime NOT NULL,
			  `Username` varchar(65) DEFAULT NULL,
			  `ID` int(11) NOT NULL AUTO_INCREMENT,
			  PRIMARY KEY (`ID`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;");	

include_once 'config.php';

//Pull username, generate new ID and hash password
$newid = uniqid(rand(), false);
$newuser = $_POST['newuser'];
$newpw = password_hash($_POST['password1'], PASSWORD_DEFAULT);
$pw1 = $_POST['password1'];
$pw2 = $_POST['password2'];


//Validation rules
if ($pw1 != $pw2) {

	echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Password fields must match</div><div id="returnVal" style="display:none;">false</div>';

} elseif (strlen($pw1) < 4) {

	echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Password must be at least 4 characters</div><div id="returnVal" style="display:none;">false</div>';

} else {


	
	//Validation passed
	if (isset($_POST['newuser']) && !empty(str_replace(' ', '', $_POST['newuser'])) && isset($_POST['password1']) && !empty(str_replace(' ', '', $_POST['password1']))) {


		//Tries inserting into database and add response to variable

		$a = new NewUserForm;

		$response = $a->createUser($newuser, $newid, $newpw);
		
		

		//Success
		if ($response == 'true') {

			echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'."Die Datenbankverbindung wurde erfolgreich hergestellt!".'</div><div id="returnVal" style="display:none;">true</div>';
		
			include("createdatabase.php");
		
		
		} else {
			//Failure
			mySqlErrors($response);

		}
	} else {
		//Validation error from empty form variables
		echo 'An error occurred on the form... try again';
	}
};				

