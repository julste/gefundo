<?php
include ("../../databasecredentials.php");
//DATABASE CONNECTION VARIABLES
$host = $hostName; // Host name
$username = $dbUserName; // Mysql username
$password = $dbPassword ; // Mysql password
$db_name = $dbName; // Database name


//DO NOT CHANGE BELOW THIS LINE UNLESS YOU CHANGE THE NAMES OF THE MEMBERS AND LOGINATTEMPTS TABLES

$tbl_prefix = ""; //***PLANNED FEATURE, LEAVE VALUE BLANK FOR NOW*** Prefix for all database tables
$tbl_members = $tbl_prefix."members";
$tbl_attempts = $tbl_prefix."loginAttempts";
