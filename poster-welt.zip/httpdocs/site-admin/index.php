<?php require "login/loginheader.php"; ?>
<? include ("../databasecredentials.php");?>
<? include("index/saveValues.php"); ?>
<? include("index/getValues.php"); ?>
<? $page = "index"; ?>
<!DOCTYPE html>
<html lang="en">
 <? include("head.php"); ?> 
  <body>
   <div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Nav tabs -->
				<div class="card">

					<? include("nav-tab.php"); ?>
					<!-- Tab panes -->
					<div class="tab-content">
						<div class="tab-pane active" id="allgemein">
							<form class="form-horizontal" action=" " method="POST">
								<p class="lead ueberschrift">Allgemeine Daten</p>
								<div class="form-group form-group-sm">
								
									<!-- left column -->
									<div class="col-sm-6">
										<div class="form-group">
											<label for="websiteBame" class="col-sm-3 control-label">Website Name</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="websiteName" name="websiteName"placeholder="" value="<? echo $rowWebsite["websiteName"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="websiteUrl" class="col-sm-3 control-label">Site Url Short</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="websiteUrl" name="websiteUrl" placeholder="" value="<? echo $rowWebsite["websiteUrl"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="mailaddress" class="col-sm-3 control-label">E-Mail</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="mailaddress" name="mailaddress" placeholder="" value="<? echo $rowWebsite["mailaddress"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="title" class="col-sm-3 control-label">Überschrift</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="title" name="title" placeholder="" value="<? echo $rowWebsite["title"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="title" class="col-sm-3 control-label">Suchfeldinhalt</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="searchField" name="searchField" placeholder="" value="<? echo $rowWebsite["searchField"]; ?>">
											</div>
										</div>
									</div>
						
									<!-- right column -->
									<div class="col-sm-6">
										<div class="form-group">
											<label for="keyWordSingular" class="col-sm-3 control-label">Keyword Sing.</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="keyWordSingular" name="keyWordSingular" placeholder=""  value="<? echo $rowWebsite["keyWordSingular"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="keyWordPlural" class="col-sm-3 control-label">Keyword Plural</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="keyWordPlural" name="keyWordPlural" placeholder=""  value="<? echo $rowWebsite["keyWordPlural"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="keyWordsStartpage" class="col-sm-3 control-label">Keywords Start.</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="keyWordsStartpage" name="keyWordsStartpage" placeholder=""  value="<? echo $rowWebsite["metaKeywordsStartpage"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="position" class="col-sm-3 control-label">Ausrichtung</label>
											<div class="col-sm-9">
												<div class="btn-group" data-toggle="buttons">
													<label class="btn btn-primary <? if ($rowWebsite["position"] == "pull-left"){ echo "active";} ?>">
														<input type="radio" name="position" id="left" value="pull-left" autocomplete="off" <? if ($rowWebsite["position"] == "pull-left"){ echo "checked";} ?>> Links 	
													</label>
													<label class="btn btn-primary <? if ($rowWebsite["position"] == "pull-right"){ echo "active";} ?>">
														<input type="radio" name="position" id="right" value="pull-right" autocomplete="off" <? if ($rowWebsite["position"] == "pull-right"){ echo "checked";} ?>> Rechts
													</label>

												</div>
											</div>
										</div>	
										<div class="form-group">
											<label for="verification" class="col-sm-3 control-label">Verification</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="verification" name="verification" placeholder=""  value="<? echo $rowWebsite["verification"]; ?>">
											</div>
										</div>
									</div>
									
								</div>
				
			
								<p class="lead ueberschrift">Amazon Daten</p>
								<div class="form-group form-group-sm">
					
									<!-- left column -->
									<div class="col-sm-6">
										<div class="form-group">
											<label for="keyId" class="col-sm-3 control-label">Key ID</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="keyId" name="keyId" placeholder=""  value="<? echo $rowWebsite["keyId"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="secretKey" class="col-sm-3 control-label">Secret Key</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="secretKey" name="secretKey" placeholder=""  value="<? echo $rowWebsite["secretKey"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="associateId" class="col-sm-3 control-label">Associate ID</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="associateId" name="associateId" placeholder=""  value="<? echo $rowWebsite["associateId"]; ?>">
											</div>
										</div>
									</div>
								
									<!-- right column -->
									<div class="col-sm-6">
										<div class="form-group">
											<label for="productCategory" class="col-sm-3 control-label"><a href="http://docs.aws.amazon.com/AWSECommerceService/latest/DG/LocaleDE.html" target="blank">Produktkategorie</a></label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="productCategory" name="productCategory"  placeholder="" value="<? echo $rowWebsite["productCategory"]; ?>">
											</div>
										</div>
										<div class="form-group">
											<label for="browseNode" class="col-sm-3 control-label">Browse Node</label>
											<div class="col-sm-9">
												<input type="text" class="form-control" id="browseNode" name="browseNode" placeholder="" value="<? echo $rowWebsite["browseNode"]; ?>">
											</div>
										</div>
									</div>
									
								</div>
								<p class="lead ueberschrift">Piwik</p>

								 <div class="form-group form-group-sm">
									<div class="col-sm-12">
										<div class="form-group">
											<label for="piwikLink" class="col-sm-1 control-label">Link</a></label>
											<div class="col-sm-11">
												<input type="text" class="form-control" id="piwikLink" name="piwikLink"  placeholder="" value="<? echo $rowWebsite["piwikLink"]; ?>">
											</div>
										</div>									
										<div class="form-group">
										<label for="piwikScript" class="col-sm-1 control-label">Script</a></label>
											<div class="col-sm-11">
													<textarea class="form-control" rows="10" id="piwikScript" name="piwikScript"><? echo $rowWebsite["piwikScript"]; ?></textarea>
											</div>
										</div>									
									</div>
								</div>
								
								<!-- Speicher Button -->
								<div class="form-group">
									<div class="col-sm-12">
										<button type="submit" class="pull-right btn btn-primary btn-xl" id="submit">Speichern</button>
									</div>
								</div>
								
							</form>									
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- /container -->
  </body>
</html>
