<?
if($_SERVER['REQUEST_METHOD'] === 'POST') {

try {
		$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
		$sql = 'UPDATE website SET 
				websiteUrl = :websiteUrl,
				websiteName = :websiteName,
				mailaddress = :mailaddress,
				searchField = :searchField,
				title = :title,
				position = :position,
				keyWordSingular = :keyWordSingular,
				keyWordPlural = :keyWordPlural,
				metaKeywordsStartpage = :metaKeywordsStartpage,
				keyId = :keyId,
				secretKey = :secretKey,
				associateId = :associateId,
				productCategory = :productCategory,
				browseNode = :browseNode,
				piwikScript = :piwikScript,
				piwikLink = :piwikLink,
				verification = :verification
				WHERE identifier = 1000';
		$statement = $dbh->prepare($sql);
		
		$websiteUrl = $_POST['websiteUrl'];
		$websiteName = $_POST['websiteName'];
		$mailaddress = $_POST['mailaddress'];
		$searchField = $_POST['searchField'];		
		$title = $_POST['title'];
		$position = $_POST['position'];
		$keyWordSingular = $_POST['keyWordSingular'];
		$keyWordPlural = $_POST['keyWordPlural'];
		$keyWordsStartpage = $_POST['keyWordsStartpage'];
		$keyId = $_POST['keyId'];
		$secretKey = $_POST['secretKey'];
		$associateId = $_POST['associateId'];
		$productCategory = $_POST['productCategory'];
		$browseNode = $_POST['browseNode'];
		$piwikScript = $_POST['piwikScript'];
		$piwikLink = $_POST['piwikLink'];
		$verification = $_POST['verification'];
		
		$statement->bindParam(':websiteUrl', $websiteUrl, PDO::PARAM_STR);   
		$statement->bindParam(':websiteName', $websiteName, PDO::PARAM_STR);       
		$statement->bindParam(':mailaddress', $mailaddress, PDO::PARAM_STR); 
		$statement->bindParam(':searchField', $searchField, PDO::PARAM_STR);    		
		$statement->bindParam(':title', $title, PDO::PARAM_STR);       
		$statement->bindParam(':position', $position, PDO::PARAM_STR);       
		$statement->bindParam(':keyWordSingular', $keyWordSingular, PDO::PARAM_STR);       
		$statement->bindParam(':keyWordPlural', $keyWordPlural, PDO::PARAM_STR);       
		$statement->bindParam(':metaKeywordsStartpage', $keyWordsStartpage, PDO::PARAM_STR);       
		$statement->bindParam(':keyId', $keyId, PDO::PARAM_STR);       
		$statement->bindParam(':secretKey', $secretKey, PDO::PARAM_STR);       
		$statement->bindParam(':associateId', $associateId, PDO::PARAM_STR);       
		$statement->bindParam(':productCategory', $productCategory, PDO::PARAM_STR);       
		$statement->bindParam(':browseNode', $browseNode, PDO::PARAM_STR);       
		$statement->bindParam(':piwikScript', $piwikScript, PDO::PARAM_STR);       
		$statement->bindParam(':piwikLink', $piwikLink, PDO::PARAM_STR);       
		$statement->bindParam(':verification', $verification, PDO::PARAM_STR);       
		$statement->execute();
		$dbh = null;

	} catch (PDOException $e) {
		print "Error: " . $e->getMessage() . "<br/>";
		die();
	}

?>

<script>
alert("Informationen wurden erfolgreich gepeichert!");
</script>
<?
	}
?>