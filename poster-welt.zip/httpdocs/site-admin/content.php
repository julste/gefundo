<?php require "login/loginheader.php"; ?>
<? include ("../databasecredentials.php");?>
<? include("helper/slug.php"); ?>

<? include("content/saveValues.php"); ?>
<? include("content/getValues.php"); ?>

<? $page = "content"; ?>
<!DOCTYPE html>
<html lang="en">
 <? include("head.php"); ?> 
  <body>
   <div class="container">
	<div class="row">
		<div class="col-md-12">
			<!-- Nav tabs -->
			<div class="card">

			<? include("nav-tab.php"); ?>
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane active" id="content">
						<form class="form-horizontal" action="" method="POST">		
						
							<p class="lead ueberschrift">Text 1</p>
							<div class="form-group">
								<label for="heading1" class="col-sm-1 control-label">Heading</label>
								<div class="col-sm-11">
									<input type="text" class="form-control" id="heading1" name="heading1" placeholder="" value="<? echo $rowText[0]["heading"];?>">
								</div>
							</div>
							<div class="form-group">
							<label for="text1" class="col-sm-1 control-label">Text</label>
								<div class="col-sm-11">
									<textarea class="form-control" rows="10" id="text1" name="text1"><? echo $rowText[0]["text"];?></textarea>
								</div>
							</div>	
							
							<p class="lead ueberschrift">Text 2</p>
							<div class="form-group">
								<label for="heading2" class="col-sm-1 control-label">Heading</label>
								<div class="col-sm-11">
									<input type="text" class="form-control" id="heading2" name="heading2" placeholder=""  value="<? echo $rowText[1]["heading"];?>">
								</div>
							</div>
							<div class="form-group">
							<label for="text2" class="col-sm-1 control-label">Text</label>
								<div class="col-sm-11">
									<textarea class="form-control" rows="10" id="text2" name="text2"><? echo $rowText[1]["text"];?></textarea>
								</div>
							</div>	

							<p class="lead ueberschrift">Text 3</p>
							<div class="form-group">
								<label for="heading3" class="col-sm-1 control-label">Heading</label>
								<div class="col-sm-11">
									<input type="text" class="form-control" id="heading3" name="heading3" placeholder=""  value="<? echo $rowText[2]["heading"];?>">
								</div>
							</div>
							<div class="form-group">
							<label for="text3" class="col-sm-1 control-label">Text</label>
								<div class="col-sm-11">
									<textarea class="form-control" rows="10" id="text3" name="text3"><? echo $rowText[1]["text"];?></textarea>
								</div>
							</div>
									
							<!-- Speicher Button -->
							<div class="form-group">
								<div class="col-sm-12">
									<button type="submit" class="pull-right btn btn-primary btn-xl">Speichern</button>
								</div>
							</div>
															
						</form>				
					
					
					
					
					</div>
				</div>
			</div>
        </div>
	</div>
   </div><!-- /container -->
  </body>
</html>
