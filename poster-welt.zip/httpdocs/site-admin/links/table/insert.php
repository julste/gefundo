<?php
include ("../../../databasecredentials.php");
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	
	if(isset($_POST["amazonName"], $_POST["googleName"], $_POST["slug"],  $_POST["startpage"]))
	{

	$stmt = $dbh->prepare("INSERT INTO page (amazonName, googleName, slug, startpage) VALUES (:amazonName, :googleName, :slug, :startpage)");
	$stmt->bindParam(':amazonName', $_POST["amazonName"]);
	$stmt->bindParam(':googleName', $_POST["googleName"]);
	$stmt->bindParam(':slug', $_POST["slug"]);
	$stmt->bindParam(':startpage', $_POST["startpage"]);
	$stmt->execute();
	}
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}



?>