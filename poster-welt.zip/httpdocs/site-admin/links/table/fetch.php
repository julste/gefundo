<?php
include ("../../../databasecredentials.php");

try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$dbh->query("SET CHARACTER SET utf8");
	$sql = 'SELECT * from page';	
	
	if(isset($_POST["search"]["value"]))
	{
	 $sql .= '
	 WHERE amazonname LIKE "%'.$_POST["search"]["value"].'%" 
	 OR googlename LIKE "%'.$_POST["search"]["value"].'%"
	 OR slug LIKE "%'.$_POST["search"]["value"].'%" 
	 OR startpage LIKE "%'.$_POST["search"]["value"].'%"';
	}
	
	/*
	if(isset($_POST["order"]))
	{
	 $sql .= 'ORDER BY '.$columns[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].'';
	}
	else
	{
	 $sql .= 'ORDER BY id DESC ';
	}
	*/
	$data = array();
	
	if($_POST["length"] != -1)
	{
		$sql .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
	}
	
	foreach($dbh->query($sql) as $rowPage){	
		$sub_array = array();
		$sub_array[] = '<div contenteditable class="update" data-id="'.$rowPage["id"].'" data-column="amazonname">' . $rowPage["amazonname"] . '</div>';
		$sub_array[] = '<div contenteditable class="update" data-id="'.$rowPage["id"].'" data-column="googlename">' . $rowPage["googlename"] . '</div>';
		$sub_array[] = '<div contenteditable class="update" data-id="'.$rowPage["id"].'" data-column="slug">' . $rowPage["slug"] . '</div>';
		$sub_array[] = '<div contenteditable class="update" data-id="'.$rowPage["id"].'" data-column="startpage">' . $rowPage["startpage"] . '</div>';
		$sub_array[] = '<button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'.$rowPage["id"].'">Delete</button>';
		$data[] = $sub_array;	
	}
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}

$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
$sql = 'SELECT count(*) from page WHERE amazonname LIKE "%'.$_POST["search"]["value"].'%" 
	 OR googlename LIKE "%'.$_POST["search"]["value"].'%" 
	 OR slug LIKE "%'.$_POST["search"]["value"].'%" 
	 OR startpage LIKE "%'.$_POST["search"]["value"].'%"';
$result = $dbh->prepare($sql); 
$result->execute(); 
$number_of_filtered_rows = $result->fetchColumn(); 

$sql = "SELECT count(*) FROM `page`"; 
$result = $dbh->prepare($sql); 
$result->execute(); 
$number_of_rows = $result->fetchColumn(); 

$sub_array = array();
$output = array(
 "draw"    => intval($_POST["draw"]),
 "recordsTotal"  =>  $number_of_rows,
 "recordsFiltered" => $number_of_filtered_rows,
 "data"    => $data
);
echo json_encode($output);



?>
