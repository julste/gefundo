<?
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from page';
	$dbh->query("SET CHARACTER SET utf8");
	$rowText = $dbh->query($sql)->fetchall();
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}
?>