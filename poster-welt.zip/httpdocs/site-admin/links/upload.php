<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST'){

	$tmpName = $_FILES['file']['tmp_name'];
	$csvAsArray = array_map('str_getcsv', file($tmpName));

	//print_r($csvAsArray);

	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);

	$stmt = $dbh->prepare("INSERT INTO page (slug, amazonname, googlename) VALUES (?, ?, ?)");
	$stmt->bindParam(1, $slug);
	$stmt->bindParam(2, $amazonname);
	$stmt->bindParam(3, $googlename);

	foreach($csvAsArray as $item){
		$slug = sanitizeStringForUrl(trim($item[1]));
		$amazonname = ucwords(trim($item[0]));
		$googlename = ucwords(trim($item[1]));
		$stmt->execute();
	}

	// Doppelte Einträge löschen
	$dbh->query("DELETE FROM page USING page, page as tmppage
					WHERE NOT page.id=tmppage.id
					AND page.id > tmppage.id
					AND page.name=tmppage.name");

/*
$target_dir = "../img/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        	?>
		<script>
		alert("Upload ist kein Image.");
		</script>
	<?
        $uploadOk = 0;
    }
}
// Check if file already exists
/*
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
*/
// Check file size
/*
if ($_FILES["fileToUpload"]["size"] > 500000) {
    	?>
		<script>
		alert("Upload ist zu gro�.");
		</script>
	<?
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
	?>
		<script>
		alert("Nur in klein: jpg, png, jpeg, gif");
		</script>
	<?    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {

// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {

		try {

		$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);

		$sql = 'UPDATE images SET
				path = :path
				WHERE name = :identifier';
		$statement = $dbh->prepare($sql);

		$path = utf8_decode(basename( $_FILES["fileToUpload"]["name"]));
		$identifier = utf8_decode($_POST['identifier']);

		$statement->bindParam(':path', $path, PDO::PARAM_STR);
		$statement->bindParam(':identifier', $identifier, PDO::PARAM_STR);

		$statement->execute();
		$dbh = null;
	?>
		<script>
		alert("Bild wurde erfolgreich hochgeladen");
		</script>
	<?
	} catch (PDOException $e) {
		print "Error: " . $e->getMessage() . "<br/>";
		die();
	}




    } else {
       // echo "Sorry, there was an error uploading your file.";
    }
}

}*/
}
?>
