﻿<a name="<?echo $rowText[0]["link"];?>"></a>
<div class="content-section-anfang">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" style="text-align:center">
                <div class="clearfix"></div>
                <h2 class="section-heading"><?echo $rowText[0]["heading"];?></h2>
                <p class="lead" style="text-align:justify">
				<?echo $rowText[0]["text"];?>
				</p>
            </div>
        </div>
    </div>
</div>
<a name="<?echo $rowText[1]["link"];?>"></a>
<div class="content-section-a">
    <div class="container">
        <div class="row"> 
            <div class="col-lg-12" style="text-align:center">
                <div class="clearfix"></div>
                <h2 class="section-heading"><?echo $rowText[1]["heading"];?></h2>
                <p class="lead" style="text-align:justify">
				<?echo $rowText[1]["text"];?>	
				</p>
				</div>
        </div>
    </div>
</div>
<a name="<?echo $rowText[2]["link"];?>"></a>
<div class="content-section-b">
    <div class="container">
        <div class="row">
            <div class="col-lg-12" style="text-align:center">
                <div class="clearfix"></div>
                <h3 class="section-heading"><?echo $rowText[2]["heading"];?></h3>
                <p class="lead" style="text-align:justify">
				<?echo $rowText[2]["text"];?>
				</p>
            </div>
        </div>
    </div>
</div>
