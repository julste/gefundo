﻿<!-- Footer -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="list-inline footer-mittig">
					<li>
						<a href="/datenschutzerklaerung" class="footer-link" title="Datenschutzerklärung von <?echo $websiteUrl;?>">Datenschutzerklärung</a>
					</li>	
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/impressum" class="footer-link" title="Impressum von <?echo $websiteUrl;?>" >Impressum</a>
					</li>
					<li class="footer-menu-divider">&sdot;</li>
					<li>
						<a href="/sitemap" class="footer-link" title="Sitemap von <?echo $websiteUrl;?>">Sitemap</a>
					</li>
				</ul>
				<p class="copyright text-muted small footer-mittig">Copyright &copy; <?echo $websiteUrl;?> <?php echo date("Y"); ?></p>
			</div>
		</div>
	</div>
</footer>
<!-- Bootstrap Core CSS -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="/css/landing-page.css" rel="stylesheet">
<!-- Custom Fonts -->
<link href="/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

<!-- Loadbar -->
<link href="/css/pace.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
<? if(isset($page) == 'result'){?>

<? }?>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" type="text/javascript"></script>

<? 
/*
<!-- Loadbar -->
<script src="/js/priceSlider.js" type="text/javascript"></script>
<script src="/js/default.js" type="text/javascript"></script>
<script src="/js/pace.min.js" type="text/javascript"></script>
<!-- Scroll to top Button -->
<script src="/js/scrolltotop.js" type="text/javascript"></script>
*/ ?> 
  <script>
$('a.modalButton').on('click', function(e) {
    var src = $(this).attr('data-src');
    var height = $(this).attr('data-height') || 400;
    var width = $(this).attr('data-width') || 500;
    $("#myModal iframe").attr({'src':src});
});
function chkFormular() {
  if (document.Formular.q.value == "") {
	      document.Formular.q.focus();
    return false;
  }else{
	return true;  
  }
}
</script>
<!-- Piwik -->
<? echo $piwikScript; ?>
<!-- End Piwik Code -->