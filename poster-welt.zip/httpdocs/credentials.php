<?
include("databasecredentials.php");
try {
	$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
	$sql = 'SELECT * from website where identifier = 1000';
	$dbh->query("SET CHARACTER SET utf8");
	$rowWebsite = $dbh->query($sql)->fetch();
	$dbh = null;
} catch (PDOException $e) {
	print "Error: " . $e->getMessage() . "<br/>";
	die();
}

// Website Credentials
$websiteUrl = $rowWebsite["websiteUrl"];
$websiteName = $rowWebsite["websiteName"];
$keyWordSingular = $rowWebsite["keyWordSingular"];
$keyWordPlural = $rowWebsite["keyWordPlural"];
$metaKeywordsStartpage = $rowWebsite["metaKeywordsStartpage"];
$mailaddress = $rowWebsite["mailaddress"];
$searchField = $rowWebsite["searchField"];
$title = $rowWebsite["title"];
$position = $rowWebsite["position"]; 

// Piwik Credentials
$piwikScript = $rowWebsite["piwikScript"];
$piwikAnalyticsLink = $rowWebsite["piwikLink"];

// Amazon Credentials
$keyId = $rowWebsite["keyId"];
$secretKey = $rowWebsite["secretKey"];
$associateId = $rowWebsite["associateId"];
$productCategory = $rowWebsite["productCategory"];
$browseNode = $rowWebsite["browseNode"];
$amazonHost = 'webservices.amazon.de';
$amazonRegion = 'eu-west-1';


// Google Verification
$verification = $rowWebsite["verification"];

?>