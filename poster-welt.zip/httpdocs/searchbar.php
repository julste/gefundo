<div class="intro-header" style="background-image: url(${../img/<? echo $backgroundImage["path"]; ?>}) no-repeat center center;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <br>
                <h1 class="hidden-xs <? echo $position; ?>"><? echo $title; ?></h1>
                <div class="intro-message">
                    <form action="/result.php" method="GET" class="form-group" name="Formular" role="search" onsubmit="return chkFormular();">
                        <div class="input-group col-xs-10 col-sm-8 col-md-8 col-lg-8 col-xs-offset-1 col-sm-offset-2 col-md-offset-2 searchbar">
                            <input type="text" class="form-control input-lg" placeholder="<? echo $searchField; ?>" name="q">
                            <div class="input-group-btn">
                                <button class="btn btn-success btn-lg" type="submit" id="search"> <i class="glyphicon glyphicon-search"></i> </button>
                            </div>
                        </div>
                    </form>
                    <div class="hidden-xs col-xs-8 col-lg-8 col-xs-offset-2 col-md-offset-2" style="background-color:rgba(0, 0, 0, 0.7);">
                        <h4 class="startseite-linkfenster">
						<? try {
								$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
								$sql = 'SELECT * from page where startpage <> "" order by startpage asc';
								$dbh->query("SET CHARACTER SET utf8");
								$var = $dbh->query($sql)->fetchall();							
								foreach( $var as $rowPage){
									 echo "<a class='startseite' href='/".$rowPage['slug']."' title='".$rowPage['googlename']."'>".$rowPage['googlename']."</a>"; 
										if(end($var) !== $rowPage){
												echo ' | '; // not the last element
											}
																				}
								$dbh = null;
							} catch (PDOException $e) {
								print "Error!: " . $e->getMessage() . "<br/>";
								die();
							}
						?>
						</h4> 
					</div>
				</div>
			</div>
        </div>
    </div>
</div>