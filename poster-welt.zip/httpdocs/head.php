﻿<head>
<style>
<?
if($page == "result"){
	include("abovethefoldResult.php");
}else{
	include("abovethefold.php");
}
?>
</style>
	<meta name="google-site-verification" content="<? echo $verification;?>" />
	<? if($page =="index"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<?$metaTextStartpage = $keyWordPlural." schnell und einfach online finden auf ".$websiteUrl."! Hier gibt es eine Riesenauswahl ✓ Tolle Angebote ✓ Faire Preise ✓ ".$keyWordSingular." ✓ "?>
    <meta name="description" content="<? echo $metaTextStartpage;?>">
	<meta name="keywords" content="<? echo $metaKeywordsStarpage;?>">
    <meta name="author" content="<? echo $websiteUrl;?>">
    <title><? echo $keyWordPlural; ?> online finden - Ganz einfach auf <?echo $websiteUrl;?>!</title>
	<?}?>
	<? if($page =="impressum"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="<? echo $websiteUrl;?>">
	<meta name="robots" content="noindex, nofollow">
    <title>Impressum - <?echo $websiteUrl;?></title>
	<?}?>
	<? if($page =="kontakt"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="<? echo $websiteUrl;?>">
    <title>Kontakt - <?echo $websiteUrl;?></title>
	<?}?>
	<? if($page =="datenschutzerklaerung"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="<? echo $websiteUrl;?>">
	<meta name="robots" content="noindex, nofollow">
    <title>Datenschutzerklärung - <?echo $websiteUrl;?></title>
	<?}?>
	<? if($page =="sitemap"){?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="<? echo $websiteUrl;?>">
    <title>Sitemap - <?echo $websiteUrl;?></title>
	<?}?>
	<?
	
	if (isset($_GET["q"]) != ""){
		try {
			$dbh = new PDO('mysql:host='.$hostName.';dbname='.$dbName.'', $dbUserName, $dbPassword);
			$sql = 'SELECT * from page where slug = "'.$_GET["q"].'"';
			$dbh->query("SET CHARACTER SET utf8");
			$row = $dbh->query($sql)->fetch();
			$slug = $row['slug'];
			$name = $row['name'];
			$dbh = null;
		} catch (PDOException $e) {
			print "Error!: " . $e->getMessage() . "<br/>";
			die();
		}
	}	
	?>
	<? if($page =="result"){?>
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1">
    	<meta name="author" content="<? echo $websiteUrl;?>">
	<? 	if(isset($_GET['page']) and $_GET['page'] == 1){?>
	   
			<meta name="description" content="<? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> - nur ein Klick entfernt auf <? echo $websiteUrl;?>! Super Angebote ✓ Billige Preise ✓ Riesige Auswahl ✓ <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> ✓ <? echo $websiteUrl;?> ✓">
			<title><? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> - online auf <? echo $websiteUrl;?>!</title>
			<meta name="keywords" content="<? echo $keyWordPlural; ?>, <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?>, online, kaufen, günstig">
			
		<?}elseif(isset($_GET['page']) and $_GET['page'] == 2){?>
		
			<meta name="description" content="Du suchst nach <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?>? Schnell und einfach auf <? echo $websiteUrl;?> finden! Eine riesige Auswahl und super Angebote warten auf dich: <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> ✓">
			<title><? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> - Spitzen Angebote auf <? echo $websiteUrl;?>!</title>
			<meta name="keywords" content="<? echo $keyWordPlural; ?>, <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?>, online, kaufen, billig">
			
		<?}elseif(isset($_GET['page']) and $_GET['page'] == 3){?>
		
			<meta name="description" content="<? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> ✓ Tolle Angebote und ein großes Sortiment findet du auf <? echo $websiteUrl;?>! Ganz einfach online <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> finden - komm vorbei!">
			<title><? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> - Top Angbote online auf <? echo $websiteUrl;?>!</title>
			<meta name="keywords" content="<? echo $keyWordPlural; ?>, <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?>, online, billig, Riesenauswahl">
			
		<?}elseif(isset($_GET['page']) and $_GET['page'] == 4){?>
		
			<meta name="description" content="<? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> schnell und einfach online finden auf <? echo $websiteUrl;?>! Super Angebote ✓ Riesige Auswahl ✓ <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> ✓ <? echo $websiteUrl;?> ✓">
			<title><? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> - und weitere Angebote auf <? echo $websiteUrl;?>!</title>
			<meta name="keywords" content="<? echo $keyWordPlural; ?>, <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?>, bestellen, kaufen, billig">
			
		<?}elseif(isset($_GET['page']) and $_GET['page'] == 5){?>
		
			<meta name="description" content="<? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> und weitere Angebote findest du hier! <? echo $websiteUrl;?> bietet eine riesige Auswahl und günstige Preise. Jetzt <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> finden!">
			<title><? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> - online finden auf <? echo $websiteUrl;?>!</title>
			<meta name="keywords" content="<? echo $keyWordPlural; ?>, <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?>, einfach, bestellen, günstig">
			
		<?}else{?>
		
			<meta name="description" content="<? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> und weitere Angebote auf <? echo $websiteUrl;?>! Riesige Auswahl ✓ Günstige Preise ✓ Auf dich zugeschnittene Angebote ✓ <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> ✓">
			<title><? echo $keyWordSingular; ?> <? echo $row['googlename']; ?> - einfach finden auf <? echo $websiteUrl;?>!</title>
			<meta name="keywords" content="<? echo $keyWordPlural; ?>, <? echo $keyWordSingular; ?> <? echo $row['googlename']; ?>, online, finden, günstig">
		<? }?>	
	<?} // Ende Pageresult?>

	<a class="scrollicon" title="zum Seitenanfang" href="#" style="display: inline;"><div><i class="fa fa-arrow-circle-up"></i></div></a>
	
	<!-- Favicon 
	<link rel="/shortcut icon" type="image/x-icon" href="favicon.ico" />
	<link rel="/icon" type="image/x-icon" href="favicon.ico" />
	
	-->
</head>